<?php
/**
 * Fantastik Tema Fonksiyonları
 */

/**
 * Tema kurulum fonksiyonu
 * init kancasına bağlıdır.
 */
function fantastik_setup()
{
    // Head sonuna ayarları enjekte et
    add_hook('head_end', 'fantastik_inject_assets');
}

/**
 * settings.json'dan gelen verilere göre CSS değişkenlerini ve fontları enjekte eder.
 */
function fantastik_inject_assets()
{
    // Ayarları çek
    $color = get_theme_setting('main_color', '#ff4757');
    $blur = get_theme_setting('glass_blur', '15');
    $radius = get_theme_setting('border_radius', '20');
    $bgColor = get_theme_setting('enable_bg_animation', '1');
    $font = get_theme_setting('font_family', 'Outfit');

    // RGB hesapla
    list($r, $g, $b) = sscanf($color, "#%02x%02x%02x");

    // 1. Parlaklık (Luminance) Hesapla: 0 (siyah) - 255 (beyaz)
    // Formula: 0.2126*R + 0.7152*G + 0.0722*B
    $luminance = (0.2126 * $r) + (0.7152 * $g) + (0.0722 * $b);

    // 2. Eğer renk çok koyuysa (örn < 60), parlamayı güçlendirmek için boost uygula
    $glowColor = $color;
    $glowStrength = "15px";

    if ($luminance < 70) {
        // Rengi otomatik olarak aç (Boost)
        $factor = 1.5; // %50 daha parlak
        $br = min(255, round($r * $factor + 50));
        $bg = min(255, round($g * $factor + 50));
        $bb = min(255, round($b * $factor + 50));
        $glowColor = sprintf("#%02x%02x%02x", $br, $bg, $bb);
        $glowStrength = "25px"; // Karanlık renklerde parlama alanını genişlet
    }

    $colorRgb = "$r, $g, $b";

    // Google Fonts Enjeksiyonu
    echo "\n    <!-- Fantastik Fonts -->\n";
    echo "    <link rel='preconnect' href='https://fonts.googleapis.com'>\n";
    echo "    <link rel='preconnect' href='https://fonts.gstatic.com' crossorigin>\n";
    echo "    <link href='https://fonts.googleapis.com/css2?family={$font}:wght@300;400;600;800&display=swap' rel='stylesheet'>\n";

    echo "\n    <style id='fantastik-dynamic-styles'>\n";
    echo "        :root {\n";
    echo "            --main-color: {$color};\n";
    echo "            --main-color-rgb: {$colorRgb};\n";
    echo "            --glow-color: {$glowColor};\n";
    echo "            --glow-strength: {$glowStrength};\n";
    echo "            --glass-blur: {$blur}px;\n";
    echo "            --border-radius: {$radius}px;\n";
    echo "            --bs-body-font-family: '{$font}', sans-serif;\n";
    echo "        }\n";

    // Arka plan animasyonu aktifse
    if ($bgColor == '1') {
        echo "        body::before {\n";
        echo "            content: '';\n";
        echo "            position: fixed;\n";
        echo "            top: -50%; left: -50%; width: 200%; height: 200%;\n";
        echo "            background: radial-gradient(circle, rgba({--main-color-rgb}, 0.05) 0%, transparent 70%);\n";
        echo "            animation: bgGlowAnim 15s linear infinite;\n";
        echo "            z-index: -1;\n";
        echo "            pointer-events: none;\n";
        echo "        }\n";
        echo "        @keyframes bgGlowAnim {\n";
        echo "            from { transform: rotate(0deg); }\n";
        echo "            to { transform: rotate(360deg); }\n";
        echo "        }\n";
    }

    echo "    </style>\n";
}

// Başlangıç kancasına bağla
add_hook('init', 'fantastik_setup');
