<?php
/**
 * Fantastik Theme Floating Glass Navbar
 */
$logo = trim($settings['logo_url'] ?? '');
$siteName = trim($settings['site_name'] ?? 'SpeedPage');
?>
<nav class="floating-glass-nav d-flex align-items-center justify-content-between">
    <!-- Brand / Logo -->
    <a class="nav-brand d-flex align-items-center text-decoration-none" href="<?= BASE_URL ?>">
        <?php if ($logo): ?>
            <img src="<?= htmlspecialchars($logo) ?>" alt="<?= htmlspecialchars($siteName) ?>"
                style="height: 30px; object-fit: contain;" class="me-2">
        <?php endif; ?>
        <span class="fw-bold fs-5 glow-text"><?= htmlspecialchars($siteName) ?></span>
    </a>

    <!-- Navigation Links -->
    <div class="nav-links d-none d-lg-flex align-items-center gap-4">
        <?php foreach ($menus as $m): ?>
            <?php $url = $m['external_url'] ? $m['external_url'] : '?page=' . $m['slug']; ?>
            <a href="<?= htmlspecialchars($url) ?>" class="text-decoration-none fw-medium text-white opacity-75 hover-opacity-100 transition-all">
                <?= htmlspecialchars($m['title']) ?>
            </a>
        <?php endforeach; ?>
    </div>

    <!-- Actions -->
    <div class="nav-actions d-flex align-items-center gap-3">
        <?php if (empty($_SESSION['user_id'])): ?>
            <a href="<?= BASE_URL ?>php/login.php" class="btn btn-sm glow-btn rounded-pill px-4">
                <span lang="login"></span>
            </a>
        <?php else: ?>
            <div class="dropdown">
                <a href="#" class="text-white text-decoration-none dropdown-toggle" data-bs-toggle="dropdown">
                    <i class="fas fa-user-circle fs-4 opacity-75"></i>
                </a>
                <ul class="dropdown-menu dropdown-menu-end shadow border-0 mt-3" style="background: rgba(20,20,25,0.9); backdrop-filter: blur(10px);">
                    <li><a class="dropdown-item text-white" href="<?= BASE_URL ?>php/profile.php?id=<?= $_SESSION['user_id'] ?>"><i class="fas fa-user me-2"></i> Profil</a></li>
                    <?php if ($_SESSION['role'] === 'admin'): ?>
                        <li><a class="dropdown-item text-white" href="<?= BASE_URL ?>admin/index.php"><i class="fas fa-gauge-high me-2"></i> Panel</a></li>
                    <?php endif; ?>
                    <li><hr class="dropdown-divider opacity-10"></li>
                    <li><a class="dropdown-item text-danger" href="<?= BASE_URL ?>php/logout.php"><i class="fas fa-sign-out-alt me-2"></i> Çıkış</a></li>
                </ul>
            </div>
        <?php endif; ?>

        <select id="lang-select" class="bg-transparent text-white border-0 small opacity-75" style="outline:none; cursor:pointer;">
            <option value="tr" class="text-dark">TR</option>
            <option value="en" class="text-dark">EN</option>
        </select>

        <!-- Mobile Toggle -->
        <button id="mobile-menu-toggle" class="btn btn-sm d-lg-none text-white p-0">
            <i class="fas fa-bars"></i>
        </button>
    </div>
</nav>

<!-- Minimal Mobile Sidebar Overlay (keeping logic compatible) -->
<div id="mobile-sidebar" class="mobile-sidebar" style="background: rgba(10,10,15,0.95); backdrop-filter: blur(20px);">
    <div class="p-4 d-flex justify-content-between align-items-center border-bottom border-secondary">
        <span class="fw-bold glow-text"><?= htmlspecialchars($siteName) ?></span>
        <button id="mobile-menu-close" class="btn btn-link text-white text-decoration-none"><i class="fas fa-times"></i></button>
    </div>
    <div class="p-4">
        <?php foreach ($menus as $m): ?>
            <?php $url = $m['external_url'] ? $m['external_url'] : '?page=' . $m['slug']; ?>
            <a href="<?= htmlspecialchars($url) ?>" class="nav-link py-3 text-white border-bottom border-secondary border-opacity-25 d-block text-decoration-none">
                <?= htmlspecialchars($m['title']) ?>
            </a>
        <?php endforeach; ?>
    </div>
</div>
<div id="mobile-sidebar-overlay" class="mobile-sidebar-overlay" style="background: rgba(0,0,0,0.8);"></div>

<style>
    .transition-all { transition: all 0.3s ease; }
    .hover-opacity-100:hover { opacity: 1 !important; }
    .dropdown-item:hover { background: var(--main-color) !important; color: white !important; }
</style>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const toggleBtn = document.getElementById('mobile-menu-toggle');
        const closeBtn = document.getElementById('mobile-menu-close');
        const sidebar = document.getElementById('mobile-sidebar');
        const overlay = document.getElementById('mobile-sidebar-overlay');

        function toggleSidebar() {
            sidebar.classList.toggle('active');
            overlay.classList.toggle('active');
        }

        if (toggleBtn) toggleBtn.addEventListener('click', toggleSidebar);
        if (closeBtn) closeBtn.addEventListener('click', toggleSidebar);
        if (overlay) overlay.addEventListener('click', toggleSidebar);
    });
</script>