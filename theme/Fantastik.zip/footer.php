<?php
/**
 * Fantastik Theme Minimal Footer
 */
?>
<footer class="py-5 mt-5">
    <div class="container text-center">
        <!-- Sosyal İkonlar -->
        <div class="social-links d-flex justify-content-center gap-4 mb-4">
            <a href="#" class="text-white opacity-50 hover-opacity-100 glow-on-hover transition-all fs-4"><i
                    class="fab fa-x-twitter"></i></a>
            <a href="#" class="text-white opacity-50 hover-opacity-100 glow-on-hover transition-all fs-4"><i
                    class="fab fa-github"></i></a>
            <a href="#" class="text-white opacity-50 hover-opacity-100 glow-on-hover transition-all fs-4"><i
                    class="fab fa-linkedin"></i></a>
            <a href="#" class="text-white opacity-50 hover-opacity-100 glow-on-hover transition-all fs-4"><i
                    class="fab fa-instagram"></i></a>
        </div>

        <!-- Powered By -->
        <div class="powered-by">
            <p class="text-white opacity-25 small mb-0 fw-light">
                © <?= date('Y') ?> SpeedPage. All rights reserved.
            </p>
            <a href="https://github.com/snrj35-dev/SpeedPage" target="_blank"
                class="text-decoration-none small transition-all glow-text-light">
                Powered by <span class="fw-bold glow-text">SpeedPage</span>
            </a>
        </div>
    </div>
</footer>

<style>
    .glow-on-hover:hover {
        color: var(--main-color) !important;
        text-shadow: 0 0 15px var(--main-color);
        opacity: 1 !important;
    }

    .glow-text-light {
        color: rgba(255, 255, 255, 0.4);
    }

    .glow-text-light:hover {
        color: white;
    }
</style>