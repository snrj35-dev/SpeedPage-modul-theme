<?php
declare(strict_types=1);
global $settings, $menus;
?>
<nav class="zen-nav">
    <div class="zen-container d-flex align-items-center w-100">
        <a href="<?= BASE_URL ?>" class="nav-brand">
            <?= e($settings['site_name'] ?? 'aura zen') ?>
        </a>

        <ul class="nav-links d-none d-md-flex">
            <?php foreach ($menus as $m): ?>
                <?php
                if ($m['external_url']) {
                    $url = $m['external_url'];
                } else {
                    $url = (($settings['friendly_url'] ?? '0') === '1') ? (BASE_PATH . $m['slug']) : (BASE_URL . 'index.php?page=' . $m['slug']);
                }
                ?>
                <li>
                    <a href="<?= e($url) ?>" data-page="<?= e($m['slug']) ?>" class="<?= is_zen_active($m['slug']) ?>">
                        <?= e($m['title']) ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>

        <div class="ms-4 d-flex align-items-center gap-3">
            <!-- Theme Toggle -->
            <button onclick="toggleTheme()" class="btn-zen" style="padding: 0.5rem; border-radius: 50%;">
                <i class="fa fa-moon"></i>
            </button>

            <?php if (isset($_SESSION['user_id']) && (($_SESSION['role'] ?? '') === 'admin')): ?>
                <a href="<?= BASE_URL ?>admin" class="btn-zen">
                    <i class="fa fa-user-shield"></i>
                    <span class="d-none d-lg-inline">
                        <?= __('admin_panel') ?>
                    </span>
                </a>
            <?php endif; ?>
        </div>
    </div>
</nav>

<script>
    function toggleTheme() {
        const html = document.documentElement;
        const current = html.getAttribute('data-theme');
        const target = current === 'dark' ? 'light' : 'dark';
        html.setAttribute('data-theme', target);
        localStorage.setItem('theme', target);

        const icon = document.querySelector('.zen-nav .fa');
        if (target === 'dark') {
            icon.classList.replace('fa-moon', 'fa-sun');
        } else {
            icon.classList.replace('fa-sun', 'fa-moon');
        }
    }

    // Initial icon set
    document.addEventListener('DOMContentLoaded', () => {
        const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
        const icon = document.querySelector('.zen-nav .fa-moon, .zen-nav .fa-sun');
        if (icon && isDark) icon.classList.replace('fa-moon', 'fa-sun');
    });
</script>
