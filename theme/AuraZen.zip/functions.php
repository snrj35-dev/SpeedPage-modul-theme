<?php
declare(strict_types=1);

/**
 * Aura Zen - Professional Premium Functions
 * SpeedPage CMS Hook Architecture
 */

// 1. Asset & Style Injection
add_hook('head_end', function () {
    // Ayarları Çek
    $accent = get_theme_setting('accent_color', '#2563eb');
    $width = get_theme_setting('content_width', '1100');
    $shadows = get_theme_setting('enable_soft_shadows', '1');

    // RGB Hesapla (Senin sevdiğin yöntemle)
    list($r, $g, $b) = sscanf($accent, "#%02x%02x%02x");
    $accentRgb = "$r, $g, $b";

    echo "\n\n<style>
    :root {
        --zen-accent: $accent;
        --zen-accent-rgb: $accentRgb;
        --content-width: {$width}px;
    }
    
    /* Progress Bar Style */
    #zen-progress {
        position: fixed; top: 0; left: 0; width: 0%; height: 3px;
        background: var(--zen-accent); z-index: 9999; transition: width 0.2s;
    }

    /* Aura Follower Style */
    .zen-aura-cursor {
        position: fixed; width: 400px; height: 400px;
        background: radial-gradient(circle, rgba($accentRgb, 0.08) 0%, transparent 70%);
        border-radius: 50%; pointer-events: none; z-index: -1;
        transform: translate(-50%, -50%); transition: opacity 0.5s ease;
        opacity: 0;
    }
    
    " . ($shadows === '1' ? "body { --zen-shadow-enabled: 1; }" : "") . "
    </style>\n";
});

// 2. Premium Scripts (Progress Bar, Aura, Smooth Scroll)
add_hook('footer_end', function () {
    ?>
    <div id="zen-progress"></div>
    <div class="zen-aura-cursor" id="aura-blob"></div>

    <script>
        // 1. Scroll Progress
        window.onscroll = function () {
            let winScroll = document.body.scrollTop || document.documentElement.scrollTop;
            let height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
            let scrolled = (winScroll / height) * 100;
            document.getElementById("zen-progress").style.width = scrolled + "%";
        };

        // 2. Aura Follower
        const aura = document.getElementById('aura-blob');
        document.addEventListener('mousemove', (e) => {
            aura.style.opacity = '1';
            aura.style.left = e.clientX + 'px';
            aura.style.top = e.clientY + 'px';
        });

        // 3. Smooth Scroll için Body Class
        document.documentElement.style.scrollBehavior = 'smooth';
    </script>
    <?php
});

// 3. Navbar Yardımcı Fonksiyonu (Eğer navbar.php'de kullanılıyorsa)
if (!function_exists('is_zen_active')) {
    function is_zen_active($slug)
    {
        $currentPage = $_GET['page'] ?? 'home';
        return ($currentPage === $slug) ? 'active' : '';
    }
}