<?php
declare(strict_types=1);
global $settings;
?>
<footer class="zen-footer">
    <div class="zen-container">
        <div class="mb-4">
            <a href="<?= BASE_URL ?>" class="nav-brand" style="opacity: 0.5;">aura zen</a>
        </div>

        <p style="font-size: 0.9rem;">
            <?= sprintf(__('engine_signature'), date('Y')) ?>
        </p>

        <div class="mt-4 d-flex justify-content-center gap-4">
            <a href="#" class="text-muted"><i class="fab fa-twitter"></i></a>
            <a href="#" class="text-muted"><i class="fab fa-instagram"></i></a>
            <a href="#" class="text-muted"><i class="fab fa-github"></i></a>
        </div>

        <?php if (DEBUG): ?>
            <div class="mt-5 p-2" style="font-size: 0.7rem; opacity: 0.3; border-top: 1px dashed var(--zen-border);">
                Debug: Theme AuraZen | System PHP 8.3
            </div>
        <?php endif; ?>
    </div>
</footer>