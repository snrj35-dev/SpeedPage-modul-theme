<?php
declare(strict_types=1);
global $db, $settings;

// İstatistikleri senin Fantastik stilinde çekelim
$countPages = $db->query("SELECT COUNT(id) FROM pages WHERE is_active = 1")->fetchColumn();
$countUsers = $db->query("SELECT COUNT(id) FROM users")->fetchColumn();
?>

<aside class="zen-sidebar">
    <div class="zen-card mb-4 p-4 text-center">
        <div class="mb-3">
            <i class="fas fa-leaf fa-2x text-accent"></i>
        </div>
        <h6 class="fw-bold"><?= e($settings['site_name'] ?? 'Aura Zen') ?></h6>
        <p class="small text-muted mb-0">Huzurlu ve minimalist içerik deneyimine hoş geldiniz.</p>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-6">
            <div class="zen-card p-3 text-center" style="border-radius: 12px;">
                <span class="d-block h4 fw-bold mb-0"><?= $countPages ?></span>
                <span class="small text-muted opacity-75">İçerik</span>
            </div>
        </div>
        <div class="col-6">
            <div class="zen-card p-3 text-center" style="border-radius: 12px;">
                <span class="d-block h4 fw-bold mb-0"><?= $countUsers ?></span>
                <span class="small text-muted opacity-75">Üye</span>
            </div>
        </div>
    </div>
</aside>