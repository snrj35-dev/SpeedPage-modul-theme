const player = document.getElementById("player");
const seekBar = document.getElementById("seekBar");
const timeText = document.getElementById("timeText");
const nextEpBox = document.getElementById("nextEpBox");
const subtitleSelect = document.getElementById("subtitleSelect");
const audioSelect = document.getElementById("audioSelect");

let playlist = [];
let subsMap = {}; // src -> subtitles array
let currentIndex = 0;

//------------------- LIST ITEMS -> PLAYLIST -------------------
document.querySelectorAll(".item").forEach((el, i)=>{
    const src = el.dataset.src;
    const subs = safeJSON(el.dataset.subs) || [];
    playlist.push(src);
    subsMap[src] = subs;

    el.addEventListener("click",()=>{
        currentIndex = i;
        loadVideo(playlist[currentIndex]);
    });
});

function safeJSON(str){
    try { return JSON.parse(str); } catch(e){ return null; }
}

//------------------- LOAD VIDEO -----------------------
function loadVideo(src){
    document.getElementById("playerWrapper").style.display="block";

    // Clear previous tracks
    [...player.querySelectorAll("track")].forEach(t=>t.remove());

    // Build subtitle tracks
    buildSubtitleTracks(subsMap[src]);

    // Set source and play
    player.src = src;
    player.play().catch(()=>{}); // autoplay might be blocked

    // Reset UI
    seekBar.value = 0;
    timeText.textContent = "00:00 / 00:00";

    setTimeout(()=> videoInfoDetect(), 800);
}

// Create <track> elements and fill subtitleSelect
function buildSubtitleTracks(subs){
    subtitleSelect.innerHTML = `<option value="">Altyazı Yok</option>`;
    subs.forEach((s, idx)=>{
        const tr = document.createElement("track");
        tr.kind = "subtitles";
        tr.label = s.label || ("Altyazı " + (idx+1));
        tr.srclang = s.lang || "tr";
        tr.src = s.src;
        tr.default = (idx===0); // first default
        player.appendChild(tr);

        const opt = document.createElement("option");
        opt.value = s.src;
        opt.textContent = s.label || `${s.lang?.toUpperCase()} Altyazı`;
        if(idx===0) opt.selected = true;
        subtitleSelect.appendChild(opt);
    });

    player.textTracks && Array.from(player.textTracks).forEach(tt=>{
        tt.mode = subs.length ? "showing" : "disabled";
    });
}

//------------------- PLAY/PAUSE ------------------------
document.getElementById("playPause").onclick=()=>{
    if(player.paused){ player.play(); }
    else { player.pause(); }
};

//------------------- SEEK BAR --------------------------
player.addEventListener("timeupdate",()=>{
    if (isFinite(player.duration) && player.duration > 0) {
        seekBar.value = (player.currentTime / player.duration) * 100;
    }
    timeText.textContent =
        format(player.currentTime) + " / " + format(player.duration);

    let total = Number(localStorage.getItem("watchTime") ?? 0) + 1;
    localStorage.setItem("watchTime", total);
    document.getElementById("totalMinutes").textContent = Math.floor(total/60);
});

seekBar.oninput = ()=>{
    if (!isFinite(player.duration) || player.duration <= 0) return;
    player.currentTime = (seekBar.value/100) * player.duration;
};

//------------------- FORMAT ----------------------------
function format(sec){
    if(!isFinite(sec) || sec <= 0) return "00:00";
    let m = Math.floor(sec/60);
    let s = Math.floor(sec%60);
    return String(m).padStart(2,"0")+":"+String(s).padStart(2,"0");
}

//------------------- FF/REW ----------------------------
document.getElementById("ff").onclick = ()=> player.currentTime = Math.min(player.currentTime + 10, player.duration || player.currentTime + 10);
document.getElementById("rew").onclick = ()=> player.currentTime = Math.max(player.currentTime - 10, 0);

//------------------- SPEED -----------------------------
document.getElementById("speedSelect").onchange = (e)=>{
    player.playbackRate = Number(e.target.value);
};

//------------------- AUTO NEXT EP ----------------------
player.addEventListener("ended",()=>{
    nextEpBox.style.display="block";
    setTimeout(()=> nextEpisode(), 5000);
});
function nextEpisode(){
    currentIndex++;
    if(currentIndex >= playlist.length) { nextEpBox.style.display="none"; return; }
    nextEpBox.style.display="none";
    loadVideo(playlist[currentIndex]);
}

//------------------- SUBTITLE SELECT -------------------
subtitleSelect.onchange = (e)=>{
    const val = e.target.value;
    const trackEls = Array.from(player.querySelectorAll("track"));
    if(val === ""){
        trackEls.forEach(t=> t.mode = "disabled");
        return;
    }
    trackEls.forEach(t=>{
        t.mode = (t.src.endsWith(val) || t.src === val) ? "showing" : "disabled";
    });
};

//------------------- AUDIO TRACKS ----------------------
player.addEventListener("loadedmetadata", ()=>{
    audioSelect.innerHTML = `<option value="">Varsayılan Ses</option>`;
    const at = player.audioTracks;
    if(at && at.length){
        for(let i=0; i<at.length; i++){
            const opt = document.createElement("option");
            const lang = at[i].language || "";
            opt.value = String(i);
            opt.textContent = (lang ? lang.toUpperCase()+" " : "") + "Ses " + (i+1);
            audioSelect.appendChild(opt);
        }
    }
});
audioSelect.onchange = ()=>{
    const idx = audioSelect.value;
    const at = player.audioTracks;
    if(!at || !at.length) return;
    for(let i=0; i<at.length; i++){
        at[i].enabled = (String(i) === String(idx));
    }
};

//------------------- FULLSCREEN ------------------------
document.getElementById("fsBtn").onclick = ()=>{
    const any = player.requestFullscreen || player.webkitEnterFullscreen || player.webkitRequestFullscreen || player.msRequestFullscreen;
    if(any){ any.call(player); }
};

//------------------- MOBILE GESTURES -------------------
let lastTap = 0;
player.addEventListener("touchend",(e)=>{
    const now = Date.now();
    const dt = now - lastTap;
    lastTap = now;
    if(dt < 300){
        const touch = e.changedTouches[0];
        const x = touch.clientX - player.getBoundingClientRect().left;
        if(x < player.clientWidth/2) player.currentTime = Math.max(player.currentTime - 10, 0);
        else player.currentTime = Math.min(player.currentTime + 10, player.duration || player.currentTime + 10);
    }
});

// Vertical swipe on right half: volume
let startY=null, startX=null;
player.addEventListener("touchstart",(e)=>{
    const t = e.touches[0];
    startY = t.clientY;
    startX = t.clientX;
});
player.addEventListener("touchmove",(e)=>{
    if(startY===null) return;
    const t = e.touches[0];
    const dy = startY - t.clientY;
    const dx = Math.abs(startX - t.clientX);
    const rect = player.getBoundingClientRect();
    const rightHalf = startX > rect.left + rect.width/2;
    if(rightHalf && Math.abs(dy) > 20 && dx < 30){
        const delta = dy / 300;
        player.volume = Math.min(1, Math.max(0, player.volume + delta));
        startY = t.clientY;
    }
});
player.addEventListener("touchend",()=>{ startY=null; startX=null; });

player.addEventListener("play",()=>{
    if(window.innerWidth < 600){
        const any = player.requestFullscreen || player.webkitEnterFullscreen || player.webkitRequestFullscreen || player.msRequestFullscreen;
        any && any.call(player);
    }
});
//------------------- VIDEO INFO ------------------------
function videoInfoDetect() {
    const w = player.videoWidth;
    const h = player.videoHeight;

    document.getElementById("resBadge").innerText = `${w || 0}x${h || 0}`;

    // HDR hint (best-effort; not reliable across browsers)
    try {
        const cs = (player.getVideoPlaybackQuality && player.getVideoPlaybackQuality().colorSpace) || "";
        if(String(cs).includes("2020")) document.getElementById("hdrBadge").innerText="HDR10";
        else if(String(cs).includes("pq")) document.getElementById("hdrBadge").innerText="Dolby Vision";
        else document.getElementById("hdrBadge").innerText="";
    } catch(e){
        document.getElementById("hdrBadge").innerText="";
    }

    // Codec badge
    const src = player.src.toLowerCase();
    if(src.endsWith(".mp4")) document.getElementById("codecBadge").innerText="H.264 / AAC";
    else if(src.endsWith(".mkv")) document.getElementById("codecBadge").innerText="MKV (Mixed Codec)";
    else if(src.endsWith(".webm")) document.getElementById("codecBadge").innerText="VP9 / Opus";
    else document.getElementById("codecBadge").innerText="";

    // Bitrate simulation
    const bit = ((w * h) / 1000).toFixed(0);
    document.getElementById("bitBadge").innerText = (isFinite(bit) ? bit : 0) + " kbps";
}

