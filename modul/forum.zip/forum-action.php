<?php
require_once __DIR__ . '/../../settings.php';
require_once ROOT_DIR . 'admin/db.php';
require_once __DIR__ . '/forum-func.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json');

// Check if user is logged in
function isLoggedIn()
{
    return isset($_SESSION['user_id']);
}

function isAdmin()
{
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

// Helper to send JSON response
function jsonResponse($success, $message, $data = [])
{
    echo json_encode(['success' => $success, 'message' => $message, 'data' => $data]);
    exit;
}

$action = $_POST['action'] ?? '';

try {
    switch ($action) {
        // --- CATEGORIES ---
        case 'add_category':
            if (!isAdmin())
                jsonResponse(false, 'Yetkisiz işlem.');
            $title = $_POST['title'] ?? '';
            if (empty($title))
                jsonResponse(false, 'Başlık gerekli.');

            $stmt = $db->prepare("INSERT INTO forum_categories (title, sort_order) VALUES (?, (SELECT IFNULL(MAX(sort_order), 0) + 1 FROM forum_categories))");
            $stmt->execute([$title]);
            jsonResponse(true, 'Kategori oluşturuldu.');
            break;

        case 'delete_category':
            if (!isAdmin())
                jsonResponse(false, 'Yetkisiz işlem.');
            $id = $_POST['id'] ?? 0;
            $stmt = $db->prepare("DELETE FROM forum_categories WHERE id = ?");
            $stmt->execute([$id]);
            jsonResponse(true, 'Kategori silindi.');
            break;

        case 'update_category':
            if (!isAdmin())
                jsonResponse(false, 'Yetkisiz işlem.');
            $id = $_POST['id'] ?? 0;
            $title = $_POST['title'] ?? '';
            $stmt = $db->prepare("UPDATE forum_categories SET title = ? WHERE id = ?");
            $stmt->execute([$title, $id]);
            jsonResponse(true, 'Kategori güncellendi.');
            break;

        // --- BOARDS ---
        case 'add_board':
            if (!isAdmin())
                jsonResponse(false, 'Yetkisiz işlem.');
            $categoryId = $_POST['category_id'] ?? 0;
            $title = $_POST['title'] ?? '';
            $desc = $_POST['description'] ?? '';

            if (empty($title))
                jsonResponse(false, 'Başlık gerekli.');

            $stmt = $db->prepare("INSERT INTO forum_boards (category_id, title, description, sort_order) VALUES (?, ?, ?, (SELECT IFNULL(MAX(sort_order), 0) + 1 FROM forum_boards WHERE category_id = ?))");
            $stmt->execute([$categoryId, $title, $desc, $categoryId]);
            jsonResponse(true, 'Pano oluşturuldu.');
            break;

        case 'delete_board':
            if (!isAdmin())
                jsonResponse(false, 'Yetkisiz işlem.');
            $id = $_POST['id'] ?? 0;
            $stmt = $db->prepare("DELETE FROM forum_boards WHERE id = ?");
            $stmt->execute([$id]);
            jsonResponse(true, 'Pano silindi.');
            break;

        case 'update_board':
            if (!isAdmin())
                jsonResponse(false, 'Yetkisiz işlem.');
            $id = $_POST['id'] ?? 0;
            $title = $_POST['title'] ?? '';
            $desc = $_POST['description'] ?? '';
            $stmt = $db->prepare("UPDATE forum_boards SET title = ?, description = ? WHERE id = ?");
            $stmt->execute([$title, $desc, $id]);
            jsonResponse(true, 'Pano güncellendi.');
            break;

        // --- TOPICS ---
        case 'add_topic':
            if (!isLoggedIn())
                jsonResponse(false, 'Giriş yapmalısınız.');
            $userId = $_SESSION['user_id'];
            $userIp = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';

            $boardId = $_POST['board_id'] ?? 0;
            $title = $_POST['title'] ?? '';
            $content = $_POST['content'] ?? ''; // First post content

            if (empty(trim($title)) || empty(trim(strip_tags($content, '<img><i>'))))
                jsonResponse(false, 'Başlık ve içerik boş olamaz.');

            $db->beginTransaction();
            try {
                // Create Topic
                $stmt = $db->prepare("INSERT INTO forum_topics (board_id, user_id, title) VALUES (?, ?, ?)");
                $stmt->execute([$boardId, $userId, $title]);
                $topicId = $db->lastInsertId();

                $db->prepare("INSERT INTO forum_posts (topic_id, user_id, content, user_ip) VALUES (?, ?, ?, ?)")->execute([$topicId, $userId, $content, $userIp ?? 'UNKNOWN']);
                $postId = $db->lastInsertId();

                // 🚀 MENTIONS NOTIFICATION
                preg_match_all('/@([a-zA-Z0-9_-]+)/', $content, $matches);
                if (!empty($matches[1])) {
                    $uniqueMentions = array_unique($matches[1]);
                    foreach ($uniqueMentions as $username) {
                        $stmt = $db->prepare("SELECT id FROM users WHERE username = ?");
                        $stmt->execute([$username]);
                        $mUserId = $stmt->fetchColumn();
                        if ($mUserId) {
                            addForumNotification((int) $mUserId, (int) $userId, (int) $postId, 'mention');
                        }
                    }
                }

                // Update stats
                $stmt = $db->prepare("UPDATE forum_boards SET topic_count = topic_count + 1, post_count = post_count + 1 WHERE id = ?");
                $stmt->execute([$boardId]);

                $db->commit();
                jsonResponse(true, 'Konu oluşturuldu.', ['topic_id' => $topicId, 'post_id' => $postId, 'p' => 1]);
            } catch (Exception $e) {
                $db->rollBack();
                jsonResponse(false, 'Hata: ' . $e->getMessage());
            }
            break;

        // --- POSTS ---
        case 'add_post':
            if (!isLoggedIn())
                jsonResponse(false, 'Giriş yapmalısınız.');
            $userId = $_SESSION['user_id'];
            $topicId = $_POST['topic_id'] ?? 0;
            $content = $_POST['content'] ?? '';

            if (empty(trim(strip_tags($content ?? '', '<img><i>'))))
                jsonResponse(false, 'İçerik boş olamaz.');

            // Check if topic is locked
            $stmt = $db->prepare("SELECT is_locked FROM forum_topics WHERE id = ?");
            $stmt->execute([$topicId]);
            $isLocked = $stmt->fetchColumn();

            if ($isLocked && !isAdmin()) {
                jsonResponse(false, 'Bu konu kilitlidir.');
            }

            $db->beginTransaction();
            try {
                $stmt = $db->prepare("INSERT INTO forum_posts (topic_id, user_id, content, user_ip) VALUES (?, ?, ?, ?)");
                $stmt->execute([$topicId, $userId, $content, $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN']);
                $postId = (int) $db->lastInsertId();

                // 🚀 NOTIFY TOPIC OWNER (if not the same person)
                $stmt = $db->prepare("SELECT user_id FROM forum_topics WHERE id = ?");
                $stmt->execute([$topicId]);
                $topicOwnerId = $stmt->fetchColumn();
                if ($topicOwnerId && $topicOwnerId != $userId) {
                    addForumNotification((int) $topicOwnerId, (int) $userId, (int) $postId, 'reply');
                }

                // 🚀 MENTIONS NOTIFICATION
                preg_match_all('/@([a-zA-Z0-9_-]+)/', $content, $matches);
                if (!empty($matches[1])) {
                    $uniqueMentions = array_unique($matches[1]);
                    foreach ($uniqueMentions as $username) {
                        $stmt = $db->prepare("SELECT id FROM users WHERE username = ?");
                        $stmt->execute([$username]);
                        $mUserId = $stmt->fetchColumn();
                        if ($mUserId) {
                            addForumNotification((int) $mUserId, (int) $userId, (int) $postId, 'mention');
                        }
                    }
                }

                // Fetch board_id to update counts
                $stmt = $db->prepare("SELECT board_id FROM forum_topics WHERE id = ?");
                $stmt->execute([$topicId]);
                $boardId = $stmt->fetchColumn();

                if ($boardId) {
                    $stmt = $db->prepare("UPDATE forum_boards SET post_count = post_count + 1 WHERE id = ?");
                    $stmt->execute([$boardId]);
                }

                // Calculate the page number for this new post
                $stmt = $db->prepare("SELECT COUNT(*) FROM forum_posts WHERE topic_id = ?");
                $stmt->execute([$topicId]);
                $totalCount = $stmt->fetchColumn();
                $perPage = 10; // Must match forum.php perPage
                $page = ceil($totalCount / $perPage);

                $db->commit();
                jsonResponse(true, 'Yanıt eklendi.', ['post_id' => $postId, 'topic_id' => $topicId, 'p' => $page]);
            } catch (Exception $e) {
                $db->rollBack();
                jsonResponse(false, 'Hata: ' . $e->getMessage());
            }
            break;

        case 'update_post':
            if (!isLoggedIn())
                jsonResponse(false, 'Giriş yapmalısınız.');
            $postId = $_POST['id'] ?? 0;
            $content = $_POST['content'] ?? '';

            if (empty($content))
                jsonResponse(false, 'İçerik gerekli.');

            // Check ownership
            $stmt = $db->prepare("SELECT user_id FROM forum_posts WHERE id = ?");
            $stmt->execute([$postId]);
            $ownerId = $stmt->fetchColumn();

            if (!isAdmin() && $_SESSION['user_id'] != $ownerId) {
                jsonResponse(false, 'Yetkiniz yok.');
            }

            $stmt = $db->prepare("UPDATE forum_posts SET content = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
            $stmt->execute([$content, $postId]);
            jsonResponse(true, 'Mesaj güncellendi.');
            break;

        case 'delete_post':
            if (!isLoggedIn())
                jsonResponse(false, 'Giriş yapmalısınız.');
            $postId = $_POST['id'] ?? 0;

            // Check ownership & Details for stats
            $stmt = $db->prepare("SELECT p.user_id, p.topic_id, t.board_id FROM forum_posts p JOIN forum_topics t ON p.topic_id =
t.id WHERE p.id = ?");
            $stmt->execute([$postId]);
            $post = $stmt->fetch();

            if (!$post)
                jsonResponse(false, 'Mesaj bulunamadı.');

            if (!isAdmin() && $_SESSION['user_id'] != $post['user_id']) {
                jsonResponse(false, 'Yetkiniz yok.');
            }

            // Check if it's the first post of a topic - usually we delete the topic or prevent this
// Here we will prevent deleting the FIRST post of a topic unless via delete_topic
            $stmt = $db->prepare("SELECT id FROM forum_posts WHERE topic_id = ? ORDER BY created_at ASC LIMIT 1");
            $stmt->execute([$post['topic_id']]);
            $firstPostId = $stmt->fetchColumn();

            if ($firstPostId == $postId) {
                jsonResponse(false, 'Konunun ilk mesajı silinemez. Konuyu silmeyi deneyin.');
            }

            $db->beginTransaction();
            try {
                $stmt = $db->prepare("DELETE FROM forum_posts WHERE id = ?");
                $stmt->execute([$postId]);

                // Update stats
                $stmt = $db->prepare("UPDATE forum_boards SET post_count = post_count - 1 WHERE id = ?");
                $stmt->execute([$post['board_id']]);

                $db->commit();
                jsonResponse(true, 'Mesaj silindi.');
            } catch (Exception $e) {
                $db->rollBack();
                jsonResponse(false, 'Hata: ' . $e->getMessage());
            }
            break;

        // --- TOPIC ACTIONS ---
        case 'delete_topic':
            if (!isAdmin())
                jsonResponse(false, 'Yetkisiz işlem.');
            $topicId = $_POST['id'] ?? 0;

            $stmt = $db->prepare("SELECT board_id FROM forum_topics WHERE id = ?");
            $stmt->execute([$topicId]);
            $boardId = $stmt->fetchColumn();

            if (!$boardId)
                jsonResponse(false, 'Konu bulunamadı.');

            // Count posts in topic
            $stmt = $db->prepare("SELECT COUNT(*) FROM forum_posts WHERE topic_id = ?");
            $stmt->execute([$topicId]);
            $postCount = $stmt->fetchColumn();

            $db->beginTransaction();
            try {
                $stmt = $db->prepare("DELETE FROM forum_topics WHERE id = ?");
                $stmt->execute([$topicId]);

                // Update stats
                $stmt = $db->prepare("UPDATE forum_boards SET topic_count = topic_count - 1, post_count = post_count - ? WHERE id = ?");
                $stmt->execute([$postCount, $boardId]);

                $db->commit();
                jsonResponse(true, 'Konu ve mesajlar silindi.');
            } catch (Exception $e) {
                $db->rollBack();
                jsonResponse(false, 'Hata: ' . $e->getMessage());
            }
            break;

        case 'toggle_lock':
            if (!isAdmin())
                jsonResponse(false, 'Yetkisiz işlem.');
            $topicId = $_POST['id'] ?? 0;

            $stmt = $db->prepare("UPDATE forum_topics SET is_locked = NOT is_locked WHERE id = ?");
            $stmt->execute([$topicId]);
            jsonResponse(true, 'İşlem başarılı.');
            break;

        case 'toggle_reaction':
            if (!isLoggedIn())
                jsonResponse(false, 'Giriş yapmalısınız.');
            $userId = $_SESSION['user_id'];
            $postId = $_POST['post_id'] ?? 0;
            $reaction = $_POST['reaction'] ?? '';

            if (empty($reaction))
                jsonResponse(false, 'Tepki geçersiz.');

            // Check if post exists and user is not the owner
            $stmt = $db->prepare("SELECT user_id FROM forum_posts WHERE id = ?");
            $stmt->execute([$postId]);
            $postOwnerId = $stmt->fetchColumn();

            if ($postOwnerId == $userId) {
                jsonResponse(false, 'Kendi mesajınıza tepki veremezsiniz.');
            }

            // Check if user already reacted
            $stmt = $db->prepare("SELECT reaction FROM forum_reactions WHERE post_id = ? AND user_id = ?");
            $stmt->execute([$postId, $userId]);
            $existing = $stmt->fetchColumn();

            if ($existing) {
                if ($existing === $reaction) {
                    // Remove reaction
                    $stmt = $db->prepare("DELETE FROM forum_reactions WHERE post_id = ? AND user_id = ?");
                    $stmt->execute([$postId, $userId]);
                    jsonResponse(true, 'Tepki kaldırıldı.');
                } else {
                    // Update reaction
                    $stmt = $db->prepare("UPDATE forum_reactions SET reaction = ? WHERE post_id = ? AND user_id = ?");
                    $stmt->execute([$reaction, $postId, $userId]);

                    // Notify post owner
                    addForumNotification((int) $postOwnerId, (int) $userId, (int) $postId, 'reaction');

                    jsonResponse(true, 'Tepki güncellendi.');
                }
            } else {
                // Add new reaction
                $stmt = $db->prepare("INSERT INTO forum_reactions (post_id, user_id, reaction) VALUES (?, ?, ?)");
                $stmt->execute([$postId, $userId, $reaction]);

                // Notify post owner
                addForumNotification((int) $postOwnerId, (int) $userId, (int) $postId, 'reaction');

                jsonResponse(true, 'Tepki eklendi.');
            }
            break;

        case 'get_notifications':
            if (!isLoggedIn())
                jsonResponse(false, 'Giriş yapmalısınız.');
            $userId = $_SESSION['user_id'];
            $notifications = getForumNotifications((int) $userId);
            $unreadCount = getUnreadNotificationCount((int) $userId);
            jsonResponse(true, 'Bildirimler yüklendi.', [
                'list' => $notifications,
                'unread' => $unreadCount
            ]);
            break;

        case 'mark_notifications_read':
            if (!isLoggedIn())
                jsonResponse(false, 'Giriş yapmalısınız.');
            $userId = $_SESSION['user_id'];
            $db->prepare("UPDATE forum_notifications SET is_read = 1 WHERE user_id = ?")->execute([$userId]);
            jsonResponse(true, 'Tüm bildirimler okundu işaretlendi.');
            break;

        case 'mark_notification_read':
            if (!isLoggedIn())
                jsonResponse(false, 'Giriş yapmalısınız.');
            $id = (int) ($_POST['id'] ?? 0);
            markNotificationRead($id, (int) $_SESSION['user_id']);
            jsonResponse(true, 'Bildirim okundu.');
            break;

        case 'search_users':
            if (!isLoggedIn())
                jsonResponse(false, 'Giriş yapmalısınız.');
            $q = $_POST['q'] ?? '';
            if (strlen($q) < 1)
                jsonResponse(true, 'Sonuç bulunamadı.', []);
            $stmt = $db->prepare("SELECT id, username, display_name
    FROM users WHERE username LIKE ? OR display_name LIKE ? LIMIT 5");
            $stmt->execute(['%' . $q . '%', '%' . $q . '%']);
            $users = $stmt->fetchAll();
            jsonResponse(true, 'Kullanıcılar getirildi.', $users);
            break;

        case 'toggle_sticky':
            if (!isAdmin())
                jsonResponse(false, 'Yetkisiz işlem.');
            $topicId = $_POST['id'] ?? 0;

            $stmt = $db->prepare("UPDATE forum_topics SET is_sticky = NOT is_sticky WHERE id = ?");
            $stmt->execute([$topicId]);
            jsonResponse(true, 'İşlem başarılı.');
            break;

        case 'move_category':
            if (!isAdmin())
                jsonResponse(false, 'Yetkisiz işlem.');
            $id = (int) ($_POST['id'] ?? 0);
            $direction = $_POST['direction'] ?? ''; // 'up' or 'down'

            $stmt = $db->prepare("SELECT sort_order FROM forum_categories WHERE id = ?");
            $stmt->execute([$id]);
            $currentOrder = $stmt->fetchColumn();

            if ($direction === 'up') {
                $stmt = $db->prepare("SELECT id, sort_order FROM forum_categories WHERE sort_order < ? ORDER BY sort_order DESC LIMIT 1");
            } else {
                $stmt = $db->prepare("SELECT id, sort_order FROM forum_categories WHERE sort_order > ? ORDER BY sort_order ASC LIMIT 1");
            }
            $stmt->execute([$currentOrder]);
            $target = $stmt->fetch();

            if ($target) {
                $db->beginTransaction();
                $db->prepare("UPDATE forum_categories SET sort_order = ? WHERE id = ?")->execute([$target['sort_order'], $id]);
                $db->prepare("UPDATE forum_categories SET sort_order = ? WHERE id = ?")->execute([$currentOrder, $target['id']]);
                $db->commit();
            }
            jsonResponse(true, 'Sıralama güncellendi.');
            break;

        case 'move_board':
            if (!isAdmin())
                jsonResponse(false, 'Yetkisiz işlem.');
            $id = (int) ($_POST['id'] ?? 0);
            $direction = $_POST['direction'] ?? '';

            $stmt = $db->prepare("SELECT category_id, sort_order FROM forum_boards WHERE id = ?");
            $stmt->execute([$id]);
            $current = $stmt->fetch();

            if ($current) {
                if ($direction === 'up') {
                    $stmt = $db->prepare("SELECT id, sort_order FROM forum_boards WHERE category_id = ? AND sort_order < ? ORDER BY sort_order DESC LIMIT 1");
                } else {
                    $stmt = $db->prepare("SELECT id, sort_order FROM forum_boards WHERE category_id = ? AND sort_order > ? ORDER BY sort_order ASC LIMIT 1");
                }
                $stmt->execute([$current['category_id'], $current['sort_order']]);
                $target = $stmt->fetch();

                if ($target) {
                    $db->beginTransaction();
                    $db->prepare("UPDATE forum_boards SET sort_order = ? WHERE id = ?")->execute([$target['sort_order'], $id]);
                    $db->prepare("UPDATE forum_boards SET sort_order = ? WHERE id = ?")->execute([$current['sort_order'], $target['id']]);
                    $db->commit();
                }
            }
            jsonResponse(true, 'Sıralama güncellendi.');
            break;

        case 'reorder_categories':
            if (!isAdmin())
                jsonResponse(false, 'Yetkisiz işlem.');

            $categoriesJson = $_POST['categories'] ?? '';
            $categories = json_decode($categoriesJson, true);

            if (empty($categories))
                jsonResponse(false, 'Kategori listesi boş.');

            $db->beginTransaction();
            try {
                foreach ($categories as $cat) {
                    $id = (int) ($cat['id'] ?? 0);
                    $order = (int) ($cat['order'] ?? 0);

                    if ($id > 0 && $order > 0) {
                        $stmt = $db->prepare("UPDATE forum_categories SET sort_order = ? WHERE id = ?");
                        $stmt->execute([$order, $id]);
                    }
                }
                $db->commit();
                jsonResponse(true, 'Kategori sıralaması güncellendi.');
            } catch (Exception $e) {
                $db->rollBack();
                jsonResponse(false, 'Hata: ' . $e->getMessage());
            }
            break;

        case 'reorder_boards':
            if (!isAdmin())
                jsonResponse(false, 'Yetkisiz işlem.');

            $boardsJson = $_POST['boards'] ?? '';
            $boards = json_decode($boardsJson, true);

            if (empty($boards))
                jsonResponse(false, 'Pano listesi boş.');

            $db->beginTransaction();
            try {
                foreach ($boards as $board) {
                    $id = (int) ($board['id'] ?? 0);
                    $order = (int) ($board['order'] ?? 0);

                    if ($id > 0 && $order > 0) {
                        $stmt = $db->prepare("UPDATE forum_boards SET sort_order = ? WHERE id = ?");
                        $stmt->execute([$order, $id]);
                    }
                }
                $db->commit();
                jsonResponse(true, 'Pano sıralaması güncellendi.');
            } catch (Exception $e) {
                $db->rollBack();
                jsonResponse(false, 'Hata: ' . $e->getMessage());
            }
            break;

        default:
            jsonResponse(false, 'Geçersiz işlem.');
    }
} catch (PDOException $e) {
    jsonResponse(false, 'Veritabanı hatası: ' . $e->getMessage());
}
?>