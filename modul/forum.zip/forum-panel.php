<?php
require_once ROOT_DIR . 'admin/db.php';
if (function_exists('sp_load_language')) {
    sp_load_language('forum');
}

// Basic admin check
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    die('<div class="container mt-5"><div class="alert alert-danger">Bu sayfaya erişim yetkiniz yok.</div></div>');
}

$categories = $db->query("SELECT * FROM forum_categories ORDER BY sort_order ASC")->fetchAll();
$boards = $db->query("SELECT * FROM forum_boards ORDER BY sort_order ASC")->fetchAll();
?>


<div class="container">
    <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm sticky-top" style="top: 20px; z-index: 100;">
                <div class="card-header" style="background: var(--primary); color: #fff;">
                    <h5 class="mb-0"><i class="fas fa-plus"></i> <?= __('forum_add_category') ?></h5>
                </div>
                <div class="card-body">
                    <form onsubmit="handleForm(event, 'add_category')">
                        <div class="mb-3">
                            <label class="form-label"><?= __('forum_category_name') ?></label>
                            <input type="text" name="title" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-primary btn-responsive w-100"><?= __('forum_save') ?></button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <h4 class="mb-3"><?= __('forum_manage_categories') ?></h4>

            <div id="category-list" class="sortable-categories">
                <?php foreach ($categories as $cat): ?>
                    <div class="card mb-4 shadow-sm category-item" data-id="<?= $cat['id'] ?>">
                        <div class="card-header d-flex justify-content-between align-items-center bg-white"
                            style="cursor: move;">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-grip-vertical text-muted me-2"></i>
                                <h5 class="mb-0 text-primary"><?= htmlspecialchars($cat['title']) ?></h5>
                            </div>
                            <div>
                                <button class="btn btn-sm btn-outline-primary me-1"
                                    onclick="editCategory(<?= $cat['id'] ?>, '<?= htmlspecialchars($cat['title']) ?>')"><i
                                        class="fas fa-edit"></i></button>
                                <button class="btn btn-sm btn-outline-danger"
                                    onclick="deleteItem('delete_category', <?= $cat['id'] ?>, 'DİKKAT: Bu kategoriyi silmek altındaki tüm panoları, konuları ve mesajları kalıcı olarak silecektir!')"><i
                                        class="fas fa-trash"></i></button>
                            </div>
                        </div>
                        <div class="card-body bg-light">
                            <!-- Boards List -->
                            <h6 class="text-muted border-bottom pb-2"><?= __('forum_boards') ?></h6>
                            <?php
                            $catBoards = array_filter($boards, fn($b) => $b['category_id'] == $cat['id']);
                            if (empty($catBoards)): ?>
                                <p class="text-muted small fst-italic">Henüz pano yok.</p>
                            <?php else: ?>
                                <ul class="list-group list-group-flush mb-3 sortable-boards"
                                    data-category-id="<?= $cat['id'] ?>">
                                    <?php foreach ($catBoards as $board): ?>
                                        <li class="list-group-item d-flex justify-content-between align-items-center bg-transparent ps-0 pe-0 board-item"
                                            data-id="<?= $board['id'] ?>" style="cursor: move;">
                                            <div class="d-flex align-items-center">
                                                <i class="fas fa-grip-vertical text-muted me-2"></i>
                                                <div>
                                                    <strong><?= htmlspecialchars($board['title']) ?></strong>
                                                    <br>
                                                    <small class="text-muted"><?= htmlspecialchars($board['description']) ?></small>
                                                </div>
                                            </div>
                                            <div>
                                                <button class="btn btn-sm btn-link text-primary p-0 me-2"
                                                    onclick="editBoard(<?= $board['id'] ?>, '<?= addslashes(htmlspecialchars($board['title'])) ?>', '<?= addslashes(htmlspecialchars($board['description'])) ?>')"><i
                                                        class="fas fa-edit"></i></button>
                                                <button class="btn btn-sm btn-link text-danger p-0"
                                                    onclick="deleteItem('delete_board', <?= $board['id'] ?>, 'DİKKAT: Bu panoyu silmek içindeki tüm konuları ve mesajları kalıcı olarak silecektir!')"><i
                                                        class="fas fa-trash"></i></button>
                                            </div>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>

                            <!-- Add Board Form -->
                            <div class="mt-3 pt-3 border-top">
                                <h6 class="text-muted mb-2"><i class="fas fa-plus-circle"></i>
                                    <?= __('forum_add_board') ?></h6>
                                <form onsubmit="handleForm(event, 'add_board')" class="row g-2">
                                    <input type="hidden" name="category_id" value="<?= $cat['id'] ?>">
                                    <div class="col-md-5">
                                        <input type="text" name="title" class="form-control form-control-sm"
                                            placeholder="<?= __('forum_board_name') ?>" required>
                                    </div>
                                    <div class="col-md-5">
                                        <input type="text" name="description" class="form-control form-control-sm"
                                            placeholder="<?= __('forum_board_desc') ?>">
                                    </div>
                                    <div class="col-md-2">
                                        <button type="submit" class="btn btn-sm btn-outline-secondary btn-responsive w-100"><i
                                                class="fas fa-plus"></i></button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

</div>
 <?php 
// Scripts and Styles are now loaded via admin_assets in module.json
 ?>