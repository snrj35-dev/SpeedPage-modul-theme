/* ======================================================
   FORUM ADMIN PANEL JS (admin_assets)
   ====================================================== */

async function deleteItem(action, id, customWarning = '') {
    const warning = customWarning || 'Bu öğeyi silmek istediğinize emin misiniz?';
    if (!confirm(warning)) return;

    if (customWarning && customWarning.includes('DİKKAT')) {
        const confirmText = prompt('Silmek için "SİL" yazın:');
        if (confirmText !== 'SİL') return;
    }

    const formData = new FormData();
    formData.append('action', action);
    formData.append('id', id);

    const result = await sendRequest(formData);
    if (result.success) {
        forumRedirect();
    } else {
        alert(result.message);
    }
}

async function moveItem(action, id, direction) {
    const formData = new FormData();
    formData.append('action', action);
    formData.append('id', id);
    formData.append('direction', direction);

    const result = await sendRequest(formData);
    if (result.success) {
        forumRedirect();
    } else {
        alert(result.message);
    }
}

async function editBoard(id, oldTitle, oldDesc) {
    const newTitle = prompt('Yeni pano başlığı:', oldTitle);
    if (newTitle === null) return;
    const newDesc = prompt('Yeni pano açıklaması:', oldDesc);
    if (newDesc === null) return;

    const formData = new FormData();
    formData.append('action', 'update_board');
    formData.append('id', id);
    formData.append('title', newTitle);
    formData.append('description', newDesc);

    const result = await sendRequest(formData);
    if (result.success) {
        forumRedirect();
    } else {
        alert(result.message);
    }
}

async function editCategory(id, oldTitle) {
    const newTitle = prompt('Yeni başlık:', oldTitle);
    if (!newTitle || newTitle === oldTitle) return;

    const formData = new FormData();
    formData.append('action', 'update_category');
    formData.append('id', id);
    formData.append('title', newTitle);

    const result = await sendRequest(formData);
    if (result.success) {
        forumRedirect();
    } else {
        alert(result.message);
    }
}

async function toggleAction(action, id) {
    const formData = new FormData();
    formData.append('action', action);
    formData.append('id', id);

    const result = await sendRequest(formData);
    if (result.success) {
        forumRedirect();
    } else {
        alert(result.message);
    }
}

// --- Sortable Initialization ---
document.addEventListener('DOMContentLoaded', function () {
    const categoryList = document.getElementById('category-list');
    if (categoryList && typeof Sortable !== 'undefined') {
        new Sortable(categoryList, {
            animation: 150,
            handle: '.card-header',
            onEnd: function (evt) {
                const categories = [];
                categoryList.querySelectorAll('.category-item').forEach((item, index) => {
                    categories.push({ id: item.getAttribute('data-id'), order: index + 1 });
                });
                const url = (typeof BASE_URL !== 'undefined') ? BASE_URL + 'modules/forum/forum-action.php' : '../modules/forum/forum-action.php';
                fetch(url, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        action: 'reorder_categories',
                        categories: JSON.stringify(categories),
                        csrf: typeof CSRF_TOKEN !== 'undefined' ? CSRF_TOKEN : (document.querySelector('input[name="csrf"]')?.value || '')
                    })
                }).then(r => r.json()).then(data => {
                    if (data.success) {
                        evt.item.style.backgroundColor = '#d4edda';
                        setTimeout(() => evt.item.style.backgroundColor = '', 500);
                    }
                });
            }
        });
    }

    document.querySelectorAll('.sortable-boards').forEach(boardList => {
        if (typeof Sortable === 'undefined') return;
        new Sortable(boardList, {
            animation: 150,
            handle: '.board-item',
            onEnd: function (evt) {
                const boards = [];
                boardList.querySelectorAll('.board-item').forEach((item, index) => {
                    boards.push({ id: item.getAttribute('data-id'), order: index + 1 });
                });
                const url = (typeof BASE_URL !== 'undefined') ? BASE_URL + 'modules/forum/forum-action.php' : '../modules/forum/forum-action.php';
                fetch(url, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        action: 'reorder_boards',
                        boards: JSON.stringify(boards),
                        csrf: typeof CSRF_TOKEN !== 'undefined' ? CSRF_TOKEN : (document.querySelector('input[name="csrf"]')?.value || '')
                    })
                }).then(r => r.json()).then(data => {
                    if (data.success) {
                        evt.item.style.backgroundColor = '#d4edda';
                        setTimeout(() => evt.item.style.backgroundColor = '', 500);
                    }
                });
            }
        });
    });
});
