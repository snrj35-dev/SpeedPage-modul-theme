<?php
declare(strict_types=1);

function clean_forum_content(?string $html): string
{
    if (empty($html))
        return '';
    // Basic whitelist: formatting and structure
    // Allow <a> tags with href and class attributes for profile links and mention-tags
    $allowed = '<b><i><u><s><a href class><img><ul><ol><li><blockquote><pre><p><br><span><div><i>';
    $cleaned = strip_tags($html, $allowed);

    // XSS Protection: Remove dangerous attributes but allow safe ones
    // Remove all on* events and style attributes that could contain javascript
    $cleaned = preg_replace('/on\w+\s*=\s*"[^"]*"/i', '', $cleaned);
    $cleaned = preg_replace('/style\s*=\s*"[^"]*(expression|javascript|vbscript)[^"]*"/i', '', $cleaned);

    // We specifically allow our safe onclick
    // Simplified: just ensure we don't allow javascript: in any attribute
    $cleaned = preg_replace('/javascript:/i', 'no-js:', $cleaned);

    return $cleaned;
}

function getPostReactions(int $postId): array
{
    global $db;
    $stmt = $db->prepare("SELECT reaction, COUNT(*) as count FROM forum_reactions WHERE post_id = ? GROUP BY reaction");
    $stmt->execute([$postId]);
    return $stmt->fetchAll();
}

function getUserReaction(int $postId, int $userId): ?string
{
    if (!$userId)
        return null;
    global $db;
    $stmt = $db->prepare("SELECT reaction FROM forum_reactions WHERE post_id = ? AND user_id = ?");
    $stmt->execute([$postId, $userId]);
    return $stmt->fetchColumn() ?: null;
}

function addForumNotification(int $userId, int $fromUserId, int $postId, string $type): bool
{
    global $db;
    if ($userId === $fromUserId)
        return false;

    // Don't duplicate notification for same post and type if unread
    $stmt = $db->prepare("SELECT id FROM notifications WHERE user_id = ? AND actor_id = ? AND target_type = 'forum' AND target_id = ? AND action_type = ? AND is_read = 0");
    $stmt->execute([$userId, $fromUserId, $postId, $type]);
    if ($stmt->fetch())
        return false;

    $stmt = $db->prepare("INSERT INTO notifications (user_id, actor_id, target_type, target_id, action_type) VALUES (?, ?, 'forum', ?, ?)");
    return $stmt->execute([$userId, $fromUserId, $postId, $type]);
}

function getForumNotifications(int $userId, int $limit = 10): array
{
    global $db;
    // We calculate post_rank to determine which page the post is on
    $stmt = $db->prepare("SELECT 
                            n.id,
                            n.user_id,
                            n.actor_id,
                            n.target_type,
                            n.target_id,
                            n.action_type,
                            n.content,
                            n.is_read,
                            n.created_at,
                            u.username,
                            u.avatar_url,
                            p.topic_id,
                            t.title as topic_title,
                            (SELECT COUNT(*) FROM forum_posts p2 WHERE p2.topic_id = p.topic_id AND p2.id <= p.id) as post_rank,
                            n.target_id AS post_id,
                            n.action_type AS type
                         FROM notifications n 
                         LEFT JOIN users u ON n.actor_id = u.id 
                         LEFT JOIN forum_posts p ON n.target_id = p.id 
                         LEFT JOIN forum_topics t ON p.topic_id = t.id
                         WHERE n.user_id = ?
                         ORDER BY n.created_at DESC LIMIT ?");
    $stmt->execute([$userId, $limit]);
    return $stmt->fetchAll();
}

function getUnreadNotificationCount(int $userId): int
{
    global $db;
    $stmt = $db->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND target_type = 'forum' AND is_read = 0");
    $stmt->execute([$userId]);
    return (int) $stmt->fetchColumn();
}

function markNotificationRead(int $id, int $userId): bool
{
    global $db;
    $stmt = $db->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ? AND target_type = 'forum'");
    return $stmt->execute([$id, $userId]);
}
