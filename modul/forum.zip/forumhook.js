/* ======================================================
   FORUM GLOBAL HOOK JS (hooksassets)
   ====================================================== */

// Helper for AJAX requests
async function sendRequest(formData) {
    try {
        if (typeof FormData !== 'undefined' && formData instanceof FormData && !formData.has('csrf')) {
            const token = (typeof CSRF_TOKEN !== 'undefined') ? CSRF_TOKEN : '';
            formData.append('csrf', token);
        }

        let actionUrl = 'modules/forum/forum-action.php';
        if (typeof BASE_URL !== 'undefined' && BASE_URL) {
            actionUrl = BASE_URL + 'modules/forum/forum-action.php';
        } else if (typeof BASE_PATH !== 'undefined' && BASE_PATH) {
            actionUrl = BASE_PATH + 'modules/forum/forum-action.php';
        }

        const response = await fetch(actionUrl, {
            method: 'POST',
            body: formData
        });

        const text = await response.text();
        try {
            return JSON.parse(text);
        } catch (jsonError) {
            console.error('JSON Parse Error:', jsonError, 'Response Text:', text);
            return { success: false, message: 'Sunucudan geçersiz yanıt alındı.' };
        }
    } catch (error) {
        console.error('Network/Request Error:', error);
        return { success: false, message: 'İletişim hatası oluştu.' };
    }
}

// SPA compatible redirect/reload
function forumRedirect(queryString = '') {
    if (window.location.pathname.includes('/admin/')) {
        window.location.reload();
        return;
    }

    const urlParams = new URLSearchParams(window.location.search);
    let page = urlParams.get('page') || 'forum';

    if (!queryString) {
        const boardId = urlParams.get('board_id');
        const topicId = urlParams.get('topic_id');
        const p = urlParams.get('p');
        if (topicId) {
            queryString = 'topic_id=' + topicId;
            if (p) queryString += '&p=' + p;
        } else if (boardId) {
            queryString = 'board_id=' + boardId;
            if (p) queryString += '&p=' + p;
        }
    }

    const target = page + (queryString ? (queryString.startsWith('&') ? queryString : '&' + queryString) : '');

    if (typeof loadPage === 'function') {
        loadPage(target);
        const modalEl = document.querySelector('.modal.show');
        if (modalEl) {
            const modal = bootstrap.Modal.getInstance(modalEl);
            if (modal) modal.hide();
            document.querySelectorAll('.modal-backdrop').forEach(el => el.remove());
            document.body.classList.remove('modal-open');
            document.body.style.overflow = '';
            document.body.style.paddingRight = '';
        }
    } else {
        window.location.href = '?page=' + target;
    }
}

async function handleForm(event, action) {
    event.preventDefault();
    const form = event.target;
    const editorEl = form.querySelector('.xf-editor-area');
    const hiddenInput = form.querySelector('input[name="content"]');
    if (editorEl && hiddenInput) {
        const cleanInner = editorEl.innerText.trim();
        if (cleanInner === '' && !editorEl.querySelector('img') && !editorEl.querySelector('i')) {
            alert('Lütfen bir içerik giriniz.');
            return;
        }
        hiddenInput.value = editorEl.innerHTML;
    }

    const formData = new FormData(form);
    formData.append('action', action);
    const result = await sendRequest(formData);

    if (result.success) {
        if (result.data && result.data.topic_id) {
            const hash = result.data.post_id ? '#post-' + result.data.post_id : '';
            const pageParam = result.data.p ? '&p=' + result.data.p : '';
            forumRedirect('topic_id=' + result.data.topic_id + pageParam + hash);
        } else {
            forumRedirect();
        }
    } else {
        alert(result.message);
    }
}

// --- WYSIWYG Editor logic ---
function moveCursorToEnd(el) {
    el.focus();
    const selection = window.getSelection();
    if (selection) {
        const range = document.createRange();
        range.selectNodeContents(el);
        range.collapse(false);
        selection.removeAllRanges();
        selection.addRange(range);
    }
}

function editorCmd(name, value = null, btn = null) {
    let editor = null;
    if (btn) {
        const parent = btn.closest('.xf-editor');
        if (parent) editor = parent.querySelector('.xf-editor-area');
    }
    if (!editor) editor = document.querySelector('.xf-editor-area');
    if (editor) editor.focus();
    document.execCommand(name, false, value);
    if (editor) moveCursorToEnd(editor);
}

function addEditorLink(btn) {
    const url = prompt("Link giriniz:", "https://");
    if (url) editorCmd('createLink', url, btn);
}

function insertImageLink(btn) {
    const url = prompt("Resim URL'sini yapıştırın:", "https://");
    if (url) editorCmd('insertImage', url, btn);
}

function addSpoiler(btn) {
    const text = prompt("Gizlenecek metni girin:");
    if (text) {
        const html = `<div class="xf-spoiler" style="background:var(--bs-tertiary-bg); border:1px solid var(--bs-border-color); padding:10px; cursor:pointer; border-radius:6px; margin-bottom: 10px;">
                        <span class="spoiler-hint" style="font-weight:bold;"><i class="fas fa-eye-slash me-2"></i>Sürprizbozan (Görmek için tıkla)</span>
                        <div class="spoiler-content" style="display:none; margin-top:8px; border-top:1px dashed var(--bs-border-color); padding-top:8px;">${text}</div>
                      </div><p><br></p>`;
        editorCmd('insertHTML', html, btn);
    }
}

function toggleEmojiMenu(btn) {
    const parent = btn.closest('.emoji-dropdown');
    if (!parent) return;
    const menu = parent.querySelector('.emoji-menu');
    if (menu) menu.classList.toggle('active');
}

function insertFasEmoji(iconClass, btn) {
    const iconHTML = `<i class="fas ${iconClass}"></i>&nbsp;`;
    editorCmd('insertHTML', iconHTML, btn);
    const parent = btn.closest('.emoji-dropdown');
    if (parent) {
        const menu = parent.querySelector('.emoji-menu');
        if (menu) menu.classList.remove('active');
    }
}

// Mentions logic
document.addEventListener('input', (e) => {
    if (!e.target.classList.contains('xf-editor-area')) return;
    const editor = e.target;
    const selection = window.getSelection();
    if (!selection.rangeCount) return;
    const range = selection.getRangeAt(0);
    const cursorContent = range.startContainer.textContent.substring(0, range.startOffset);
    const lastAt = cursorContent.lastIndexOf('@');
    if (lastAt !== -1 && (lastAt === 0 || cursorContent[lastAt - 1] === ' ' || cursorContent[lastAt - 1] === '\n')) {
        const query = cursorContent.substring(lastAt + 1);
        if (!query.includes(' ')) {
            showMentionDropdown(editor, range, query);
            return;
        }
    }
    hideMentionDropdown();
});

async function showMentionDropdown(editor, range, query) {
    let dropdown = document.getElementById('mentionDropdown');
    if (!dropdown) {
        dropdown = document.createElement('div');
        dropdown.id = 'mentionDropdown';
        dropdown.className = 'mention-dropdown';
        document.body.appendChild(dropdown);
    }
    const rect = range.getBoundingClientRect();
    dropdown.style.left = `${rect.left + window.scrollX}px`;
    dropdown.style.top = `${rect.bottom + window.scrollY + 5}px`;
    dropdown.style.display = 'block';

    const formData = new FormData();
    formData.append('action', 'search_users');
    formData.append('q', query);
    const result = await sendRequest(formData);
    if (result.success && result.data.length > 0) {
        dropdown.innerHTML = result.data.map(user => `
            <div class="mention-item" onmousedown='event.preventDefault(); insertMention(${JSON.stringify(user.username)}, ${user.id})'>
                <i class="fas fa-user-circle me-1"></i> @${user.username} 
            </div>
        `).join('');
    } else {
        hideMentionDropdown();
    }
}

function hideMentionDropdown() {
    const dropdown = document.getElementById('mentionDropdown');
    if (dropdown) dropdown.style.display = 'none';
}

function insertMention(username, id) {
    const selection = window.getSelection();
    if (!selection.rangeCount) return;
    const range = selection.getRangeAt(0);
    const node = range.startContainer;
    const lastAt = node.textContent.lastIndexOf('@', range.startOffset - 1);
    if (lastAt !== -1) {
        const editor = node.parentElement.closest('.xf-editor-area');
        if (editor) editor.focus();
        const profileUrl = (typeof BASE_URL !== 'undefined') ? BASE_URL + 'php/profile.php?id=' + id : 'php/profile.php?id=' + id;
        const mentionHTML = `<a href="${profileUrl}" class="mention-tag" contenteditable="false">@${username}</a>&nbsp;`;
        range.setStart(node, lastAt);
        range.deleteContents();
        editorCmd('insertHTML', mentionHTML);
        hideMentionDropdown();
        if (editor) moveCursorToEnd(editor);
    }
}

// --- Initialization ---
document.addEventListener('DOMContentLoaded', () => {
    try { document.execCommand('defaultParagraphSeparator', false, 'p'); } catch (e) { }

    document.addEventListener('click', (e) => {
        // Spoiler Toggle
        const spoiler = e.target.closest('.xf-spoiler');
        if (spoiler) spoiler.classList.toggle('active');

        // Emoji Menu Close
        if (!e.target.closest('.emoji-dropdown')) {
            const menu = document.querySelector('.emoji-menu.active');
            if (menu) menu.classList.remove('active');
        }
    });

    window.addEventListener('mousedown', (e) => {
        if (!e.target.closest('.mention-dropdown')) hideMentionDropdown();
    });
});
