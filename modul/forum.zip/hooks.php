<?php
declare(strict_types=1);

/**
 * Forum Module Hooks
 */

// Inject Notification Icon and JS into themes
add_hook('after_navbar', function () {
    if (!isset($_SESSION['user_id']))
        return;

    require_once __DIR__ . '/forum-func.php';
    $unreadCount = getUnreadNotificationCount((int) $_SESSION['user_id']);

    ?>
    <style>
        .forum-noti-wrapper {
            position: relative;
            display: inline-block;
            margin-right: 15px;
        }

        .forum-noti-btn {
            background: none;
            border: none;
            color: inherit;
            padding: 5px;
            cursor: pointer;
            position: relative;
            transition: transform 0.2s;
        }

        .forum-noti-btn:hover {
            transform: scale(1.1);
            color: var(--bs-primary);
        }

        .forum-noti-badge {
            position: absolute;
            top: -2px;
            right: -2px;
            background: #dc3545;
            color: white;
            font-size: 10px;
            padding: 2px 5px;
            border-radius: 10px;
            border: 2px solid var(--bs-body-bg);
        }

        .forum-noti-dropdown {
            position: absolute;
            top: 100%;
            right: 0;
            width: 320px;
            background: var(--bs-card-bg);
            border: 1px solid var(--bs-border-color);
            border-radius: 8px;
            box-shadow: var(--bs-box-shadow);
            display: none;
            z-index: 1070;
            margin-top: 10px;
            overflow: hidden;
        }

        .forum-noti-dropdown.active {
            display: block;
            animation: forumFadeIn 0.2s ease-out;
        }

        .forum-noti-header {
            padding: 12px 15px;
            border-bottom: 1px solid var(--bs-border-color);
            font-weight: bold;
            background: var(--bs-tertiary-bg);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .forum-noti-list {
            max-height: 350px;
            overflow-y: auto;
        }

        .forum-noti-item {
            padding: 12px 15px;
            border-bottom: 1px solid var(--bs-border-color);
            display: flex;
            text-decoration: none !important;
            color: inherit !important;
            transition: background 0.2s;
        }

        .forum-noti-item:hover {
            background: rgba(var(--bs-primary-rgb), 0.05);
        }

        .forum-noti-item.unread {
            background: rgba(var(--bs-primary-rgb), 0.02);
            border-left: 3px solid var(--bs-primary);
        }

        .forum-noti-avatar {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            background: var(--bs-secondary-bg);
            margin-right: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .forum-noti-content {
            font-size: 13px;
            line-height: 1.4;
        }

        .forum-noti-footer {
            padding: 10px;
            text-align: center;
            border-top: 1px solid var(--bs-border-color);
            background: var(--bs-tertiary-bg);
        }

        @keyframes forumFadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const navRight = document.querySelector('.user-profile-nav');
            if (!navRight) return;

            const notiWrapper = document.createElement('div');
            notiWrapper.className = 'forum-noti-wrapper';
            notiWrapper.innerHTML = `
                <button class="forum-noti-btn" id="forum-noti-toggle" title="Bildirimler">
                    <i class="far fa-bell fs-5"></i>
                    <span class="forum-noti-badge" id="forum-noti-unread" style="display: ${<?= (int) $unreadCount ?> > 0 ? 'block' : 'none'}">${<?= (int) $unreadCount ?>}</span>
                </button>
                <div class="forum-noti-dropdown" id="forum-noti-dropdown">
                    <div class="forum-noti-header">
                        <span>Bildirimler</span>
                        <button class="btn btn-link btn-sm text-decoration-none p-0" id="forum-noti-mark-all">Hepsini Oku</button>
                    </div>
                    <div class="forum-noti-list" id="forum-noti-list">
                        <div class="p-4 text-center text-muted small"><i class="fas fa-circle-notch fa-spin me-2"></i>Yükleniyor...</div>
                    </div>
                </div>
            `;
            navRight.prepend(notiWrapper);

            const toggle = document.getElementById('forum-noti-toggle');
            const dropdown = document.getElementById('forum-noti-dropdown');

            toggle.addEventListener('click', function (e) {
                e.stopPropagation();
                dropdown.classList.toggle('active');
                if (dropdown.classList.contains('active')) {
                    loadNotifications();
                }
            });

            document.addEventListener('click', () => dropdown.classList.remove('active'));
            dropdown.addEventListener('click', (e) => e.stopPropagation());

            async function loadNotifications() {
                const list = document.getElementById('forum-noti-list');
                const formData = new FormData();
                formData.append('action', 'get_notifications');

                try {
                    const actionUrl = (typeof BASE_URL !== 'undefined') ? BASE_URL + 'modules/forum/forum-action.php' : 'modules/forum/forum-action.php';
                    const response = await fetch(actionUrl, { method: 'POST', body: formData });
                    const res = await response.json();
                    if (res.success) {
                        renderNotifications(res.data.list);
                        document.getElementById('forum-noti-unread').textContent = res.data.unread;
                        document.getElementById('forum-noti-unread').style.display = res.data.unread > 0 ? 'block' : 'none';
                    }
                } catch (err) {
                    list.innerHTML = '<div class="p-3 text-center text-danger small">Hata oluştu.</div>';
                }
            }

            function renderNotifications(items) {
                const list = document.getElementById('forum-noti-list');
                if (items.length === 0) {
                    list.innerHTML = '<div class="p-4 text-center text-muted small">Henüz bildirim yok.</div>';
                    return;
                }

                list.innerHTML = items.map(n => {
                    let msg = '';
                    let icon = '';
                    if (n.type === 'mention') { msg = `<b>@${n.username}</b> bir mesajda senden bahsetti.`; icon = 'fa-at text-primary'; }
                    else if (n.type === 'reaction') { msg = `<b>@${n.username}</b> mesajına tepki verdi.`; icon = 'fa-heart text-danger'; }
                    else if (n.type === 'reply') { msg = `<b>@${n.username}</b> konuna cevap yazdı: <i>${n.topic_title}</i>`; icon = 'fa-reply text-success'; }

                    const perPage = 10;
                    const pageNum = Math.ceil((n.post_rank || 1) / perPage);
                    const forumUrl = (typeof BASE_URL !== 'undefined') ? BASE_URL + '?page=forum&topic_id=' + n.topic_id + '&p=' + pageNum : '?page=forum&topic_id=' + n.topic_id + '&p=' + pageNum;
                    return `
                        <a href="${forumUrl}#post-${n.post_id}" 
                           data-page="forum&topic_id=${n.topic_id}&p=${pageNum}"
                           class="forum-noti-item ${n.is_read == 0 ? 'unread' : ''}"
                           onclick="markAsRead(${n.id})">
                            <div class="forum-noti-avatar">
                                <i class="fas ${n.avatar_url || 'fa-user'}"></i>
                            </div>
                            <div class="forum-noti-content">
                                <div>${msg}</div>
                                <div class="text-muted extra-small mt-1">${new Date(n.created_at).toLocaleString()}</div>
                            </div>
                        </a>
                    `;
                }).join('');
            }

            window.markAsRead = function (id) {
                const formData = new FormData();
                formData.append('action', 'mark_notification_read');
                formData.append('id', id);
                const actionUrl = (typeof BASE_URL !== 'undefined') ? BASE_URL + 'modules/forum/forum-action.php' : 'modules/forum/forum-action.php';

                if (navigator.sendBeacon) {
                    navigator.sendBeacon(actionUrl, formData);
                } else {
                    fetch(actionUrl, { method: 'POST', body: formData, keepalive: true });
                }
            };

            document.getElementById('forum-noti-mark-all').addEventListener('click', async function () {
                const formData = new FormData();
                formData.append('action', 'mark_notifications_read');
                const actionUrl = (typeof BASE_URL !== 'undefined') ? BASE_URL + 'modules/forum/forum-action.php' : 'modules/forum/forum-action.php';
                await fetch(actionUrl, { method: 'POST', body: formData });
                loadNotifications();
            });
        });
    </script>
    <?php
});
