<?php
declare(strict_types=1);

/**
 * Forum Module Hooks
 */

// Inject Notification Icon and JS into themes
add_hook('after_navbar', function () {
    if (!isset($_SESSION['user_id']))
        return;

    require_once __DIR__ . '/forum-func.php';
    $unreadCount = getUnreadNotificationCount((int) $_SESSION['user_id']);
    ?>
    <script>
        window.forumUnreadCount = <?= (int) $unreadCount ?>;
    </script>
    <?php
});
