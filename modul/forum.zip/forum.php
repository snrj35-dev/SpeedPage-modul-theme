<?php
require_once 'lang.php';
require_once 'forum-func.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$boardId = isset($_GET['board_id']) ? (int) $_GET['board_id'] : 0;
$topicId = isset($_GET['topic_id']) ? (int) $_GET['topic_id'] : 0;
$userId = $_SESSION['user_id'] ?? 0;
$username = $_SESSION['username'] ?? '';
$userRole = $_SESSION['role'] ?? 'user';

// Fetch Helper
function fetchOne($sql, $params)
{
    global $db;
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetch();
}

function renderPagination($totalItems, $perPage, $currentPage, $baseUrl)
{
    $totalPages = ceil($totalItems / $perPage);
    if ($totalPages <= 1)
        return '';

    $html = '<nav aria-label="Page navigation" class="my-4"><ul class="pagination justify-content-center">';

    // Previous
    $prevClass = ($currentPage <= 1) ? 'disabled' : '';
    $prevUrl = $baseUrl . '&p=' . ($currentPage - 1);
    $html .= '<li class="page-item ' . $prevClass . '"><a class="page-link" href="' . $prevUrl . '" data-page="' . str_replace('?page=', '', $prevUrl) . '">&laquo;</a></li>';

    for ($i = 1; $i <= $totalPages; $i++) {
        $activeClass = ($i == $currentPage) ? 'active' : '';
        $url = $baseUrl . '&p=' . $i;
        $html .= '<li class="page-item ' . $activeClass . '"><a class="page-link" href="' . $url . '" data-page="' . str_replace('?page=', '', $url) . '">' . $i . '</a></li>';
    }

    // Next
    $nextClass = ($currentPage >= $totalPages) ? 'disabled' : '';
    $nextUrl = $baseUrl . '&p=' . ($currentPage + 1);
    $html .= '<li class="page-item ' . $nextClass . '"><a class="page-link" href="' . $nextUrl . '" data-page="' . str_replace('?page=', '', $nextUrl) . '">&raquo;</a></li>';

    $html .= '</ul></nav>';
    return $html;
}

function renderEditor($name = 'content', $placeholder = '')
{
    global $lang;
    ?>
    <div class="xf-editor">
        <div class="xf-toolbar">
            <button type="button" class="xf-btn" onclick="editorCmd('bold', null, this)" title="Kalın"><i
                    class="fas fa-bold"></i></button>
            <button type="button" class="xf-btn" onclick="editorCmd('italic', null, this)" title="İtalik"><i
                    class="fas fa-italic"></i></button>
            <button type="button" class="xf-btn" onclick="editorCmd('underline', null, this)" title="Altı Çizili"><i
                    class="fas fa-underline"></i></button>
            <button type="button" class="xf-btn" onclick="editorCmd('strikeThrough', null, this)" title="Üstü Çizili"><i
                    class="fas fa-strikethrough"></i></button>

            <div class="xf-divider"></div>

            <button type="button" class="xf-btn" onclick="editorCmd('justifyLeft', null, this)"><i
                    class="fas fa-align-left"></i></button>
            <button type="button" class="xf-btn" onclick="editorCmd('justifyCenter', null, this)"><i
                    class="fas fa-align-center"></i></button>

            <div class="xf-divider"></div>

            <button type="button" class="xf-btn" onclick="editorCmd('insertUnorderedList', null, this)"><i
                    class="fas fa-list-ul"></i></button>
            <button type="button" class="xf-btn" onclick="addEditorLink(this)"><i class="fas fa-link"></i></button>
            <button type="button" class="xf-btn" onclick="insertImageLink(this)" title="Resim URL'si Ekle">
                <i class="fas fa-image"></i>
            </button>
            <button type="button" class="xf-btn" onclick="editorCmd('formatBlock', 'blockquote', this)"><i
                    class="fas fa-quote-right"></i></button>
            <button type="button" class="xf-btn" onclick="editorCmd('formatBlock', 'pre', this)"><i
                    class="fas fa-code"></i></button>
            <button type="button" class="xf-btn" onclick="addSpoiler(this)" title="Spoiler Ekle"><i
                    class="fas fa-eye-slash"></i></button>

            <div class="xf-divider"></div>

            <div class="emoji-dropdown">
                <button class="xf-btn" onclick="toggleEmojiMenu(this)" type="button" title="Emoji Seç">
                    <i class="far fa-smile"></i>
                </button>
                <div class="emoji-menu" id="emojiMenu">
                    <?php
                    $emojis = ['fa-smile', 'fa-laugh', 'fa-smile-wink', 'fa-heart', 'fa-thumbs-up', 'fa-thumbs-down', 'fa-fire', 'fa-rocket'];
                    foreach ($emojis as $emo): ?>
                        <i class="fas <?= $emo ?>" onclick="insertFasEmoji('<?= $emo ?>', this)"></i>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <div class="xf-editor-area" contenteditable="true" data-placeholder="<?= e($placeholder) ?>"></div>
        <input type="hidden" name="<?= e($name) ?>" required>
    </div>
    <?php
}


// VIEW: TOPIC (Show Posts)
if ($topicId > 0) {
    $topic = fetchOne("SELECT * FROM forum_topics WHERE id = ?", [$topicId]);
    if (!$topic)
        die("Konu bulunamadı.");
    $board = fetchOne("SELECT * FROM forum_boards WHERE id = ?", [$topic['board_id']]);

    // Increase view count
    $db->prepare("UPDATE forum_topics SET views = views + 1 WHERE id = ?")->execute([$topicId]);

    $perPage = 10;
    $currentPage = isset($_GET['p']) ? max(1, (int) $_GET['p']) : 1;
    $offset = ($currentPage - 1) * $perPage;

    // Total post count for pagination
    $stmt = $db->prepare("SELECT COUNT(*) FROM forum_posts WHERE topic_id = ?");
    $stmt->execute([$topicId]);
    $totalPosts = $stmt->fetchColumn();

    $posts = $db->prepare("SELECT p.*, u.username, u.avatar_url, u.role FROM forum_posts p LEFT JOIN users u ON p.user_id = u.id WHERE p.topic_id = ? ORDER BY p.created_at ASC LIMIT $perPage OFFSET $offset");
    $posts->execute([$topicId]);
    $posts = $posts->fetchAll();

    $pageTitle = e($topic['title']);
    $view = 'topic';

    // VIEW: BOARD (Show Topics)
} elseif ($boardId > 0) {
    $board = fetchOne("SELECT * FROM forum_boards WHERE id = ?", [$boardId]);
    if (!$board)
        die("Pano bulunamadı.");

    $perPage = 15;
    $currentPage = isset($_GET['p']) ? max(1, (int) $_GET['p']) : 1;
    $offset = ($currentPage - 1) * $perPage;

    // Total topics for pagination
    $stmt = $db->prepare("SELECT COUNT(*) FROM forum_topics WHERE board_id = ?");
    $stmt->execute([$boardId]);
    $totalTopics = $stmt->fetchColumn();

    $topics = $db->prepare("SELECT t.*, u.username FROM forum_topics t LEFT JOIN users u ON t.user_id = u.id WHERE t.board_id = ? ORDER BY t.is_sticky DESC, t.created_at DESC LIMIT $perPage OFFSET $offset");
    $topics->execute([$boardId]);
    $topics = $topics->fetchAll();

    $pageTitle = e($board['title']);
    $view = 'board';

    // VIEW: HOME (Show Categories & Boards)
} else {
    $categories = $db->query("SELECT * FROM forum_categories ORDER BY sort_order ASC")->fetchAll();
    $boards = $db->query("SELECT * FROM forum_boards ORDER BY sort_order ASC")->fetchAll();
    $pageTitle = $lang['forum_home'];
    $view = 'home';
}
?>

<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="?page=forum" data-page="forum"><?= $lang['forum_home'] ?></a></li>
            <?php if ($view == 'board'): ?>
                <li class="breadcrumb-item active" aria-current="page"><?= e($board['title']) ?></li>
            <?php elseif ($view == 'topic'): ?>
                <li class="breadcrumb-item"><a href="?page=forum&board_id=<?= $board['id'] ?>"
                        data-page="forum&board_id=<?= $board['id'] ?>"><?= e($board['title']) ?></a></li>
                <li class="breadcrumb-item active" aria-current="page"><?= e($topic['title']) ?></li>
            <?php endif; ?>
        </ol>
    </nav>

    <!-- HOME VIEW -->
    <?php if ($view == 'home'): ?>
        <?php foreach ($categories as $cat): ?>
            <div class="card mb-4 shadow-sm">
                <div class="card-header  fw-bold text-primary">
                    <?= e($cat['title']) ?>
                </div>
                <div class="list-group list-group-flush">
                    <?php
                    $catBoards = array_filter($boards, fn($b) => $b['category_id'] == $cat['id']);
                    foreach ($catBoards as $boardItem):
                        ?>
                        <div class="list-group-item d-flex justify-content-between align-items-center p-3">
                            <div class="d-flex align-items-center">
                                <div class="me-3 text-secondary">
                                    <i class="fas fa-comments fa-2x"></i>
                                </div>
                                <div>
                                    <h5 class="mb-1"><a href="?page=forum&board_id=<?= $boardItem['id'] ?>"
                                            data-page="forum&board_id=<?= $boardItem['id'] ?>"
                                            class="text-decoration-none"><?= e($boardItem['title']) ?></a>
                                    </h5>
                                    <small class="text"><?= e($boardItem['description']) ?></small>
                                </div>
                            </div>
                            <div class="text-end text small">
                                <div><i class="fas fa-file-alt"></i> <?= $boardItem['topic_count'] ?> Konu</div>
                                <div><i class="fas fa-comment"></i> <?= $boardItem['post_count'] ?> Mesaj</div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <!-- BOARD VIEW -->
    <?php if ($view == 'board'): ?>
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h1><?= e($board['title']) ?></h1>
            <?php if ($userId): ?>
                <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#newTopicModal">
                    <i class="fas fa-plus"></i> <?= $lang['forum_new_topic'] ?>
                </button>
            <?php endif; ?>
        </div>

        <div class="topic-list-container card shadow-sm">
            <!-- Header (Mobile'da gizli) -->
            <div class="topic-header d-none d-md-flex p-3 fw-bold border-bottom">
                <div class="flex-grow-1"><?= $lang['forum_topics'] ?></div>
                <div class="text-center" style="width: 150px;">Yazar</div>
                <div class="text-center" style="width: 100px;">Görüntüleme</div>
                <div class="text-end" style="width: 150px;">Tarih</div>
            </div>

            <div class="topic-body">
                <?php if (empty($topics)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-folder-open fa-3x text-muted mb-3 d-block"></i>
                        <?= $lang['forum_no_topics'] ?>
                    </div>
                <?php else: ?>
                    <?php foreach ($topics as $t): ?>
                        <div
                            class="topic-row d-flex align-items-center p-3 border-bottom <?= $t['is_sticky'] ? 'topic-sticky' : '' ?> <?= $t['is_locked'] ? 'topic-locked' : '' ?>">
                            <!-- Konu Bilgisi -->
                            <div class="flex-grow-1 pe-3">
                                <div class="d-flex align-items-center mb-1">
                                    <?php if ($t['is_sticky']): ?><i class="fas fa-thumbtack text-danger me-2" title="Sabit"></i>
                                    <?php endif; ?>
                                    <?php if ($t['is_locked']): ?><i class="fas fa-lock text-muted me-2" title="Kilitli"></i>
                                    <?php endif; ?>
                                    <a href="?page=forum&topic_id=<?= $t['id'] ?>" data-page="forum&topic_id=<?= $t['id'] ?>"
                                        class="fw-bold text-decoration-none topic-link h5 mb-0 d-block"><?= e($t['title']) ?></a>
                                </div>
                                <div class="small text-muted d-md-none">
                                    <i class="fas fa-user me-1"></i> <a
                                        href="<?= BASE_URL ?>php/profile.php?id=<?= $t['user_id'] ?>"
                                        class="text-decoration-none text-muted"><?= e($t['username'] ?? 'Silinmiş Üye') ?></a>
                                    <span class="mx-1">•</span>
                                    <i class="fas fa-clock me-1"></i> <?= date('d.m.Y', strtotime($t['created_at'])) ?>
                                </div>
                            </div>

                            <!-- Yazar (Desktop) -->
                            <div class="text-center d-none d-md-block" style="width: 150px;">
                                <div class="fw-medium text-truncate"><a
                                        href="<?= BASE_URL ?>php/profile.php?id=<?= $t['user_id'] ?>"
                                        class="text-decoration-none text-body"><?= e($t['username'] ?? 'Silinmiş Üye') ?></a></div>
                            </div>

                            <!-- Görüntüleme (Desktop) -->
                            <div class="text-center d-none d-md-block" style="width: 100px;">
                                <span class="badge rounded-pill bg-tertiary text-body border"><?= $t['views'] ?></span>
                            </div>

                            <!-- Tarih (Desktop) -->
                            <div class="text-end d-none d-md-block small text-muted" style="width: 150px;">
                                <div><?= date('d.m.Y', strtotime($t['created_at'])) ?></div>
                                <div><?= date('H:i', strtotime($t['created_at'])) ?></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <?php if (!empty($topics)): ?>
                <div class="p-3">
                    <?= renderPagination((int) $totalTopics, $perPage, $currentPage, "?page=forum&board_id=" . $board['id']) ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- New Topic Modal -->
        <div class="modal fade" id="newTopicModal" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title"><?= $lang['forum_new_topic'] ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <form onsubmit="handleForm(event, 'add_topic')">
                            <input type="hidden" name="board_id" value="<?= $board['id'] ?>">
                            <div class="mb-3">
                                <label class="form-label"><?= $lang['forum_title'] ?></label>
                                <input type="text" name="title" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label"><?= $lang['forum_content'] ?></label>
                                <?php renderEditor('content', $lang['forum_content']); ?>
                            </div>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary"><?= $lang['forum_save'] ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- TOPIC VIEW -->
    <?php if ($view == 'topic'): ?>
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>
                <?php if ($topic['is_sticky']): ?><i class="fas fa-thumbtack text-danger"></i> <?php endif; ?>
                <?php if ($topic['is_locked']): ?><i class="fas fa-lock text-muted"></i> <?php endif; ?>
                <?= e($topic['title']) ?>
            </h2>
            <?php if ($userRole === 'admin'): ?>
                <div>
                    <?php
                    $lockIcon = $topic['is_locked'] ? 'fa-unlock' : 'fa-lock';
                    $lockText = $topic['is_locked'] ? $lang['forum_unlock'] : $lang['forum_lock'];
                    $lockType = $topic['is_locked'] ? 'btn-outline-secondary' : 'btn-outline-warning';

                    $stickyIcon = $topic['is_sticky'] ? 'fa-thumbtack' : 'fa-thumbtack';
                    $stickyText = $topic['is_sticky'] ? $lang['forum_unsticky'] : $lang['forum_sticky'];
                    $stickyType = $topic['is_sticky'] ? 'btn-outline-secondary' : 'btn-outline-danger';
                    ?>
                    <button class="btn btn-sm <?= $lockType ?>" onclick="toggleAction('toggle_lock', <?= $topic['id'] ?>)">
                        <i class="fas <?= $lockIcon ?>"></i> <?= $lockText ?>
                    </button>
                    <button class="btn btn-sm <?= $stickyType ?>" onclick="toggleAction('toggle_sticky', <?= $topic['id'] ?>)">
                        <i class="fas <?= $stickyIcon ?>"></i> <?= $stickyText ?>
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="deleteItem('delete_topic', <?= $topic['id'] ?>)">
                        <i class="fas fa-trash"></i> <?= $lang['forum_delete_topic'] ?>
                    </button>
                </div>
            <?php endif; ?>
        </div>

        <?php foreach ($posts as $post): ?>
            <div class="card mb-3 shadow-sm" id="post-<?= $post['id'] ?>">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center">
                        <!-- Avatar -->
                        <div class="me-3 text-center" style="width: 40px;">
                            <i class="fas <?= $post['avatar_url'] ?? 'fa-user-circle' ?> fa-2x text-secondary"></i>
                        </div>
                        <div>
                            <span class="fw-bold d-block"><a href="<?= BASE_URL ?>php/profile.php?id=<?= $post['user_id'] ?>"
                                    class="text-decoration-none text-body"><?= e($post['username'] ?? 'Silinmiş Üye') ?></a></span>
                            <?php
                            $role = strtolower($post['role'] ?? 'user');
                            $badgeClass = 'rank-' . $role;
                            ?>
                            <span class="rank-badge <?= $badgeClass ?>"><?= e(ucfirst($post['role'] ?? 'User')) ?></span>
                        </div>
                    </div>
                    <div class="text-end">
                        <small class="text-muted d-block"><i class="far fa-clock"></i>
                            <?= date('d.m.Y H:i', strtotime($post['created_at'])) ?>
                        </small>
                        <?php if ($userId): ?>
                            <div class="mt-1">
                                <button class="btn btn-sm btn-link text-decoration-none p-1 me-2"
                                    onclick='quotePost(<?= e(json_encode($post['username'])) ?>, <?= e(json_encode($post['content'])) ?>)'>
                                    <i class="fas fa-quote-right"></i> <?= $lang['forum_quote'] ?>
                                </button>

                                <?php if ($userRole === 'admin' || $userId == $post['user_id']): ?>
                                    <button class="btn btn-sm btn-link text-primary text-decoration-none p-1 me-2"
                                        onclick='editPost(<?= (int) $post['id'] ?>, <?= e(json_encode($post['content'])) ?>)'>
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-link text-danger text-decoration-none p-1"
                                        onclick="deleteItem('delete_post', <?= $post['id'] ?>)">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body">
                    <div class="post-content">
                        <?= clean_forum_content($post['content']) ?>
                    </div>
                    <?php if ($post['updated_at']): ?>
                        <div class="mt-2 text-muted small fst-italic">
                            Düzenlendi: <?= date('d.m.Y H:i', strtotime($post['updated_at'])) ?>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="post-footer">
                    <div class="reactions-bar" id="reactions-<?= $post['id'] ?>">
                        <?php
                        $reactions = getPostReactions($post['id']);
                        $userReaction = getUserReaction($post['id'], $userId);
                        foreach ($reactions as $r):
                            $isActive = ($userReaction === $r['reaction']);
                            ?>
                            <div class="reaction-pill <?= $isActive ? 'active' : '' ?>"
                                onclick="toggleReaction(<?= $post['id'] ?>, '<?= e($r['reaction']) ?>')">
                                <?= e($r['reaction']) ?> <small><?= $r['count'] ?></small>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <?php if ($userId): ?>
                        <div class="reaction-picker-container">
                            <button class="btn btn-sm btn-link text-decoration-none p-0 text-secondary">
                                <i class="far fa-smile"></i> Tepki Ver
                            </button>
                            <div class="reaction-picker">
                                <span class="reaction-opt" onclick="toggleReaction(<?= $post['id'] ?>, '👍')">👍</span>
                                <span class="reaction-opt" onclick="toggleReaction(<?= $post['id'] ?>, '❤️')">❤️</span>
                                <span class="reaction-opt" onclick="toggleReaction(<?= $post['id'] ?>, '😂')">😂</span>
                                <span class="reaction-opt" onclick="toggleReaction(<?= $post['id'] ?>, '😮')">😮</span>
                                <span class="reaction-opt" onclick="toggleReaction(<?= $post['id'] ?>, '😢')">😢</span>
                                <span class="reaction-opt" onclick="toggleReaction(<?= $post['id'] ?>, '🔥')">🔥</span>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>

        <?php if (!empty($posts)): ?>
            <div class="p-3">
                <?= renderPagination((int) $totalPosts, $perPage, $currentPage, "?page=forum&topic_id=" . $topic['id']) ?>
            </div>
        <?php endif; ?>

        <?php if ($userId): ?>
            <?php if ($topic['is_locked'] && $userRole !== 'admin'): ?>
                <div class="alert alert-secondary mt-4">
                    <i class="fas fa-lock"></i> <?= $lang['forum_topic_locked'] ?>
                </div>
            <?php else: ?>
                <!-- Reply Form -->
                <div class="card mt-4 shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title mb-3"><?= $lang['forum_reply'] ?></h5>
                        <form onsubmit="handleForm(event, 'add_post')">
                            <input type="hidden" name="topic_id" value="<?= $topic['id'] ?>">
                            <div class="mb-4">
                                <?php renderEditor('content', $lang['forum_content']); ?>
                            </div>
                            <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i>
                                <?= $lang['forum_reply'] ?></button>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="alert alert-info mt-4">
                <i class="fas fa-info-circle"></i> <?= $lang['forum_login_required'] ?> <a href="login.php">Giriş Yap</a>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <!-- Edit Post Modal -->
    <div class="modal fade" id="editPostModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?= $lang['forum_edit_post'] ?? 'Mesajı Düzenle' ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form onsubmit="handleForm(event, 'update_post')">
                        <input type="hidden" name="id" id="edit-post-id">
                        <div class="mb-4">
                            <?php renderEditor('content', $lang['forum_content']); ?>
                        </div>
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary"><?= $lang['forum_save'] ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>