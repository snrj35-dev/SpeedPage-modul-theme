/* ======================================================
   FORUM FRONTEND PAGE JS (pageassets)
   ====================================================== */
console.log("forum.js loading...");

// Define functions first
async function editPost(id, oldContent) {
    const modalEl = document.getElementById('editPostModal');
    if (!modalEl) return;
    let decodedContent = '';
    try { decodedContent = JSON.parse(oldContent); } catch (e) { decodedContent = oldContent; }
    document.getElementById('edit-post-id').value = id;
    const editor = modalEl.querySelector('.xf-editor-area');
    if (editor) editor.innerHTML = decodedContent;
    const modal = new bootstrap.Modal(modalEl);
    modal.show();
}

function quotePost(username, content) {
    const parser = new DOMParser();
    const decodedContent = parser.parseFromString(content, 'text/html').documentElement.textContent;
    const quoteHTML = `<blockquote class="border-start border-primary border-4 ps-3 py-2 mb-3 bg-tertiary"><strong>${username}</strong> dedi ki:<br>${decodedContent}</blockquote><p><br></p>`;
    const editor = document.querySelector('.xf-editor-area');
    if (editor) {
        editor.innerHTML += quoteHTML;
        editor.focus();
        editor.scrollIntoView();
    }
}

async function toggleReaction(postId, reaction) {
    const formData = new FormData();
    formData.append('action', 'toggle_reaction');
    formData.append('post_id', postId);
    formData.append('reaction', reaction);
    const result = await sendRequest(formData);
    if (result.success) { forumRedirect(); } else { alert(result.message); }
}

async function deleteItem(action, id) {
    const confirmMsg = (typeof lang !== 'undefined' && lang['forum_confirm_delete'])
        ? lang['forum_confirm_delete']
        : 'Bu öğeyi silmek istediğinize emin misiniz?';
    if (!confirm(confirmMsg)) return;
    const formData = new FormData();
    formData.append('action', action);
    formData.append('id', id);
    const result = await sendRequest(formData);
    if (result.success) { forumRedirect(); } else { alert(result.message); }
}

async function toggleAction(action, id) {
    const formData = new FormData();
    formData.append('action', action);
    formData.append('id', id);
    const result = await sendRequest(formData);
    if (result.success) { forumRedirect(); } else { alert(result.message); }
}

// Export immediately to global scope
window.editPost = editPost;
window.quotePost = quotePost;
window.toggleReaction = toggleReaction;
window.deleteItem = deleteItem;
window.toggleAction = toggleAction;

console.log("forum.js initialized correctly.");
