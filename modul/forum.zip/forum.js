// Helper for AJAX requests
async function sendRequest(formData) {
    try {
        let actionUrl = 'modules/forum/forum-action.php';

        if (typeof BASE_URL !== 'undefined' && BASE_URL) {
            actionUrl = BASE_URL + 'modules/forum/forum-action.php';
        } else if (typeof BASE_PATH !== 'undefined' && BASE_PATH) {
            actionUrl = BASE_PATH + 'modules/forum/forum-action.php';
        }

        const response = await fetch(actionUrl, {
            method: 'POST',
            body: formData
        });

        const text = await response.text();
        try {
            return JSON.parse(text);
        } catch (jsonError) {
            console.error('JSON Parse Error:', jsonError, 'Response Text:', text);
            return { success: false, message: 'Sunucudan geçersiz yanıt alındı.' };
        }
    } catch (error) {
        console.error('Network/Request Error:', error);
        return { success: false, message: 'İletişim hatası oluştu.' };
    }
}

// SPA compatible redirect/reload
function forumRedirect(queryString = '') {
    // If we're in admin panel, just reload
    if (window.location.pathname.includes('/admin/')) {
        window.location.reload();
        return;
    }

    // Determine current page state from URL
    const urlParams = new URLSearchParams(window.location.search);
    let page = urlParams.get('page') || 'forum';

    // If queryString is empty, we try to stay on current view
    if (!queryString) {
        const boardId = urlParams.get('board_id');
        const topicId = urlParams.get('topic_id');
        const p = urlParams.get('p');

        if (topicId) {
            queryString = 'topic_id=' + topicId;
            if (p) queryString += '&p=' + p;
        }
        else if (boardId) {
            queryString = 'board_id=' + boardId;
            if (p) queryString += '&p=' + p;
        }
    }

    const target = page + (queryString ? (queryString.startsWith('&') ? queryString : '&' + queryString) : '');

    if (typeof loadPage === 'function') {
        loadPage(target);
        // Modal cleanup just in case
        const modalEl = document.querySelector('.modal.show');
        if (modalEl) {
            const modal = bootstrap.Modal.getInstance(modalEl);
            if (modal) modal.hide();
            // Remove backdrops manually if bootstrap instance fails
            document.querySelectorAll('.modal-backdrop').forEach(el => el.remove());
            document.body.classList.remove('modal-open');
            document.body.style.overflow = '';
            document.body.style.paddingRight = '';
        }
    } else {
        window.location.href = '?page=' + target;
    }
}

async function handleForm(event, action) {
    event.preventDefault();
    const form = event.target;

    // Sync editor content if exists
    const editorEl = form.querySelector('.xf-editor-area');
    const hiddenInput = form.querySelector('input[name="content"]');
    if (editorEl && hiddenInput) {
        // Editörün gerçekten dolu olup olmadığını kontrol et (Boşlukları temizle ve Resim var mı bak)
        const cleanInner = editorEl.innerText.trim();
        if (cleanInner === '' && !editorEl.querySelector('img') && !editorEl.querySelector('i')) {
            alert('Lütfen bir içerik giriniz.');
            return;
        }
        hiddenInput.value = editorEl.innerHTML;
    }

    const formData = new FormData(form);
    formData.append('action', action);

    const result = await sendRequest(formData);

    if (result.success) {
        if (result.data && result.data.topic_id) {
            const hash = result.data.post_id ? '#post-' + result.data.post_id : '';
            const pageParam = result.data.p ? '&p=' + result.data.p : '';
            forumRedirect('topic_id=' + result.data.topic_id + pageParam + hash);
        } else {
            forumRedirect();
        }
    } else {
        alert(result.message);
    }
}

async function deleteItem(action, id, customWarning = '') {
    const warning = customWarning || 'Bu öğeyi silmek istediğinize emin misiniz?';
    if (!confirm(warning)) return;

    if (customWarning && customWarning.includes('DİKKAT')) {
        const confirmText = prompt('Silmek için "SİL" yazın:');
        if (confirmText !== 'SİL') return;
    }

    const formData = new FormData();
    formData.append('action', action);
    formData.append('id', id);

    const result = await sendRequest(formData);
    if (result.success) {
        forumRedirect();
    } else {
        alert(result.message);
    }
}

async function moveItem(action, id, direction) {
    const formData = new FormData();
    formData.append('action', action);
    formData.append('id', id);
    formData.append('direction', direction);

    const result = await sendRequest(formData);
    if (result.success) {
        forumRedirect();
    } else {
        alert(result.message);
    }
}

async function editBoard(id, oldTitle, oldDesc) {
    const newTitle = prompt('Yeni pano başlığı:', oldTitle);
    if (newTitle === null) return;
    const newDesc = prompt('Yeni pano açıklaması:', oldDesc);
    if (newDesc === null) return;

    const formData = new FormData();
    formData.append('action', 'update_board');
    formData.append('id', id);
    formData.append('title', newTitle);
    formData.append('description', newDesc);

    const result = await sendRequest(formData);
    if (result.success) {
        forumRedirect();
    } else {
        alert(result.message);
    }
}

async function editCategory(id, oldTitle) {
    const newTitle = prompt('Yeni başlık:', oldTitle);
    if (!newTitle || newTitle === oldTitle) return;

    const formData = new FormData();
    formData.append('action', 'update_category');
    formData.append('id', id);
    formData.append('title', newTitle);

    const result = await sendRequest(formData);
    if (result.success) {
        forumRedirect();
    } else {
        alert(result.message);
    }
}

async function toggleAction(action, id) {
    const formData = new FormData();
    formData.append('action', action);
    formData.append('id', id);

    const result = await sendRequest(formData);
    if (result.success) {
        forumRedirect();
    } else {
        alert(result.message);
    }
}

async function editPost(id, oldContent) {
    const modalId = 'editPostModal';
    const modalEl = document.getElementById(modalId);
    if (!modalEl) return;

    // JSON encoded string'i çöz (Hata payına karşı try-catch)
    let decodedContent = '';
    try {
        decodedContent = JSON.parse(oldContent);
    } catch (e) {
        decodedContent = oldContent;
    }

    // Modal içindeki ID ve Editör alanını doldur
    document.getElementById('edit-post-id').value = id;
    const editor = modalEl.querySelector('.xf-editor-area');
    if (editor) {
        editor.innerHTML = decodedContent;
    }

    // Modalı aç
    const modal = new bootstrap.Modal(modalEl);
    modal.show();
}

function quotePost(username, content) {
    const parser = new DOMParser();
    const decodedContent = parser.parseFromString(content, 'text/html').documentElement.textContent;

    const quoteHTML = `<blockquote class="border-start border-primary border-4 ps-3 py-2 mb-3 bg-tertiary"><strong>${username}</strong> dedi ki:<br>${decodedContent}</blockquote><p><br></p>`;

    const editor = document.querySelector('.xf-editor-area');
    if (editor) {
        editor.innerHTML += quoteHTML;
        editor.focus();
        editor.scrollIntoView();
    }
}

// --- WYSIWYG Editor logic ---
function moveCursorToEnd(el) {
    el.focus();
    const selection = window.getSelection();
    if (selection) {
        const range = document.createRange();
        range.selectNodeContents(el);
        range.collapse(false);
        selection.removeAllRanges();
        selection.addRange(range);
    }
}

function editorCmd(name, value = null, btn = null) {
    let editor = null;
    if (btn) {
        const parent = btn.closest('.xf-editor');
        if (parent) editor = parent.querySelector('.xf-editor-area');
    }
    if (!editor) editor = document.querySelector('.xf-editor-area');

    if (editor) editor.focus();
    document.execCommand(name, false, value);
    if (editor) moveCursorToEnd(editor);
}

function addEditorLink(btn) {
    const url = prompt("Link giriniz:", "https://");
    if (url) editorCmd('createLink', url, btn);
}

function insertImageLink(btn) {
    const url = prompt("Resim URL'sini yapıştırın:", "https://");
    if (url) editorCmd('insertImage', url, btn);
}

function addSpoiler(btn) {
    const text = prompt("Gizlenecek metni girin:");
    if (text) {
        const html = `<div class="xf-spoiler" style="background:var(--bs-tertiary-bg); border:1px solid var(--bs-border-color); padding:10px; cursor:pointer; border-radius:6px; margin-bottom: 10px;">
                        <span class="spoiler-hint" style="font-weight:bold;"><i class="fas fa-eye-slash me-2"></i>Sürprizbozan (Görmek için tıkla)</span>
                        <div class="spoiler-content" style="display:none; margin-top:8px; border-top:1px dashed var(--bs-border-color); padding-top:8px;">${text}</div>
                      </div><p><br></p>`;
        editorCmd('insertHTML', html, btn);
    }
}

function toggleEmojiMenu(btn) {
    const parent = btn.closest('.emoji-dropdown');
    if (!parent) return;
    const menu = parent.querySelector('.emoji-menu');
    if (menu) menu.classList.toggle('active');
}

function insertFasEmoji(iconClass, btn) {
    const iconHTML = `<i class="fas ${iconClass}"></i>&nbsp;`;
    editorCmd('insertHTML', iconHTML, btn);
    const parent = btn.closest('.emoji-dropdown');
    if (parent) {
        const menu = parent.querySelector('.emoji-menu');
        if (menu) menu.classList.remove('active');
    }
}

// Initial config
try {
    document.execCommand('defaultParagraphSeparator', false, 'p');
} catch (e) { }

// Close emoji menu on outside click
window.addEventListener('click', (event) => {
    if (!event.target.closest('.emoji-dropdown')) {
        const menu = document.getElementById('emojiMenu');
        if (menu && menu.classList.contains('active')) {
            menu.classList.remove('active');
        }
    }
});

// --- Mentions logic ---
let mentionQuery = '';
let mentionActive = false;

document.addEventListener('input', (e) => {
    if (!e.target.classList.contains('xf-editor-area')) return;

    const editor = e.target;
    const selection = window.getSelection();
    if (!selection.rangeCount) return;

    const range = selection.getRangeAt(0);
    const cursorContent = range.startContainer.textContent.substring(0, range.startOffset);
    const lastAt = cursorContent.lastIndexOf('@');

    if (lastAt !== -1 && (lastAt === 0 || cursorContent[lastAt - 1] === ' ' || cursorContent[lastAt - 1] === '\n')) {
        mentionQuery = cursorContent.substring(lastAt + 1);
        if (!mentionQuery.includes(' ')) {
            mentionActive = true;
            showMentionDropdown(editor, range, mentionQuery);
            return;
        }
    }

    hideMentionDropdown();
});

async function showMentionDropdown(editor, range, query) {
    let dropdown = document.getElementById('mentionDropdown');
    if (!dropdown) {
        dropdown = document.createElement('div');
        dropdown.id = 'mentionDropdown';
        dropdown.className = 'mention-dropdown';
        document.body.appendChild(dropdown);
    }

    // Position dropdown
    const rect = range.getBoundingClientRect();
    dropdown.style.left = `${rect.left + window.scrollX}px`;
    dropdown.style.top = `${rect.bottom + window.scrollY + 5}px`;
    dropdown.style.display = 'block';

    const formData = new FormData();
    formData.append('action', 'search_users');
    formData.append('q', query);

    const result = await sendRequest(formData);
    if (result.success && result.data.length > 0) {
        dropdown.innerHTML = result.data.map(user => `
            <div class="mention-item" onmousedown='event.preventDefault(); insertMention(${JSON.stringify(user.username)}, ${user.id})'>
                <i class="fas fa-user-circle me-1"></i> @${user.username} 
                <small class="text-muted">(${user.display_name || user.username})</small>
            </div>
        `).join('');
    } else {
        hideMentionDropdown();
    }
}

function hideMentionDropdown() {
    const dropdown = document.getElementById('mentionDropdown');
    if (dropdown) dropdown.style.display = 'none';
    mentionActive = false;
}

let lastMentionEditor = null; // Store which editor was active

function insertMention(username, id) {
    const selection = window.getSelection();
    if (!selection.rangeCount) return;

    const range = selection.getRangeAt(0);
    const node = range.startContainer;
    const content = node.textContent;
    const lastAt = content.lastIndexOf('@', range.startOffset - 1);

    if (lastAt !== -1) {
        // Find the editor parent to refocus it
        const editor = node.parentElement.closest('.xf-editor-area');
        if (editor) editor.focus();

        // Create mention tag
        const profileUrl = (typeof BASE_URL !== 'undefined') ? BASE_URL + 'php/profile.php?id=' + id : 'php/profile.php?id=' + id;
        const mentionHTML = `<a href="${profileUrl}" class="mention-tag" contenteditable="false">@${username}</a>&nbsp;`;

        range.setStart(node, lastAt);
        range.deleteContents();

        editorCmd('insertHTML', mentionHTML);
        hideMentionDropdown();
        if (editor) moveCursorToEnd(editor);
    }
}

// Close dropdown on outside click
window.addEventListener('mousedown', (e) => {
    if (!e.target.closest('.mention-dropdown')) {
        hideMentionDropdown();
    }
});

async function toggleReaction(postId, reaction) {
    const formData = new FormData();
    formData.append('action', 'toggle_reaction');
    formData.append('post_id', postId);
    formData.append('reaction', reaction);

    const result = await sendRequest(formData);
    if (result.success) {
        forumRedirect();
    } else {
        alert(result.message);
    }
}

// Pagination Logic is now handled by PHP via standard link clicks.
// Obsolete AJAX load-more functions removed.
// Spoiler Toggle Logic (Global)
document.addEventListener('click', (e) => {
    const spoiler = e.target.closest('.xf-spoiler');
    if (spoiler) {
        spoiler.classList.toggle('active');
    }
});
