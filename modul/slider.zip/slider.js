/**
 * Advanced Slider Module - Vanilla JavaScript
 * Modern, responsive slider with touch support and glassmorphism design
 */

(function () {
    if (typeof window !== 'undefined' && window.AdvancedSlider) {
        return;
    }

class AdvancedSlider {
    constructor(containerId, options = {}) {
        this.container = document.getElementById(containerId);
        if (!this.container) {
            console.error(`Slider container with ID "${containerId}" not found`);
            return;
        }

        // Default settings
        this.settings = {
            autoplay: true,
            autoplaySpeed: 5000,
            transitionSpeed: 800,
            showNavigation: true,
            showDots: true,
            infiniteLoop: true,
            pauseOnHover: true,
            ...options
        };

        // State
        this.slides = [];
        this.currentSlide = 0;
        this.isPlaying = false;
        this.autoplayTimer = null;
        this.isTransitioning = false;
        this.touchStartX = 0;
        this.touchEndX = 0;

        // DOM references (always initialize to safe defaults)
        this.wrapper = null;
        this.slideElements = [];
        this.navButtons = [];
        this.dotButtons = [];

        this.init();
    }

    async init() {
        try {
            await this.loadSlides();
            this.createSliderHTML();
            this.bindEvents();
            this.startAutoplay();
            this.showSlide(0);
        } catch (error) {
            console.error('Slider initialization failed:', error);
            this.showError();
        }
    }

    async loadSlides() {
        try {
            const response = await fetch(BASE_PATH + 'modules/slider/slider-func.php?action=get_slides');
            const data = await response.json();

            if (data.status === 'success') {
                this.slides = Array.isArray(data.slides) ? data.slides : [];
            } else {
                throw new Error(data.message || 'Failed to load slides');
            }
        } catch (error) {
            console.error('Error loading slides:', error);
            this.slides = [];
        }
    }

    createSliderHTML() {
        if (this.slides.length === 0) {
            this.showEmptyState();
            return;
        }

        const sliderHTML = `
            <div class="slider-wrapper">
                ${this.slides.map((slide, index) => `
                    <div class="slider-slide" data-index="${index}">
                        <img src="${slide.image_url}" alt="${slide.title}" loading="lazy">
                        <div class="slider-content">
                            <h2 class="slider-title">${this.escapeHtml(slide.title)}</h2>
                            ${slide.description ? `<p class="slider-description">${this.escapeHtml(slide.description)}</p>` : ''}
                            ${slide.link_url ? `<a href="${slide.link_url}" class="slider-link">Daha Fazla Bilgi</a>` : ''}
                        </div>
                    </div>
                `).join('')}
            </div>
            
            ${this.settings.showNavigation ? `
                <button class="slider-nav prev" aria-label="Previous slide">
                    <i class="fas fa-chevron-left"></i>
                </button>
                <button class="slider-nav next" aria-label="Next slide">
                    <i class="fas fa-chevron-right"></i>
                </button>
            ` : ''}
            
            ${this.settings.showDots ? `
                <div class="slider-dots">
                    ${this.slides.map((_, index) => `
                        <button class="slider-dot" data-index="${index}" aria-label="Go to slide ${index + 1}"></button>
                    `).join('')}
                </div>
            ` : ''}
        `;

        this.container.innerHTML = sliderHTML;
        this.wrapper = this.container.querySelector('.slider-wrapper');
        this.slideElements = this.container.querySelectorAll('.slider-slide');
        this.navButtons = this.container.querySelectorAll('.slider-nav');
        this.dotButtons = this.container.querySelectorAll('.slider-dot');
    }

    showEmptyState() {
        this.container.innerHTML = `
            <div class="slider-empty">
                <i class="fas fa-images"></i>
                <h3>Gösterilecek Resim Yok</h3>
                <p>Slider'da gösterilecek aktif resim bulunmamaktadır.</p>
            </div>
        `;

        this.wrapper = null;
        this.slideElements = [];
        this.navButtons = [];
        this.dotButtons = [];
    }

    showError() {
        this.container.innerHTML = `
            <div class="slider-empty">
                <i class="fas fa-exclamation-triangle"></i>
                <h3>Slider Yüklenemedi</h3>
                <p>Slider verileri yüklenirken bir hata oluştu.</p>
            </div>
        `;

        this.wrapper = null;
        this.slideElements = [];
        this.navButtons = [];
        this.dotButtons = [];
    }

    bindEvents() {
        if (!this.wrapper || !this.container) {
            return;
        }

        // Navigation buttons
        (this.navButtons || []).forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                if (button.classList.contains('prev')) {
                    this.prevSlide();
                } else {
                    this.nextSlide();
                }
            });
        });

        // Dot navigation
        (this.dotButtons || []).forEach(dot => {
            dot.addEventListener('click', (e) => {
                e.preventDefault();
                const index = parseInt(dot.dataset.index);
                this.goToSlide(index);
            });
        });

        // Touch events
        this.wrapper.addEventListener('touchstart', this.handleTouchStart.bind(this), { passive: true });
        this.wrapper.addEventListener('touchend', this.handleTouchEnd.bind(this), { passive: true });

        // Mouse events
        this.wrapper.addEventListener('mousedown', this.handleMouseDown.bind(this));
        this.wrapper.addEventListener('mouseup', this.handleMouseUp.bind(this));
        this.wrapper.addEventListener('mouseleave', this.handleMouseUp.bind(this));

        // Pause on hover
        if (this.settings.pauseOnHover) {
            this.container.addEventListener('mouseenter', this.pauseAutoplay.bind(this));
            this.container.addEventListener('mouseleave', this.startAutoplay.bind(this));
        }

        // Keyboard navigation
        document.addEventListener('keydown', this.handleKeyboard.bind(this));

        // Visibility change
        document.addEventListener('visibilitychange', this.handleVisibilityChange.bind(this));

        // Window resize
        window.addEventListener('resize', this.handleResize.bind(this));
    }

    showSlide(index, direction = 'next') {
        if (this.isTransitioning || this.slides.length === 0) return;
        if (!this.slideElements || this.slideElements.length === 0) return;

        this.isTransitioning = true;

        // Remove active classes
        (this.slideElements || []).forEach(slide => {
            slide.classList.remove('active', 'prev');
        });
        (this.dotButtons || []).forEach(dot => {
            dot.classList.remove('active');
        });

        // Set current slide
        this.currentSlide = index;

        // Add active class with animation
        const currentSlideElement = this.slideElements[index];
        if (!currentSlideElement) {
            this.isTransitioning = false;
            return;
        }
        currentSlideElement.classList.add('active');

        // Update dots
        if (this.dotButtons && this.dotButtons[index]) {
            this.dotButtons[index].classList.add('active');
        }

        // Handle infinite loop
        if (this.settings.infiniteLoop) {
            this.setupInfiniteLoop(direction);
        }

        // Reset transition flag
        setTimeout(() => {
            this.isTransitioning = false;
        }, this.settings.transitionSpeed);
    }

    setupInfiniteLoop(direction) {
        if (direction === 'next' && this.currentSlide === this.slides.length - 1) {
            setTimeout(() => {
                if (!this.isTransitioning) {
                    this.goToSlide(0, 'instant');
                }
            }, this.settings.transitionSpeed + 50);
        } else if (direction === 'prev' && this.currentSlide === 0) {
            setTimeout(() => {
                if (!this.isTransitioning) {
                    this.goToSlide(this.slides.length - 1, 'instant');
                }
            }, this.settings.transitionSpeed + 50);
        }
    }

    nextSlide() {
        if (this.slides.length === 0) return;

        let nextIndex = this.currentSlide + 1;
        if (nextIndex >= this.slides.length) {
            nextIndex = this.settings.infiniteLoop ? 0 : this.slides.length - 1;
        }

        this.showSlide(nextIndex, 'next');
    }

    prevSlide() {
        if (this.slides.length === 0) return;

        let prevIndex = this.currentSlide - 1;
        if (prevIndex < 0) {
            prevIndex = this.settings.infiniteLoop ? this.slides.length - 1 : 0;
        }

        this.showSlide(prevIndex, 'prev');
    }

    goToSlide(index, instant = false) {
        if (index < 0 || index >= this.slides.length) return;

        if (instant) {
            this.currentSlide = index;
            this.slideElements.forEach(slide => slide.classList.remove('active', 'prev'));
            this.dotButtons.forEach(dot => dot.classList.remove('active'));

            this.slideElements[index].classList.add('active');
            if (this.dotButtons[index]) {
                this.dotButtons[index].classList.add('active');
            }
        } else {
            const direction = index > this.currentSlide ? 'next' : 'prev';
            this.showSlide(index, direction);
        }
    }

    startAutoplay() {
        if (!this.settings.autoplay || this.slides.length <= 1) return;

        this.pauseAutoplay();
        this.isPlaying = true;
        this.autoplayTimer = setInterval(() => {
            this.nextSlide();
        }, this.settings.autoplaySpeed);
    }

    pauseAutoplay() {
        if (this.autoplayTimer) {
            clearInterval(this.autoplayTimer);
            this.autoplayTimer = null;
        }
        this.isPlaying = false;
    }

    // Touch handlers
    handleTouchStart(e) {
        this.touchStartX = e.touches[0].clientX;
        this.container.classList.add('touch-active');
    }

    handleTouchEnd(e) {
        this.touchEndX = e.changedTouches[0].clientX;
        this.container.classList.remove('touch-active');
        this.handleSwipe();
    }

    // Mouse handlers
    handleMouseDown(e) {
        this.touchStartX = e.clientX;
        this.container.classList.add('touch-active');
    }

    handleMouseUp(e) {
        this.touchEndX = e.clientX;
        this.container.classList.remove('touch-active');
        this.handleSwipe();
    }

    handleSwipe() {
        const swipeThreshold = 50;
        const diff = this.touchStartX - this.touchEndX;

        if (Math.abs(diff) > swipeThreshold) {
            if (diff > 0) {
                this.nextSlide();
            } else {
                this.prevSlide();
            }
        }
    }

    // Keyboard navigation
    handleKeyboard(e) {
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;

        switch (e.key) {
            case 'ArrowLeft':
                e.preventDefault();
                this.prevSlide();
                break;
            case 'ArrowRight':
                e.preventDefault();
                this.nextSlide();
                break;
            case 'Home':
                e.preventDefault();
                this.goToSlide(0);
                break;
            case 'End':
                e.preventDefault();
                this.goToSlide(this.slides.length - 1);
                break;
            case ' ':
                e.preventDefault();
                if (this.isPlaying) {
                    this.pauseAutoplay();
                } else {
                    this.startAutoplay();
                }
                break;
        }
    }

    // Visibility change handler
    handleVisibilityChange() {
        if (document.hidden) {
            this.pauseAutoplay();
        } else if (this.settings.autoplay) {
            this.startAutoplay();
        }
    }

    // Resize handler
    handleResize() {
        // Debounce resize events
        clearTimeout(this.resizeTimer);
        this.resizeTimer = setTimeout(() => {
            // Adjust slider height if needed
            const container = this.container;
            const wrapper = this.wrapper;
            if (container && wrapper) {
                const aspectRatio = 16 / 9;
                const containerWidth = container.offsetWidth;
                const calculatedHeight = containerWidth / aspectRatio;

                if (calculatedHeight < 250) {
                    wrapper.style.height = '250px';
                } else if (calculatedHeight > 500) {
                    wrapper.style.height = '500px';
                } else {
                    wrapper.style.height = calculatedHeight + 'px';
                }
            }
        }, 250);
    }

    // Utility methods
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // Public methods
    updateSettings(newSettings) {
        this.settings = { ...this.settings, ...newSettings };

        if (this.settings.autoplay && !this.isPlaying) {
            this.startAutoplay();
        } else if (!this.settings.autoplay && this.isPlaying) {
            this.pauseAutoplay();
        }
    }

    refresh() {
        this.pauseAutoplay();
        this.loadSlides().then(() => {
            this.createSliderHTML();
            this.bindEvents();
            this.startAutoplay();
            this.showSlide(0);
        });
    }

    destroy() {
        this.pauseAutoplay();

        // Remove event listeners
        this.navButtons?.forEach(button => {
            button.replaceWith(button.cloneNode(true));
        });

        this.dotButtons?.forEach(dot => {
            dot.replaceWith(dot.cloneNode(true));
        });

        // Clear container
        if (this.container) {
            this.container.innerHTML = '';
        }

        // Clear references
        this.slides = [];
        this.slideElements = [];
        this.navButtons = [];
        this.dotButtons = [];
        this.wrapper = null;
        this.container = null;
    }
}

// Initialize slider when DOM is ready
document.addEventListener('DOMContentLoaded', function () {
    // Find slider containers
    const sliderContainers = document.querySelectorAll('[data-slider]');

    sliderContainers.forEach(container => {
        if (container.dataset.sliderInitialized === '1') {
            return;
        }
        container.dataset.sliderInitialized = '1';

        const containerId = container.id || `slider-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        container.id = containerId;

        // Get options from data attributes
        const options = {};
        const dataAttrs = container.dataset;

        Object.keys(dataAttrs).forEach(key => {
            if (key.startsWith('slider')) {
                const optionKey = key.replace('slider', '').toLowerCase();
                let value = dataAttrs[key];

                // Convert string values to appropriate types
                if (value === 'true' || value === 'false') {
                    value = value === 'true';
                } else if (!isNaN(value) && value !== '') {
                    value = parseInt(value, 10);
                }

                options[optionKey] = value;
            }
        });

        // Initialize slider
        new AdvancedSlider(containerId, options);
    });
});

// Global function for manual initialization
window.AdvancedSlider = AdvancedSlider;

})();
