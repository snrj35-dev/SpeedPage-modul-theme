<div class="slider-admin">
<div class="container">
    <div class="header">
        <h1><i class="fas fa-images"></i> <?= slider_t('slider_title') ?></h1>
        <p><?= slider_t('slider_description') ?></p>
    </div>

    <div class="tabs">
        <button class="tab-button active" onclick="showTab('images')">
            <i class="fas fa-image"></i> Resimler
        </button>
        <button class="tab-button" onclick="showTab('settings')">
            <i class="fas fa-cog"></i> Ayarlar
        </button>
    </div>

    <div id="images-tab" class="tab-content active">
        <div class="card">
            <h3 style="color: white; margin-bottom: 20px;">
                <i class="fas fa-plus"></i> <?= slider_t('slider_add_image') ?>
            </h3>
            <form id="addImageForm">
                <div class="form-group">
                    <label for="title">Başlık *</label>
                    <input type="text" id="title" name="title" class="form-control" placeholder="Resim başlığı"
                        required>
                </div>
                <div class="form-group">
                    <label for="description">Açıklama</label>
                    <textarea id="description" name="description" class="form-control" rows="3"
                        placeholder="Resim açıklaması"></textarea>
                </div>
                <div class="form-group">
                    <label for="image_url">Resim URL *</label>
                    <input type="url" id="image_url" name="image_url" class="form-control"
                        placeholder="https://example.com/image.jpg" required>
                </div>
                <div class="form-group">
                    <label for="link_url">Link URL</label>
                    <input type="url" id="link_url" name="link_url" class="form-control"
                        placeholder="https://example.com">
                </div>
                <button type="submit" class="btn btn-success">
                    <i class="fas fa-plus"></i> Resim Ekle
                </button>
            </form>
        </div>

        <div class="card">
            <h3 style="color: white; margin-bottom: 20px;">
                <i class="fas fa-images"></i> Mevcut Resimler
            </h3>
            <div id="alertContainer"></div>
            <div class="images-grid" id="imagesGrid">
                <?php foreach ($images as $image): ?>
                    <div class="image-card sortable" data-id="<?php echo $image['id']; ?>">
                        <img src="<?php echo htmlspecialchars($image['image_url']); ?>"
                            alt="<?php echo htmlspecialchars($image['title']); ?>" class="image-preview">
                        <div class="image-info">
                            <h4><?php echo htmlspecialchars($image['title']); ?></h4>
                            <p><?php echo htmlspecialchars($image['description'] ?: 'Açıklama yok'); ?></p>
                            <span
                                class="status-badge <?php echo $image['is_active'] ? 'status-active' : 'status-inactive'; ?>">
                                <?php echo $image['is_active'] ? 'Aktif' : 'Pasif'; ?>
                            </span>
                            <div class="image-actions">
                                <button class="btn btn-warning" onclick="editImage(<?php echo $image['id']; ?>)">
                                    <i class="fas fa-edit"></i> Düzenle
                                </button>
                                <button class="btn <?php echo $image['is_active'] ? 'btn-danger' : 'btn-success'; ?>"
                                    onclick="toggleImage(<?php echo $image['id']; ?>)">
                                    <i class="fas fa-<?php echo $image['is_active'] ? 'eye-slash' : 'eye'; ?>"></i>
                                    <?php echo $image['is_active'] ? 'Pasif Yap' : 'Aktif Yap'; ?>
                                </button>
                                <button class="btn btn-danger" onclick="deleteImage(<?php echo $image['id']; ?>)">
                                    <i class="fas fa-trash"></i> Sil
                                </button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <div id="settings-tab" class="tab-content">
        <div class="card">
            <h3 style="color: white; margin-bottom: 20px;">
                <i class="fas fa-cog"></i> <?= slider_t('slider_settings') ?>
            </h3>
            <form id="settingsForm">
                <div class="form-group">
                    <label for="display_location"><?= slider_t('slider_display_location') ?></label>
                    <select id="display_location" name="display_location" class="form-control">
                        <option value="hidden" <?php echo ($settings['display_location'] ?? 'hidden') == 'hidden' ? 'selected' : ''; ?>><?= slider_t('slider_location_hidden') ?></option>
                        <option value="before_content" <?php echo ($settings['display_location'] ?? '') == 'before_content' ? 'selected' : ''; ?>>
                            <?= slider_t('slider_location_before_content') ?></option>
                        <option value="after_content" <?php echo ($settings['display_location'] ?? '') == 'after_content' ? 'selected' : ''; ?>><?= slider_t('slider_location_after_content') ?></option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="autoplay">Otomatik Oynatma</label>
                    <select id="autoplay" name="autoplay" class="form-control">
                        <option value="1" <?php echo $settings['autoplay'] == '1' ? 'selected' : ''; ?>>Açık</option>
                        <option value="0" <?php echo $settings['autoplay'] == '0' ? 'selected' : ''; ?>>Kapalı
                        </option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="autoplay_speed">Otomatik Oynatma Hızı (ms)</label>
                    <input type="number" id="autoplay_speed" name="autoplay_speed" class="form-control"
                        value="<?php echo htmlspecialchars($settings['autoplay_speed']); ?>" min="1000" step="500">
                </div>
                <div class="form-group">
                    <label for="transition_speed">Geçiş Hızı (ms)</label>
                    <input type="number" id="transition_speed" name="transition_speed" class="form-control"
                        value="<?php echo htmlspecialchars($settings['transition_speed']); ?>" min="100" step="100">
                </div>
                <div class="form-group">
                    <label for="show_navigation">Navigasyon Okları</label>
                    <select id="show_navigation" name="show_navigation" class="form-control">
                        <option value="1" <?php echo $settings['show_navigation'] == '1' ? 'selected' : ''; ?>>Göster
                        </option>
                        <option value="0" <?php echo $settings['show_navigation'] == '0' ? 'selected' : ''; ?>>Gizle
                        </option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="show_dots">Nokta Navigasyonu</label>
                    <select id="show_dots" name="show_dots" class="form-control">
                        <option value="1" <?php echo $settings['show_dots'] == '1' ? 'selected' : ''; ?>>Göster
                        </option>
                        <option value="0" <?php echo $settings['show_dots'] == '0' ? 'selected' : ''; ?>>Gizle
                        </option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="infinite_loop">Sonsuz Döngü</label>
                    <select id="infinite_loop" name="infinite_loop" class="form-control">
                        <option value="1" <?php echo $settings['infinite_loop'] == '1' ? 'selected' : ''; ?>>Açık
                        </option>
                        <option value="0" <?php echo $settings['infinite_loop'] == '0' ? 'selected' : ''; ?>>Kapalı
                        </option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="pause_on_hover">Hover'da Durdur</label>
                    <select id="pause_on_hover" name="pause_on_hover" class="form-control">
                        <option value="1" <?php echo $settings['pause_on_hover'] == '1' ? 'selected' : ''; ?>>Açık
                        </option>
                        <option value="0" <?php echo $settings['pause_on_hover'] == '0' ? 'selected' : ''; ?>>Kapalı
                        </option>
                    </select>
                </div>
                <button type="submit" class="btn btn-success">
                    <i class="fas fa-save"></i> Ayarları Kaydet
                </button>
            </form>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<div id="editModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal()">&times;</span>
        <h3 style="color: white; margin-bottom: 20px;">
            <i class="fas fa-edit"></i> <?= slider_t('slider_edit_image') ?>
        </h3>
        <form id="editImageForm">
            <input type="hidden" id="edit_id" name="id">
            <div class="form-group">
                <label for="edit_title">Başlık *</label>
                <input type="text" id="edit_title" name="title" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="edit_description">Açıklama</label>
                <textarea id="edit_description" name="description" class="form-control" rows="3"></textarea>
            </div>
            <div class="form-group">
                <label for="edit_image_url">Resim URL *</label>
                <input type="url" id="edit_image_url" name="image_url" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="edit_link_url">Link URL</label>
                <input type="url" id="edit_link_url" name="link_url" class="form-control">
            </div>
            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i> Güncelle
            </button>
        </form>
    </div>
</div>

<script>
    let currentEditId = null;

    function showTab(tabName) {
        document.querySelectorAll('.tab-content').forEach(tab => {
            tab.classList.remove('active');
        });
        document.querySelectorAll('.tab-button').forEach(btn => {
            btn.classList.remove('active');
        });

        document.getElementById(tabName + '-tab').classList.add('active');
        event.target.classList.add('active');
    }

    function showAlert(message, type = 'success') {
        const alertContainer = document.getElementById('alertContainer');
        const alert = document.createElement('div');
        alert.className = `alert alert-${type}`;
        alert.innerHTML = `<i class="fas fa-${type === 'success' ? 'check' : 'exclamation-triangle'}"></i> ${message}`;
        alertContainer.appendChild(alert);

        setTimeout(() => {
            alert.remove();
        }, 5000);
    }

    // Add Image Form
    document.getElementById('addImageForm').addEventListener('submit', function (e) {
        e.preventDefault();
        const formData = new FormData(this);
        formData.append('action', 'add_image');
        formData.append('csrf', '<?php echo $_SESSION['csrf']; ?>');

        fetch('<?= BASE_URL ?>modules/slider/slider-panel.php', {
            method: 'POST',
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    showAlert('<?= slider_t('slider_image_added_successfully') ?>', 'success');
                    this.reset();
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showAlert(data.message, 'error');
                }
            })
            .catch(error => {
                showAlert('Bir hata oluştu: ' + error.message, 'error');
            });
    });

    // Edit Image
    function editImage(id) {
        currentEditId = id;
        // In a real implementation, you would fetch the image data from the server
        // For now, we'll just show the modal
        document.getElementById('editModal').style.display = 'block';
    }

    function closeModal() {
        document.getElementById('editModal').style.display = 'none';
    }

    // Edit Image Form
    document.getElementById('editImageForm').addEventListener('submit', function (e) {
        e.preventDefault();
        const formData = new FormData(this);
        formData.append('action', 'update_image');
        formData.append('csrf', '<?php echo $_SESSION['csrf']; ?>');

        fetch('<?= BASE_URL ?>modules/slider/slider-panel.php', {
            method: 'POST',
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    showAlert('<?= slider_t('slider_image_updated_successfully') ?>', 'success');
                    closeModal();
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showAlert(data.message, 'error');
                }
            })
            .catch(error => {
                showAlert('Bir hata oluştu: ' + error.message, 'error');
            });
    });

    // Toggle Image
    function toggleImage(id) {
        const formData = new FormData();
        formData.append('action', 'toggle_image');
        formData.append('id', id);
        formData.append('csrf', '<?php echo $_SESSION['csrf']; ?>');

        fetch('<?= BASE_URL ?>modules/slider/slider-panel.php', {
            method: 'POST',
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    showAlert(data.message, 'success');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showAlert(data.message, 'error');
                }
            })
            .catch(error => {
                showAlert('Bir hata oluştu: ' + error.message, 'error');
            });
    }

    // Delete Image
    function deleteImage(id) {
        if (confirm('Bu resmi silmek istediğinizden emin misiniz?')) {
            const formData = new FormData();
            formData.append('action', 'delete_image');
            formData.append('id', id);
            formData.append('csrf', '<?php echo $_SESSION['csrf']; ?>');

            fetch('<?= BASE_URL ?>modules/slider/slider-panel.php', {
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        showAlert('<?= slider_t('slider_image_deleted_successfully') ?>', 'success');
                        setTimeout(() => location.reload(), 1500);
                    } else {
                        showAlert(data.message, 'error');
                    }
                })
                .catch(error => {
                    showAlert('Bir hata oluştu: ' + error.message, 'error');
                });
        }
    }

    // Settings Form
    document.getElementById('settingsForm').addEventListener('submit', function (e) {
        e.preventDefault();
        const formData = new FormData(this);
        formData.append('action', 'update_settings');
        formData.append('csrf', '<?php echo $_SESSION['csrf']; ?>');

        fetch('<?= BASE_URL ?>modules/slider/slider-panel.php', {
            method: 'POST',
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    showAlert('<?= slider_t('slider_settings_updated_successfully') ?>', 'success');
                } else {
                    showAlert(data.message, 'error');
                }
            })
            .catch(error => {
                showAlert('Bir hata oluştu: ' + error.message, 'error');
            });
    });

    // Close modal when clicking outside
    window.onclick = function (event) {
        const modal = document.getElementById('editModal');
        if (event.target === modal) {
            closeModal();
        }
    }
</script>

</div>
</div>