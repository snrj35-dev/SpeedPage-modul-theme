<?php
declare(strict_types=1);

// Slider module hooks
if (!function_exists('slider_init')) {
    function slider_init()
    {
        // Check display location setting
        require_once __DIR__ . '/slider.php';
        $sliderData = getSliderData();
        $location = $sliderData['settings']['display_location'] ?? 'hidden';

        if ($location === 'before_content') {
            add_hook('before_content', 'slider_render_hook');
        } elseif ($location === 'after_content') {
            add_hook('after_content', 'slider_render_hook');
        }
    }
}

if (!function_exists('slider_render_hook')) {
    function slider_render_hook($data = null)
    {
        require_once __DIR__ . '/slider.php';
        echo getSliderHTML();
        return $data;
    }
}

if (!function_exists('slider_shortcode')) {
    function slider_shortcode($atts = [])
    {
        require_once __DIR__ . '/slider.php';
        return getSliderHTML();
    }
}

// Register core init hook
if (function_exists('add_hook')) {
    add_hook('init', 'slider_init');
}
?>