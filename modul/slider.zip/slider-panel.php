<?php
declare(strict_types=1);
require_once __DIR__ . '/../../settings.php';
require_once ROOT_DIR . 'admin/auth.php';
require_once ROOT_DIR . 'admin/db.php';

/** @var PDO $db */
global $db;

if (!function_exists('slider_t')) {
    /**
     * Slider Module Translation Helper
     */
    function slider_t(string $key, ...$args): string
    {
        static $translations = null;
        if ($translations === null) {
            $langFile = __DIR__ . '/lang.php';
            if (file_exists($langFile)) {
                $langData = require $langFile;
                $translations = $langData['Slider Module'] ?? [];
            } else {
                $translations = [];
            }
        }
        $text = $translations[$key] ?? $key;
        if (!empty($args)) {
            return vsprintf((string) $text, $args);
        }
        return (string) $text;
    }
}

// Check admin access
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('HTTP/1.0 403 Forbidden');
    exit('Access denied');
}

$action = filter_input(INPUT_POST, 'action', FILTER_SANITIZE_SPECIAL_CHARS) ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = filter_input(INPUT_POST, 'csrf', FILTER_SANITIZE_SPECIAL_CHARS);
    if (!$csrf || $csrf !== $_SESSION['csrf']) {
        echo json_encode(["status" => "error", "message" => "CSRF error"]);
        exit;
    }
}

switch ($action) {
    case 'add_image':
        handleAddImage($db);
        break;
    case 'update_image':
        handleUpdateImage($db);
        break;
    case 'delete_image':
        handleDeleteImage($db);
        break;
    case 'toggle_image':
        handleToggleImage($db);
        break;
    case 'reorder_images':
        handleReorderImages($db);
        break;
    case 'update_settings':
        handleUpdateSettings($db);
        break;
    default:
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            showAdminPanel($db);
        } else {
            echo json_encode(["status" => "error", "message" => "Invalid action"]);
        }
        break;
}

function showAdminPanel(PDO $db): void
{
    $images = getSliderImages($db);
    $settings = getSliderSettings($db);

    include __DIR__ . '/slider-panel-template.php';
}

function getSliderImages(PDO $db): array
{
    $stmt = $db->prepare("SELECT * FROM slider_images ORDER BY sort_order ASC, id DESC");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getSliderSettings(PDO $db): array
{
    $stmt = $db->prepare("SELECT setting_key, setting_value FROM slider_settings");
    $stmt->execute();
    $settings = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }
    return $settings;
}

function handleAddImage(PDO $db): void
{
    try {
        $title = filter_input(INPUT_POST, 'title', FILTER_SANITIZE_SPECIAL_CHARS);
        $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_SPECIAL_CHARS);
        $image_url = filter_input(INPUT_POST, 'image_url', FILTER_VALIDATE_URL);
        $link_url = filter_input(INPUT_POST, 'link_url', FILTER_VALIDATE_URL);

        if (!$title || !$image_url) {
            throw new Exception("Title and Image URL are required");
        }

        $stmt = $db->prepare("INSERT INTO slider_images (title, description, image_url, link_url) VALUES (?, ?, ?, ?)");
        $stmt->execute([$title, $description, $image_url, $link_url]);

        echo json_encode([
            "status" => "success",
            "message" => "Image added successfully",
            "id" => $db->lastInsertId()
        ]);
    } catch (Exception $e) {
        echo json_encode(["status" => "error", "message" => $e->getMessage()]);
    }
}

function handleUpdateImage(PDO $db): void
{
    try {
        $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
        $title = filter_input(INPUT_POST, 'title', FILTER_SANITIZE_SPECIAL_CHARS);
        $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_SPECIAL_CHARS);
        $image_url = filter_input(INPUT_POST, 'image_url', FILTER_VALIDATE_URL);
        $link_url = filter_input(INPUT_POST, 'link_url', FILTER_VALIDATE_URL);

        if (!$id || !$title || !$image_url) {
            throw new Exception("ID, Title and Image URL are required");
        }

        $stmt = $db->prepare("UPDATE slider_images SET title = ?, description = ?, image_url = ?, link_url = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
        $stmt->execute([$title, $description, $image_url, $link_url, $id]);

        echo json_encode(["status" => "success", "message" => "Image updated successfully"]);
    } catch (Exception $e) {
        echo json_encode(["status" => "error", "message" => $e->getMessage()]);
    }
}

function handleDeleteImage(PDO $db): void
{
    try {
        $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
        if (!$id) {
            throw new Exception("Invalid ID");
        }

        $stmt = $db->prepare("DELETE FROM slider_images WHERE id = ?");
        $stmt->execute([$id]);

        echo json_encode(["status" => "success", "message" => "Image deleted successfully"]);
    } catch (Exception $e) {
        echo json_encode(["status" => "error", "message" => $e->getMessage()]);
    }
}

function handleToggleImage(PDO $db): void
{
    try {
        $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
        if (!$id) {
            throw new Exception("Invalid ID");
        }

        $stmt = $db->prepare("SELECT is_active FROM slider_images WHERE id = ?");
        $stmt->execute([$id]);
        $current = $stmt->fetchColumn();

        $newState = $current ? 0 : 1;
        $stmt = $db->prepare("UPDATE slider_images SET is_active = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
        $stmt->execute([$newState, $id]);

        echo json_encode([
            "status" => "success",
            "message" => $newState ? "Image activated" : "Image deactivated",
            "is_active" => $newState
        ]);
    } catch (Exception $e) {
        echo json_encode(["status" => "error", "message" => $e->getMessage()]);
    }
}

function handleReorderImages(PDO $db): void
{
    try {
        $orders = json_decode(file_get_contents('php://input'), true);
        if (!is_array($orders)) {
            throw new Exception("Invalid order data");
        }

        $db->beginTransaction();
        foreach ($orders as $order) {
            $stmt = $db->prepare("UPDATE slider_images SET sort_order = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
            $stmt->execute([$order['order'], $order['id']]);
        }
        $db->commit();

        echo json_encode(["status" => "success", "message" => "Images reordered successfully"]);
    } catch (Exception $e) {
        $db->rollBack();
        echo json_encode(["status" => "error", "message" => $e->getMessage()]);
    }
}

function handleUpdateSettings(PDO $db): void
{
    try {
        $settings = [
            'display_location' => filter_input(INPUT_POST, 'display_location', FILTER_SANITIZE_SPECIAL_CHARS),
            'autoplay' => filter_input(INPUT_POST, 'autoplay', FILTER_VALIDATE_INT),
            'autoplay_speed' => filter_input(INPUT_POST, 'autoplay_speed', FILTER_VALIDATE_INT),
            'transition_speed' => filter_input(INPUT_POST, 'transition_speed', FILTER_VALIDATE_INT),
            'show_navigation' => filter_input(INPUT_POST, 'show_navigation', FILTER_VALIDATE_INT),
            'show_dots' => filter_input(INPUT_POST, 'show_dots', FILTER_VALIDATE_INT),
            'infinite_loop' => filter_input(INPUT_POST, 'infinite_loop', FILTER_VALIDATE_INT),
            'pause_on_hover' => filter_input(INPUT_POST, 'pause_on_hover', FILTER_VALIDATE_INT)
        ];

        $db->beginTransaction();
        foreach ($settings as $key => $value) {
            $stmt = $db->prepare("UPDATE slider_settings SET setting_value = ?, updated_at = CURRENT_TIMESTAMP WHERE setting_key = ?");
            $stmt->execute([$value, $key]);
        }
        $db->commit();

        echo json_encode(["status" => "success", "message" => "Settings updated successfully"]);
    } catch (Exception $e) {
        $db->rollBack();
        echo json_encode(["status" => "error", "message" => $e->getMessage()]);
    }
}
?>