<?php
declare(strict_types=1);

if (!defined('ROOT_DIR')) {
    require_once __DIR__ . '/../../settings.php';
}
require_once ROOT_DIR . 'admin/db.php';

/** @var PDO $db */
global $db;

$action = filter_input(INPUT_GET, 'action', FILTER_SANITIZE_SPECIAL_CHARS) ?? '';

switch ($action) {
    case 'get_slides':
        getSlides($db);
        break;
    case 'get_settings':
        getSettings($db);
        break;
    default:
        echo json_encode(["status" => "error", "message" => "Invalid action"]);
        break;
}

function getSlides(PDO $db): void
{
    try {
        $stmt = $db->prepare("
            SELECT id, title, description, image_url, link_url, sort_order 
            FROM slider_images 
            WHERE is_active = 1 
            ORDER BY sort_order ASC, id DESC
        ");
        $stmt->execute();
        $slides = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode([
            "status" => "success",
            "slides" => $slides
        ]);
    } catch (Exception $e) {
        echo json_encode([
            "status" => "error",
            "message" => "Failed to load slides: " . $e->getMessage()
        ]);
    }
}

function getSettings(PDO $db): void
{
    try {
        $stmt = $db->prepare("SELECT setting_key, setting_value FROM slider_settings");
        $stmt->execute();
        $settings = [];

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }

        echo json_encode([
            "status" => "success",
            "settings" => $settings
        ]);
    } catch (Exception $e) {
        echo json_encode([
            "status" => "error",
            "message" => "Failed to load settings: " . $e->getMessage()
        ]);
    }
}
?>