/* ======================================================
   SLIDER ADMIN PANEL JS (admin_assets)
   ====================================================== */

let currentEditId = null;

function showTab(tabName) {
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    document.querySelectorAll('.tab-button').forEach(btn => {
        btn.classList.remove('active');
    });

    document.getElementById(tabName + '-tab').classList.add('active');
    if (event && event.target) {
        event.target.classList.add('active');
    }
}

function showAlert(message, type = 'success') {
    const alertContainer = document.getElementById('alertContainer');
    if (!alertContainer) return;
    const alert = document.createElement('div');
    alert.className = `alert alert-${type}`;
    alert.innerHTML = `<i class="fas fa-${type === 'success' ? 'check' : 'exclamation-triangle'}"></i> ${message}`;
    alertContainer.appendChild(alert);

    setTimeout(() => {
        alert.remove();
    }, 5000);
}

// Edit Modal helpers
function closeModal() {
    const modal = document.getElementById('editModal');
    if (modal) modal.style.display = 'none';
}

function editImage(id) {
    currentEditId = id;
    const modal = document.getElementById('editModal');
    if (modal) modal.style.display = 'block';
}

// Helper for AJAX requests
async function sendSliderRequest(formData) {
    try {
        let actionUrl = 'modules/slider/slider-panel.php';
        if (typeof BASE_URL !== 'undefined' && BASE_URL) {
            actionUrl = BASE_URL + 'modules/slider/slider-panel.php';
        }

        const response = await fetch(actionUrl, {
            method: 'POST',
            body: formData
        });

        const text = await response.text();
        try {
            return JSON.parse(text);
        } catch (jsonError) {
            console.error('JSON Parse Error:', jsonError, 'Response Text:', text);
            return { status: 'error', message: 'Sunucudan geçersiz yanıt alındı.' };
        }
    } catch (error) {
        console.error('Network/Request Error:', error);
        return { status: 'error', message: 'İletişim hatası oluştu.' };
    }
}

async function toggleImage(id) {
    const formData = new FormData();
    formData.append('action', 'toggle_image');
    formData.append('id', id);
    formData.append('csrf', typeof CSRF_TOKEN !== 'undefined' ? CSRF_TOKEN : (document.querySelector('input[name="csrf"]')?.value || ''));

    const data = await sendSliderRequest(formData);
    if (data.status === 'success') {
        showAlert(data.message, 'success');
        setTimeout(() => location.reload(), 1000);
    } else {
        showAlert(data.message, 'error');
    }
}

async function deleteImage(id) {
    if (!confirm('Bu resmi silmek istediğinizden emin misiniz?')) return;
    const formData = new FormData();
    formData.append('action', 'delete_image');
    formData.append('id', id);
    formData.append('csrf', typeof CSRF_TOKEN !== 'undefined' ? CSRF_TOKEN : (document.querySelector('input[name="csrf"]')?.value || ''));

    const data = await sendSliderRequest(formData);
    if (data.status === 'success') {
        showAlert(data.message, 'success');
        setTimeout(() => location.reload(), 1000);
    } else {
        showAlert(data.message, 'error');
    }
}

document.addEventListener('DOMContentLoaded', () => {
    // Add Image Form
    const addForm = document.getElementById('addImageForm');
    if (addForm) {
        addForm.addEventListener('submit', async function (e) {
            e.preventDefault();
            const formData = new FormData(this);
            formData.append('action', 'add_image');
            formData.append('csrf', typeof CSRF_TOKEN !== 'undefined' ? CSRF_TOKEN : (document.querySelector('input[name="csrf"]')?.value || ''));

            const data = await sendSliderRequest(formData);
            if (data.status === 'success') {
                showAlert('Resim başarıyla eklendi', 'success');
                this.reset();
                setTimeout(() => location.reload(), 1000);
            } else { showAlert(data.message, 'error'); }
        });
    }

    // Edit Image Form
    const editForm = document.getElementById('editImageForm');
    if (editForm) {
        editForm.addEventListener('submit', async function (e) {
            e.preventDefault();
            const formData = new FormData(this);
            formData.append('action', 'update_image');
            formData.append('csrf', typeof CSRF_TOKEN !== 'undefined' ? CSRF_TOKEN : (document.querySelector('input[name="csrf"]')?.value || ''));

            const data = await sendSliderRequest(formData);
            if (data.status === 'success') {
                showAlert('Resim güncellendi', 'success');
                closeModal();
                setTimeout(() => location.reload(), 1000);
            } else { showAlert(data.message, 'error'); }
        });
    }

    // Settings Form
    const settingsForm = document.getElementById('settingsForm');
    if (settingsForm) {
        settingsForm.addEventListener('submit', async function (e) {
            e.preventDefault();
            const formData = new FormData(this);
            formData.append('action', 'update_settings');
            formData.append('csrf', typeof CSRF_TOKEN !== 'undefined' ? CSRF_TOKEN : (document.querySelector('input[name="csrf"]')?.value || ''));

            const data = await sendSliderRequest(formData);
            if (data.status === 'success') {
                showAlert('Ayarlar kaydedildi', 'success');
            } else { showAlert(data.message, 'error'); }
        });
    }

    // Close modal on click outside
    window.addEventListener('click', (event) => {
        const modal = document.getElementById('editModal');
        if (event.target === modal) closeModal();
    });
});
