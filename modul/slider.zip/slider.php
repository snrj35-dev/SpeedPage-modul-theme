<?php
declare(strict_types=1);

require_once ROOT_DIR . 'admin/db.php';

/** @var PDO $db */
global $db;

// Get slider data
function getSliderData(): array
{
    global $db;
    try {
        $stmt = $db->prepare("
            SELECT id, title, description, image_url, link_url, sort_order 
            FROM slider_images 
            WHERE is_active = 1 
            ORDER BY sort_order ASC, id DESC
        ");
        $stmt->execute();
        $slides = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $stmt = $db->prepare("SELECT setting_key, setting_value FROM slider_settings");
        $stmt->execute();
        $settings = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }

        return [
            'slides' => $slides,
            'settings' => $settings
        ];
    } catch (Exception $e) {
        return [
            'slides' => [],
            'settings' => []
        ];
    }
}

// Get slider HTML
function getSliderHTML(): string
{
    $data = getSliderData();
    $slides = $data['slides'];
    $settings = $data['settings'];

    if (empty($slides)) {
        return '<div class="slider-container">
            <div class="slider-empty">
                <i class="fas fa-images"></i>
                <h3>' . __('slider_no_images_found') . '</h3>
                <p>' . __('slider_description') . '</p>
            </div>
        </div>';
    }

    $sliderId = 'slider-' . uniqid();
    $dataAttributes = '';

    // Convert settings to data attributes
    $settingMap = [
        'autoplay' => 'data-slider-autoplay',
        'autoplay_speed' => 'data-slider-autoplay-speed',
        'transition_speed' => 'data-slider-transition-speed',
        'show_navigation' => 'data-slider-show-navigation',
        'show_dots' => 'data-slider-show-dots',
        'infinite_loop' => 'data-slider-infinite-loop',
        'pause_on_hover' => 'data-slider-pause-on-hover'
    ];

    foreach ($settingMap as $key => $attr) {
        $value = $settings[$key] ?? '';
        if ($value !== '') {
            $dataAttributes .= ' ' . $attr . '="' . htmlspecialchars($value) . '"';
        }
    }

    $html = '<div class="slider-container" data-slider="1" id="' . $sliderId . '"' . $dataAttributes . '>';
    $html .= '<!-- Slider will be initialized by JavaScript -->';
    $html .= '</div>';

    return $html;
}

if (!function_exists('slider_shortcode')) {
    // Shortcode support
    function slider_shortcode($atts = []): string
    {
        $atts = array_change_key_case((array) $atts, CASE_LOWER);

        // Override settings with shortcode attributes
        $dataAttributes = '';
        $settingMap = [
            'autoplay' => 'data-slider-autoplay',
            'autoplay_speed' => 'data-slider-autoplay-speed',
            'transition_speed' => 'data-slider-transition-speed',
            'show_navigation' => 'data-slider-show-navigation',
            'show_dots' => 'data-slider-show-dots',
            'infinite_loop' => 'data-slider-infinite-loop',
            'pause_on_hover' => 'data-slider-pause-on-hover'
        ];

        foreach ($settingMap as $key => $attr) {
            if (isset($atts[$key])) {
                $dataAttributes .= ' ' . $attr . '="' . htmlspecialchars($atts[$key]) . '"';
            }
        }

        $sliderId = 'slider-' . uniqid();

        return '<div class="slider-container" data-slider="1" id="' . $sliderId . '"' . $dataAttributes . '><!-- Slider will be initialized by JavaScript --></div>';
    }
}

// Output only when called directly
if (realpath($_SERVER['SCRIPT_FILENAME'] ?? '') === realpath(__FILE__)) {
    echo getSliderHTML();
}
?>