<?php
return [
    'Slider Module' => [
        'slider_title' => 'Slider',
        'slider_description' => 'Slider açıklaması',
        'slider_add_image' => 'Resim Ekle',
        'slider_edit_image' => 'Resim Düzenle',
        'slider_delete_image' => 'Resim Sil',
        'slider_settings' => 'Slider Ayarları',
        'slider_autoplay' => 'Otomatik Oynatma',
        'slider_autoplay_speed' => 'Otomatik Oynatma Hızı',
        'slider_transition_speed' => 'Geçiş Hızı',
        'slider_show_navigation' => 'Navigasyon Okları',
        'slider_show_dots' => 'Nokta Navigasyonu',
        'slider_infinite_loop' => 'Sonsuz Döngü',
        'slider_pause_on_hover' => 'Hover\'da Durdur',
        'slider_title_required' => 'Başlık alanı zorunludur',
        'slider_image_url_required' => 'Resim URL alanı zorunludur',
        'slider_image_added_successfully' => 'Resim başarıyla eklendi',
        'slider_image_updated_successfully' => 'Resim başarıyla güncellendi',
        'slider_image_deleted_successfully' => 'Resim başarıyla silindi',
        'slider_settings_updated_successfully' => 'Ayarlar başarıyla güncellendi',
        'slider_no_images_found' => 'Gösterilecek resim bulunamadı',
        'slider_error_loading' => 'Slider yüklenirken hata oluştu',
        'slider_display_location' => 'Gösterim Yeri',
        'slider_location_hidden' => 'Gizle (Sadece Shortcode)',
        'slider_location_before_content' => 'İçerik Üstü',
        'slider_location_after_content' => 'İçerik Altı'
    ]
];
?>