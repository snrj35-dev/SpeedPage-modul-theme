<?php
declare(strict_types=1);
require_once ROOT_DIR . 'admin/db.php';
require_once PHP_DIR . 'user_auth.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (function_exists('sp_load_module_hooks')) {
    sp_load_module_hooks();
}

$current_user_id = $_SESSION['user_id'] ?? 0;
if (!$current_user_id) {
    header("Location: " . BASE_URL . "php/login.php");
    exit;
}

// Kullanıcı Bilgilerini Çek
$stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$current_user_id]);
$me = $stmt->fetch();

?>
<style>
    /* Sidebar kolonunu gizle */
    aside.sidebar, 
    .col-md-3.d-none.d-md-block { 
        display: none !important; 
    }
    
    /* Ana içerik kolonunu %100 genişliğe zorla */
    .col-md-9 {
        width: 100% !important;
        flex: 0 0 100% !important;
        max-width: 100% !important;
    }

    /* Eğer konteyner içinde ekstra boşluk kalsın istemiyorsan */
    main#app.container {
        max-width: 100% !important;
    }
</style>
<main class="container py-4">
    <div class="row g-4">
        <!-- Sol Kolon: Kişisel Özet -->
        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 overflow-hidden mb-4">
                <?php
                $stmt = $db->prepare("SELECT meta_value FROM user_meta WHERE user_id = ? AND meta_key = 'cover_photo'");
                $stmt->execute([$current_user_id]);
                $cover = $stmt->fetchColumn();
                if ($cover && strpos($cover, 'linear-gradient') !== false) {
                    $coverStyle = "background: $cover;";
                } else {
                    $coverStyle = $cover ? "background-image: url('".BASE_URL.$cover."');" : "background: linear-gradient(45deg, #4e73df, #224abe);";
                }
                ?>
                <div style="height: 80px; <?= $coverStyle ?> background-size: cover; background-position: center;"></div>
                <div class="card-body text-center pt-0" style="margin-top: -35px;">
                    <div class="avatar-md bg-white p-1 rounded-circle d-inline-block shadow-sm">
                        <div class="position-relative" style="width:60px; height:60px;">
                            <div class="rounded-circle bg-secondary w-100 h-100 d-flex align-items-center justify-content-center text-white">
                                <i class="fas <?= !empty($me['avatar_url']) ? $me['avatar_url'] : 'fa-user' ?> fa-lg"></i>
                            </div>
                        </div>
                    </div>
                    <h6 class="fw-bold mt-2 mb-0"><?= htmlspecialchars($me['display_name']) ?></h6>
                    <p class="text-muted small">@<?= htmlspecialchars($me['username']) ?></p>
                    <hr>
                    <div class="d-flex justify-content-around small">
                        <div>
                            <div class="fw-bold"><?php 
                                $stmt = $db->prepare("SELECT COUNT(*) FROM social_follows WHERE follower_id = ?");
                                $stmt->execute([$current_user_id]);
                                echo $stmt->fetchColumn();
                            ?></div>
                            <div class="text-muted">Takip</div>
                        </div>
                        <div>
                            <div class="fw-bold"><?php 
                                $stmt = $db->prepare("SELECT COUNT(*) FROM social_follows WHERE following_id = ?");
                                $stmt->execute([$current_user_id]);
                                echo $stmt->fetchColumn();
                            ?></div>
                            <div class="text-muted">Takipçi</div>
                        </div>
                    </div>
                    <a href="<?= BASE_URL ?>php/profile.php" class="btn btn-primary btn-sm rounded-pill w-100 mt-3">Profilime Git</a>
                </div>
            </div>
            
            <div class="list-group list-group-flush shadow-sm rounded-4 border-0 mb-4 overflow-hidden">
                <a href="<?= BASE_URL ?>modules/social/social.php" class="list-group-item list-group-item-action active border-0">
                    <i class="fas fa-home me-2"></i> Haber Kaynağı
                </a>
                <a href="#" class="list-group-item list-group-item-action border-0">
                    <i class="fas fa-users me-2"></i> Arkadaşlar
                </a>
                <a href="#" class="list-group-item list-group-item-action border-0">
                    <i class="fas fa-bookmark me-2"></i> Kaydedilenler
                </a>
            </div>
        </div>

        <!-- Orta Kolon: Main Feed -->
        <div class="col-md-6">
            <!-- Paylaşım Kutusu -->
            <div class="card mb-4 border-0 shadow-sm rounded-4 overflow-hidden">
                <div class="card-body">
                    <div class="d-flex gap-2">
                        <div class="position-relative" style="width:40px; height:40px;">
                            <div class="rounded-circle bg-secondary w-100 h-100 d-flex align-items-center justify-content-center text-white">
                                <i class="fas <?= !empty($me['avatar_url']) ? $me['avatar_url'] : 'fa-user' ?>"></i>
                            </div>
                        </div>
                        <input type="hidden" id="wallTarget" value="<?= $current_user_id ?>">
                        <textarea id="wallContent" class="form-control border-0 bg-light rounded-4" rows="2" placeholder="Ne düşünüyorsun?"></textarea>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <div>
                        </div>
                        <button id="submitWallPost" class="btn btn-primary btn-sm rounded-pill px-4 fw-bold">Paylaş</button>
                    </div>
                </div>
            </div>

            <!-- Akış -->
            <div id="social-feed">
                <?php
                // Takip edilenlerin ve kendisinin gönderilerini çek
                $stmt = $db->prepare("SELECT p.*, u.display_name, u.avatar_url,
                                      (SELECT COUNT(*) FROM social_reactions WHERE post_id = p.id) as like_count,
                                      (SELECT COUNT(*) FROM social_comments WHERE post_id = p.id) as comment_count,
                                      (SELECT 1 FROM social_reactions WHERE post_id = p.id AND user_id = ?) as user_liked
                                      FROM social_posts p 
                                      JOIN users u ON p.author_id = u.id 
                                      WHERE p.author_id = ? 
                                      OR p.author_id IN (SELECT following_id FROM social_follows WHERE follower_id = ?)
                                      ORDER BY p.created_at DESC");
                $stmt->execute([$current_user_id, $current_user_id, $current_user_id]);
                $posts = $stmt->fetchAll();

                if(empty($posts)): ?>
                    <div class="card border-0 shadow-sm rounded-4 p-5 text-center">
                        <i class="fas fa-users-slash fa-3x text-muted mb-3"></i>
                        <h5>Henüz akışında bir şey yok</h5>
                        <p class="text-muted">Birkaç kişiyi takip ederek akışını canlandır!</p>
                    </div>
                <?php else: 
                    foreach($posts as $post): ?>
                        <div class="card mb-3 border-0 shadow-sm rounded-4 social-post-card post-card-<?= $post['id'] ?>">
                            <div class="card-body p-3">
                                <div class="d-flex justify-content-between mb-2">
                                    <div class="d-flex align-items-center">
                                        <a href="<?= BASE_URL ?>php/profile.php?id=<?= $post['author_id'] ?>">
                                            <div class="position-relative me-2" style="width:38px; height:38px;">
                                                <div class="rounded-circle bg-secondary w-100 h-100 d-flex align-items-center justify-content-center text-white">
                                                    <i class="fas <?= !empty($post['avatar_url']) ? $post['avatar_url'] : 'fa-user' ?>"></i>
                                                </div>
                                            </div>
                                        </a>
                                        <div>
                                            <h6 class="mb-0 fw-bold">
                                                <a href="<?= BASE_URL ?>php/profile.php?id=<?= $post['author_id'] ?>" class="text-dark text-decoration-none"><?= htmlspecialchars($post['display_name']) ?></a>
                                                <?php if($post['user_id'] != $post['author_id']): ?>
                                                    <i class="fas fa-caret-right text-muted mx-1"></i>
                                                    <a href="<?= BASE_URL ?>php/profile.php?id=<?= $post['user_id'] ?>" class="text-dark text-decoration-none">Duvar</a>
                                                <?php endif; ?>
                                            </h6>
                                            <small class="text-muted" style="font-size: 11px;"><?= $post['created_at'] ?></small>
                                        </div>
                                    </div>
                                    <?php if($post['author_id'] == $current_user_id || (isset($_SESSION['role']) && $_SESSION['role'] === 'admin')): ?>
                                    <div class="dropdown">
                                        <button class="btn btn-link text-muted p-0" data-bs-toggle="dropdown"><i class="fas fa-ellipsis-h"></i></button>
                                        <ul class="dropdown-menu dropdown-menu-end shadow border-0 rounded-3">
                                            <li><a class="dropdown-item text-danger" href="javascript:void(0)" onclick="socialDeletePost(<?= $post['id'] ?>)"><i class="fas fa-trash-alt me-2"></i>Sil</a></li>
                                        </ul>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <p class="card-text text-secondary mb-3"><?= nl2br(htmlspecialchars($post['content'])) ?></p>
                                

                                <div class="post-actions d-flex border-top pt-2">
                                    <button class="btn btn-link btn-sm text-decoration-none react-btn <?= $post['user_liked'] ? 'text-primary' : 'text-muted' ?>" data-id="<?= $post['id'] ?>" onclick="socialReact(<?= $post['id'] ?>)">
                                        <i class="fa<?= $post['user_liked'] ? 's' : 'r' ?> fa-heart me-1"></i> Beğen (<?= $post['like_count'] ?>)
                                    </button>
                                    <button class="btn btn-link btn-sm text-decoration-none text-muted ms-2" onclick="document.getElementById('comment-box-<?= $post['id'] ?>').classList.toggle('d-none')">
                                        <i class="far fa-comment me-1"></i> Yorum (<?= $post['comment_count'] ?>)
                                    </button>
                                </div>

                                <div id="comment-box-<?= $post['id'] ?>" class="comment-section mt-3 d-none">
                                    <div class="comments-list mb-2">
                                        <?php
                                        $cStmt = $db->prepare("SELECT c.*, u.display_name, u.avatar_url FROM social_comments c JOIN users u ON c.user_id = u.id WHERE c.post_id = ? ORDER BY c.created_at ASC LIMIT 5");
                                        $cStmt->execute([$post['id']]);
                                        while($comment = $cStmt->fetch()):
                                        ?>
                                            <div class="d-flex mb-2">
                                            <div class="position-relative me-2" style="width:28px; height:28px;">
                                                    <div class="rounded-circle bg-secondary w-100 h-100 d-flex align-items-center justify-content-center text-white">
                                                        <i class="fas <?= !empty($comment['avatar_url']) ? $comment['avatar_url'] : 'fa-user' ?>"></i>
                                                    </div>
                                            </div>
                                                <div class="bg-light rounded-4 p-2 flex-grow-1" style="font-size: 0.85rem;">
                                                    <div class="fw-bold"><?= htmlspecialchars($comment['display_name']) ?></div>
                                                    <div><?= nl2br(htmlspecialchars($comment['comment'])) ?></div>
                                                </div>
                                            </div>
                                        <?php endwhile; ?>
                                    </div>
                                    <div class="d-flex gap-2">
                                        <input type="text" id="comment-input-<?= $post['id'] ?>" class="form-control form-control-sm rounded-pill border-0 bg-light px-3" placeholder="Yorum yap...">
                                        <button class="btn btn-primary btn-sm rounded-pill px-3" onclick="socialComment(<?= $post['id'] ?>)">Gönder</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; 
                endif; ?>
            </div>
        </div>

        <!-- Sağ Kolon: Öneriler -->
        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 mb-4">
                <div class="card-body">
                    <h6 class="fw-bold mb-3">Kimi Takip Etmeli?</h6>
                    <?php
                    // Takip edilmeyen rastgele 3 kullanıcı
                    $stmt = $db->prepare("SELECT id, display_name, username, avatar_url FROM users WHERE id != ? AND id NOT IN (SELECT following_id FROM social_follows WHERE follower_id = ?) ORDER BY RANDOM() LIMIT 3");
                    $stmt->execute([$current_user_id, $current_user_id]);
                    $suggestions = $stmt->fetchAll();

                    foreach($suggestions as $sug): ?>
                        <div class="d-flex align-items-center justify-content-between mb-3">
                            <div class="d-flex align-items-center">
                                <div class="position-relative me-2" style="width:35px; height:35px;">
                                    <div class="rounded-circle bg-secondary w-100 h-100 d-flex align-items-center justify-content-center text-white">
                                        <i class="fas <?= !empty($sug['avatar_url']) ? $sug['avatar_url'] : 'fa-user' ?>"></i>
                                    </div>
                                </div>
                                <div style="line-height: 1;">
                                    <div class="fw-bold small"><?= htmlspecialchars($sug['display_name']) ?></div>
                                    <small class="text-muted" style="font-size: 10px;">@<?= $sug['username'] ?></small>
                                </div>
                            </div>
                            <button class="btn btn-outline-primary btn-sm rounded-pill px-3 py-1" style="font-size: 10px;" onclick="socialFollow(<?= $sug['id'] ?>)">Takip Et</button>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="card border-0 shadow-sm rounded-4 mb-4">
                <div class="card-body">
                    <h6 class="fw-bold mb-3">Trendler</h6>
                    <div class="list-group list-group-flush">
                        <div class="list-group-item px-0 border-0">
                            <div class="text-muted small">#teknoloji</div>
                            <div class="fw-bold small">1.5K Paylaşım</div>
                        </div>
                        <div class="list-group-item px-0 border-0">
                            <div class="text-muted small">#spor</div>
                            <div class="fw-bold small">840 Paylaşım</div>
                        </div>
                        <div class="list-group-item px-0 border-0">
                            <div class="text-muted small">#yazılım</div>
                            <div class="fw-bold small">420 Paylaşım</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<script src="<?= BASE_URL ?>modules/social/social.js"></script>
