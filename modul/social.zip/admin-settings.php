<?php
declare(strict_types=1);

// Admin panelinden include edildiği için root'a göre ayarla
require_once __DIR__ . '/../../settings.php';
require_once __DIR__ . '/../../admin/db.php';
require_once __DIR__ . '/../../admin/auth.php';

// Form gönderildiğinde ayarları kaydet
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    
    $settings_to_save = [
        'social_enable_wall' => $_POST['enable_wall'] ?? '0',
        'social_enable_chat' => $_POST['enable_chat'] ?? '0',
        'social_enable_trends' => $_POST['enable_trends'] ?? '0',
        'social_premium_features' => $_POST['enable_premium'] ?? '0'
    ];

    foreach ($settings_to_save as $key => $val) {
        $check = $db->prepare("SELECT 1 FROM settings WHERE `key` = ?");
        $check->execute([$key]);
        if ($check->fetch()) {
            $db->prepare("UPDATE settings SET value = ? WHERE `key` = ?")->execute([$val, $key]);
        } else {
            $db->prepare("INSERT INTO settings (`key`, value) VALUES (?, ?)")->execute([$key, $val]);
        }
    }
    $success = "Ayarlar başarıyla kaydedildi.";
}

// Mevcut ayarları çek
$stmt = $db->query("SELECT `key`, value FROM settings WHERE `key` LIKE 'social_%'");
$social_settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

?>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold text-primary mb-0">
            <i class="fas fa-users-cog me-2"></i> social Modül Ayarları
        </h4>
        <a href="<?= BASE_URL ?>modules/social/social.php" class="btn btn-outline-primary btn-sm rounded-pill px-3" target="_blank">
            <i class="fas fa-external-link-alt me-1"></i> Haber Kaynağına Git
        </a>
    </div>

    <?php if(isset($success)): ?>
        <div class="alert alert-success border-0 shadow-sm rounded-4"><?= $success ?></div>
    <?php endif; ?>

    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
        <div class="card-body p-4">
            <form method="POST">
                <input type="hidden" name="csrf" value="<?= $_SESSION['csrf'] ?>">
                
                <div class="row g-4">
                    <div class="col-md-6">
                        <div class="form-check form-switch mb-3">
                            <input class="form-check-input" type="checkbox" name="enable_wall" value="1" id="enableWall" <?= ($social_settings['social_enable_wall'] ?? '1') == '1' ? 'checked' : '' ?>>
                            <label class="form-check-label fw-bold" for="enableWall">Kullanıcı Duvarını Etkinleştir</label>
                            <div class="form-text">Profil sayfalarında duvar bölümünü gösterir.</div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="form-check form-switch mb-3">
                            <input class="form-check-input" type="checkbox" name="enable_chat" value="1" id="enableChat" <?= ($social_settings['social_enable_chat'] ?? '1') == '1' ? 'checked' : '' ?>>
                            <label class="form-check-label fw-bold" for="enableChat">Messenger (Mini Chat) Etkinleştir</label>
                            <div class="form-text">Sağ alt köşede hızlı mesajlaşma penceresini gösterir.</div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-check form-switch mb-3">
                            <input class="form-check-input" type="checkbox" name="enable_trends" value="1" id="enableTrends" <?= ($social_settings['social_enable_trends'] ?? '1') == '1' ? 'checked' : '' ?>>
                            <label class="form-check-label fw-bold" for="enableTrends">Trendler Bölümünü Etkinleştir</label>
                            <div class="form-text">Haber kaynağında popüler etiketleri gösterir.</div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-check form-switch mb-3">
                            <input class="form-check-input" type="checkbox" name="enable_premium" value="1" id="enablePremium" <?= ($social_settings['social_premium_features'] ?? '1') == '1' ? 'checked' : '' ?>>
                            <label class="form-check-label fw-bold" for="enablePremium">Premium Özellikleri Etkinleştir</label>
                            <div class="form-text">Kapak fotoğrafı gibi özellikleri genel kullanıma açar.</div>
                        </div>
                    </div>

                </div>

                <hr class="my-4">
                
                <div class="text-end">
                    <button type="submit" class="btn btn-primary px-5 rounded-pill shadow-sm">
                        <i class="fas fa-save me-2"></i> Ayarları Kaydet
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
