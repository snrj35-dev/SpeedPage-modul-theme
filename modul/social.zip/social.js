// Profil Kapağını Uygula (JS ile Entegrasyon)
function applyProfileCover(val) {
    const headerCard = document.querySelector('.container.py-5 .card .bg-primary');
    if (headerCard) {
        if (val.startsWith('linear-gradient')) {
            headerCard.style.background = val;
        } else {
            headerCard.style.backgroundImage = `url('${val}')`;
            headerCard.style.backgroundSize = 'cover';
            headerCard.style.backgroundPosition = 'center';
        }
        // Gradienti kaldır veya üzerine bindir
        headerCard.classList.remove('bg-primary');
    }
}

// CSRF Token Helper
function getCsrfToken() {
    // const ile tanımlanan değişkenler window objesine bağlı değildir, doğrudan erişilmeli.
    try {
        return CSRF_TOKEN || '';
    } catch (e) {
        // Eğer tanımlı değilse alternatif yollar denenebilir veya boş döner.
        return '';
    }
}

// Genel AJAX Helper
async function socialFetch(action, data = {}) {
    const formData = new FormData();
    formData.append('action', action);
    formData.append('csrf', getCsrfToken());

    for (let key in data) {
        formData.append(key, data[key]);
    }

    try {
        const res = await fetch(BASE_URL + 'modules/social/ajax.php', {
            method: 'POST',
            body: formData
        });
        const text = await res.text();
        try {
            return JSON.parse(text);
        } catch (e) {
            console.error('JSON Parse Error:', e, 'Raw Response:', text);
            return { status: 'error', message: 'Sunucu hatası: Geçersiz yanıt.' };
        }
    } catch (err) {
        console.error('Social Action Error:', err);
        return { status: 'error', message: 'Bir hata oluştu.' };
    }
}

// Takip Etme
async function socialFollow(targetId) {
    const res = await socialFetch('follow', { target_id: targetId });
    if (res.status === 'success') location.reload();
}

// Engelleme
async function socialBlock(targetId) {
    if (!confirm('Bu kullanıcıyı engellemek istediğinize emin misiniz?')) return;
    const res = await socialFetch('block', { target_id: targetId });
    if (res.status === 'success') location.reload();
}

// React (Like)
async function socialReact(postId, type = 'like') {
    const res = await socialFetch('react', { post_id: postId, type: type });
    if (res.status === 'success') {
        const btn = document.querySelector(`.react-btn[data-id="${postId}"]`);
        if (btn) {
            btn.classList.toggle('text-primary', res.reacted);
            // Sayıyı güncelle (basitçe reload şimdilik veya DOM manipülasyonu)
            location.reload();
        }
    }
}

// Comment
async function socialComment(postId) {
    const input = document.querySelector(`#comment-input-${postId}`);
    const comment = input.value.trim();
    if (!comment) return;

    const res = await socialFetch('add_comment', { post_id: postId, comment: comment });
    if (res.status === 'success') location.reload();
}

// Post Sil
async function socialDeletePost(postId) {
    if (!confirm('Bu paylaşımı silmek istediğinize emin misiniz?')) return;
    const res = await socialFetch('delete_post', { post_id: postId });
    if (res.status === 'success') {
        document.querySelector(`.post-card-${postId}`)?.remove();
    }
}

// Duvara Yazma
document.addEventListener('click', async function (e) {
    if (e.target && e.target.id === 'submitWallPost') {
        const btn = e.target;
        const content = document.querySelector('#wallContent').value;
        const targetUser = document.querySelector('#wallTarget').value;

        if (!content.trim()) return;

        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Paylaşılıyor...';

        const res = await socialFetch('post_wall', { content: content, target_user: targetUser });
        if (res.status === 'success') {
            location.reload();
        } else {
            alert(res.message || 'Bir hata oluştu.');
            btn.disabled = false;
            btn.innerHTML = 'Paylaş';
        }
    }
});