<?php
declare(strict_types=1);
require_once '../../settings.php';
require_once '../../admin/db.php';

header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Bildirim sistemi ve diğer çekirdek fonksiyonlar
if (file_exists('../../php/notifications.php')) {
    require_once '../../php/notifications.php';
}

// CSRF Kontrolü (Direct access check)
$csrf = $_POST['csrf'] ?? '';
if (!$csrf || $csrf !== ($_SESSION['csrf'] ?? '')) {
    echo json_encode(['status' => 'error', 'message' => 'Güvenlik hatası (CSRF). Lütfen sayfayı yenileyin.']);
    exit;
}

$current_user = $_SESSION['user_id'] ?? 0;
$action = $_POST['action'] ?? '';

if (!$current_user) {
    echo json_encode(['status' => 'error', 'message' => 'Giriş yapmalısınız.']);
    exit;
}

// --- AKSİYONLAR ---
try {

// Takip Et / Bırak
if ($action === 'follow') {
    $target_id = (int)$_POST['target_id'];
    if ($target_id === $current_user) exit;

    $check = $db->prepare("SELECT id FROM social_follows WHERE follower_id = ? AND following_id = ?");
    $check->execute([$current_user, $target_id]);
    
    if ($check->fetch()) {
        $db->prepare("DELETE FROM social_follows WHERE follower_id = ? AND following_id = ?")->execute([$current_user, $target_id]);
        echo json_encode(['status' => 'success', 'followed' => false]);
    } else {
        $db->prepare("INSERT INTO social_follows (follower_id, following_id) VALUES (?, ?)")->execute([$current_user, $target_id]);
        
        // Bildirim ekle
        if (function_exists('addNotification')) {
            addNotification($target_id, $current_user, 'social', $current_user, 'follow', 'seni takip etmeye başladı.');
        }

        echo json_encode(['status' => 'success', 'followed' => true]);
    }
}


// Duvara Yaz
if ($action === 'post_wall') {
    $target_user = (int)$_POST['target_user'];
    $content = trim($_POST['content'] ?? '');
    
    if (!empty($content)) {
        $stmt = $db->prepare("INSERT INTO social_posts (user_id, author_id, content) VALUES (?, ?, ?)");
        $stmt->execute([$target_user, $current_user, $content]);
        
        // Bildirim
        if ($target_user !== $current_user && function_exists('addNotification')) {
            addNotification($target_user, $current_user, 'social', (int)$db->lastInsertId(), 'wall_post', 'duvarına yazdı.');
        }

        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'İçerik boş olamaz.']);
    }
}

// Yorum Yap
if ($action === 'add_comment') {
    $post_id = (int)$_POST['post_id'];
    $comment = trim($_POST['comment'] ?? '');

    if (!empty($comment)) {
        $stmt = $db->prepare("INSERT INTO social_comments (post_id, user_id, comment) VALUES (?, ?, ?)");
        $stmt->execute([$post_id, $current_user, $comment]);

        // Post sahibine bildirim
        $postOwner = $db->prepare("SELECT author_id FROM social_posts WHERE id = ?");
        $postOwner->execute([$post_id]);
        $ownerId = $postOwner->fetchColumn();

        if ($ownerId && $ownerId != $current_user && function_exists('addNotification')) {
            addNotification((int)$ownerId, $current_user, 'social', $post_id, 'comment', 'gönderine yorum yaptı.');
        }

        echo json_encode(['status' => 'success']);
    }
}

// Reaksiyon (Like)
if ($action === 'react') {
    $post_id = (int)$_POST['post_id'];
    $type = $_POST['type'] ?? 'like';

    $check = $db->prepare("SELECT id, user_id FROM social_reactions WHERE post_id = ? AND user_id = ?");
    $check->execute([$post_id, $current_user]);
    $existing = $check->fetch();

    // Kendi gönderisini beğenmeyi engelle
    $ownerStmt = $db->prepare("SELECT author_id FROM social_posts WHERE id = ?");
    $ownerStmt->execute([$post_id]);
    $author_id = (int)$ownerStmt->fetchColumn();

    if ($author_id === $current_user) {
        echo json_encode(['status' => 'error', 'message' => 'Kendi gönderinizi beğenmezsiniz.']);
        exit;
    }

    if ($existing) {
        $db->prepare("DELETE FROM social_reactions WHERE id = ?")->execute([$existing['id']]);
        echo json_encode(['status' => 'success', 'reacted' => false]);
    } else {
        $db->prepare("INSERT INTO social_reactions (post_id, user_id, type) VALUES (?, ?, ?)")->execute([$post_id, $current_user, $type]);
        
        // Bildirim
        $postOwner = $db->prepare("SELECT author_id FROM social_posts WHERE id = ?");
        $postOwner->execute([$post_id]);
        $ownerId = $postOwner->fetchColumn();
        if ($ownerId && $ownerId != $current_user && function_exists('addNotification')) {
            addNotification((int)$ownerId, $current_user, 'social', $post_id, 'like', 'gönderini beğendi.');
        }

        echo json_encode(['status' => 'success', 'reacted' => true]);
    }
}

// Post Sil
if ($action === 'delete_post') {
    $post_id = (int)$_POST['post_id'];
    
    // Yetki kontrolü: Postun yazarı mı, duvarın sahibi mi, yoksa admin mi?
    $stmt = $db->prepare("SELECT author_id, user_id FROM social_posts WHERE id = ?");
    $stmt->execute([$post_id]);
    $post = $stmt->fetch();

    if ($post) {
        $is_admin = isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
        if ($post['author_id'] == $current_user || $post['user_id'] == $current_user || $is_admin) {
            $db->prepare("DELETE FROM social_posts WHERE id = ?")->execute([$post_id]);
            $db->prepare("DELETE FROM social_comments WHERE post_id = ?")->execute([$post_id]);
            $db->prepare("DELETE FROM social_reactions WHERE post_id = ?")->execute([$post_id]);
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Yetkiniz yok.']);
        }
    }
}

// Engelleme
if ($action === 'block') {
    $target_id = (int)$_POST['target_id'];
    if ($target_id === $current_user) exit;

    $check = $db->prepare("SELECT id FROM social_blocks WHERE user_id = ? AND blocked_id = ?");
    $check->execute([$current_user, $target_id]);

    if ($check->fetch()) {
        $db->prepare("DELETE FROM social_blocks WHERE user_id = ? AND blocked_id = ?")->execute([$current_user, $target_id]);
        echo json_encode(['status' => 'success', 'blocked' => false]);
    } else {
        $db->prepare("INSERT INTO social_blocks (user_id, blocked_id) VALUES (?, ?)")->execute([$current_user, $target_id]);
        // Takipten çıkar
        $db->prepare("DELETE FROM social_follows WHERE (follower_id = ? AND following_id = ?) OR (follower_id = ? AND following_id = ?)")
           ->execute([$current_user, $target_id, $target_id, $current_user]);
        echo json_encode(['status' => 'success', 'blocked' => true]);
    }
}

// Mesaj Gönder (Chat)
if ($action === 'send_message') {
    $receiver_id = (int)$_POST['receiver_id'];
    $message = trim($_POST['message'] ?? '');

    if (!empty($message)) {
        $stmt = $db->prepare("INSERT INTO social_messages (sender_id, receiver_id, message) VALUES (?, ?, ?)");
        $stmt->execute([$current_user, $receiver_id, $message]);
        
        // Bildirim
        if (function_exists('addNotification')) {
            addNotification($receiver_id, $current_user, 'chat', (int)$db->lastInsertId(), 'new_message', 'sana bir mesaj gönderdi.');
        }

        echo json_encode(['status' => 'success']);
    }
}

// Mesajları Getir
if ($action === 'get_messages') {
    $chat_id = (int)$_POST['chat_id'];
    
    // Mesajları çek
    $stmt = $db->prepare("SELECT * FROM social_messages 
                          WHERE (sender_id = ? AND receiver_id = ?) 
                          OR (sender_id = ? AND receiver_id = ?) 
                          ORDER BY created_at ASC");
    $stmt->execute([$current_user, $chat_id, $chat_id, $current_user]);
    $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Okundu işaretle
    $db->prepare("UPDATE social_messages SET is_read = 1 WHERE sender_id = ? AND receiver_id = ?")->execute([$chat_id, $current_user]);

    echo json_encode(['status' => 'success', 'messages' => $messages]);
}

// Sohbet Listesi
if ($action === 'get_chat_list') {
    $stmt = $db->prepare("
        SELECT u.id, u.display_name, u.avatar_url,
        (SELECT message FROM social_messages WHERE (sender_id = u.id AND receiver_id = :me) OR (sender_id = :me AND receiver_id = u.id) ORDER BY created_at DESC LIMIT 1) as last_msg,
        (SELECT created_at FROM social_messages WHERE (sender_id = u.id AND receiver_id = :me) OR (sender_id = :me AND receiver_id = u.id) ORDER BY created_at DESC LIMIT 1) as last_msg_time,
        (SELECT COUNT(*) FROM social_messages WHERE sender_id = u.id AND receiver_id = :me AND is_read = 0) as unread_count
        FROM users u
        WHERE u.id != :me AND (
            EXISTS (SELECT 1 FROM social_follows WHERE follower_id = :me AND following_id = u.id) -- Takip ettiklerim
            OR EXISTS (SELECT 1 FROM social_follows WHERE follower_id = u.id AND following_id = :me) -- Beni takip edenler
            OR EXISTS (SELECT 1 FROM social_messages WHERE (sender_id = u.id AND receiver_id = :me) OR (sender_id = :me AND receiver_id = u.id)) -- Mesajlaştıklarım
        )
        ORDER BY (CASE WHEN last_msg_time IS NULL THEN 1 ELSE 0 END), last_msg_time DESC, u.display_name ASC
    ");
    $stmt->execute(['me' => $current_user]);
    $chats = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['status' => 'success', 'chats' => $chats]);
}

} catch (Throwable $e) {
    echo json_encode(['status' => 'error', 'message' => 'Sunucu hatası: ' . $e->getMessage()]);
}
