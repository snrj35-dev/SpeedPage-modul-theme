<?php
// modules/social/hooks.php
// Head kısmına CSS ekle (JS değişkenleri çekirdek sistem tarafından sağlanıyor)
add_hook('head_start', function() {
    echo '<link rel="stylesheet" href="'.BASE_URL.'modules/social/social.css?v='.time().'">';
});


// 1. Profil Başlığına Butonlar ve Kapak JS Ekle
add_hook('profile_header_badges', function($data) {
    global $db;
    $profile_user_id = $data['user']['id'];
    $current_user_id = $_SESSION['user_id'] ?? 0;

    // Kapak fotoğrafını JS ile uygulamak için değeri aktar
    $stmtCover = $db->prepare("SELECT meta_value FROM user_meta WHERE user_id = ? AND meta_key = 'cover_photo'");
    $stmtCover->execute([$profile_user_id]);
    $cover = $stmtCover->fetchColumn();
    if ($cover) {
        $coverVal = (strpos($cover, 'linear-gradient') !== false) ? $cover : BASE_URL . $cover;
        echo '<script>document.addEventListener("DOMContentLoaded", () => { applyProfileCover('
            . json_encode((string) $coverVal, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
            . '); });</script>';
    }

    if ($current_user_id && $current_user_id != $profile_user_id) {
        // Takip durumu kontrolü
        $stmt = $db->prepare("SELECT id FROM social_follows WHERE follower_id = ? AND following_id = ?");
        $stmt->execute([$current_user_id, $profile_user_id]);
        $is_following = $stmt->fetch();

        // Engelleme durumu kontrolü
        $stmt = $db->prepare("SELECT id FROM social_blocks WHERE user_id = ? AND blocked_id = ?");
        $stmt->execute([$current_user_id, $profile_user_id]);
        $is_blocked = $stmt->fetch();

        $btnText = $is_following ? 'Takibi Bırak' : 'Takip Et';
        $btnClass = $is_following ? 'btn-outline-danger' : 'btn-primary';

        echo '<button class="btn btn-sm '.$btnClass.' ms-2" onclick="socialFollow('.$profile_user_id.')">'.$btnText.'</button>';
        
        $blockText = $is_blocked ? 'Engeli Kaldır' : 'Engelle';
        echo '<button class="btn btn-sm btn-outline-secondary ms-1" onclick="socialBlock('.$profile_user_id.')"><i class="fas fa-ban me-1"></i>'.$blockText.'</button>';
    }
});

// 2. Yan Menüye (Sidebar) Takipçi İstatistiklerini ve Arkadaş Galerisini Ekle
add_hook('profile_sidebar', function($data) {
    global $db;
    $user_id = $data['user']['id'];

    $followers = $db->prepare("SELECT COUNT(*) FROM social_follows WHERE following_id = ?");
    $followers->execute([$user_id]);
    $fCount = $followers->fetchColumn();

    // Son Takipçiler (Arkadaş Galerisi niyetine)
    $stmt = $db->prepare("SELECT u.id, u.display_name, u.avatar_url FROM social_follows f JOIN users u ON f.follower_id = u.id WHERE f.following_id = ? LIMIT 6");
    $stmt->execute([$user_id]);
    $friends = $stmt->fetchAll();

    ?>
    <div class="card rounded-4 mb-4 border-0 shadow-sm">
        <div class="card-body">
            <h6 class="fw-bold mb-3"><i class="fas fa-share-alt text-primary me-2"></i>Sosyal Bilgiler</h6>
            <div class="d-flex justify-content-between mb-2">
                <span>Takipçi:</span>
                <span class="badge bg-primary rounded-pill"><?= $fCount ?></span>
            </div>
            <?php if(!empty($friends)): ?>
            <hr>
            <h6 class="fw-bold mb-2" style="font-size: 0.85rem;">Takipçiler</h6>
            <div class="d-flex flex-wrap gap-2">
                <?php foreach($friends as $fr): ?>
                    <a href="<?= BASE_URL ?>php/profile.php?id=<?= $fr['id'] ?>" title="<?= htmlspecialchars($fr['display_name']) ?>" class="text-decoration-none">
                        <div class="position-relative" style="width:35px; height:35px;">
                        <div class="rounded-circle bg-secondary w-100 h-100 d-flex align-items-center justify-content-center text-white">
                            <i class="fas <?= !empty($fr['avatar_url']) ? $fr['avatar_url'] : 'fa-user' ?>"></i>
                        </div>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php
});

// 3. Duvar (Wall) - Gelişmiş Render
add_hook('profile_bottom', function($data) {
    global $db;
    $profile_user_id = $data['user']['id'] ?? null;
    if (!$profile_user_id) return;

    $current_user_id = $_SESSION['user_id'] ?? 0;

    // Duvar yazılarını çek (+ Like sayısı ve yorum sayısı)
    $stmt = $db->prepare("SELECT p.*, u.display_name, u.avatar_url,
                          (SELECT COUNT(*) FROM social_reactions WHERE post_id = p.id) as like_count,
                          (SELECT COUNT(*) FROM social_comments WHERE post_id = p.id) as comment_count,
                          (SELECT 1 FROM social_reactions WHERE post_id = p.id AND user_id = ?) as user_liked
                          FROM social_posts p 
                          JOIN users u ON p.author_id = u.id 
                          WHERE p.user_id = ? 
                          ORDER BY p.created_at DESC");
    $stmt->execute([$current_user_id, $profile_user_id]);
    $posts = $stmt->fetchAll();

    ?>
    <div class="row mt-4 mb-5">
        <div class="col-md-8 mx-auto">
            <div class="d-flex align-items-center mb-3">
                <h5 class="fw-bold mb-0"><i class="fas fa-comment-alt text-primary me-2"></i>Kullanıcı Duvarı</h5>
                <span class="badge bg-white text-primary ms-2 border border-primary-subtle rounded-pill"><?= count($posts) ?> Paylaşım</span>
            </div>
            
            <?php if($current_user_id): ?>
            <div class="card mb-4 border-0 shadow-sm rounded-4 overflow-hidden">
                <div class="card-body p-3">
                    <input type="hidden" id="wallTarget" value="<?= $profile_user_id ?>">
                    <textarea id="wallContent" class="form-control border-0 bg-light rounded-3 mb-2" rows="2" placeholder="Neler düşünüyorsun?"></textarea>
                    <div class="d-flex justify-content-end align-items-center">
                        <button id="submitWallPost" class="btn btn-primary btn-sm rounded-pill px-4">
                            Paylaş
                        </button>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <div id="social-feed">
                <?php if(empty($posts)): ?>
                    <div class="text-center py-5 bg-white rounded-4 shadow-sm border-dashed">
                        <i class="fas fa-feather fa-3x text-muted mb-3 opacity-25"></i>
                        <p class="text-muted">Daha önce kimse bir şey yazmamış.</p>
                    </div>
                <?php else: ?>
                    <?php foreach($posts as $post): ?>
                        <div class="card mb-3 border-0 shadow-sm rounded-4 social-post-card post-card-<?= $post['id'] ?>">
                            <div class="card-body p-3">
                                <div class="d-flex justify-content-between mb-2">
                                    <div class="d-flex align-items-center">
                                        <div class="position-relative me-2" style="width:38px; height:38px;">
                                            <div class="rounded-circle bg-secondary w-100 h-100 d-flex align-items-center justify-content-center text-white">
                                                <i class="fas <?= !empty($post['avatar_url']) ? $post['avatar_url'] : 'fa-user' ?>"></i>
                                            </div>
                                        </div>
                                        <div>
                                            <h6 class="mb-0 fw-bold"><?= htmlspecialchars($post['display_name']) ?></h6>
                                            <small class="text-muted" style="font-size: 11px;"><?= $post['created_at'] ?></small>
                                        </div>
                                    </div>
                                    <?php if($post['author_id'] == $current_user_id || $profile_user_id == $current_user_id || (isset($_SESSION['role']) && $_SESSION['role'] === 'admin')): ?>
                                    <div class="dropdown">
                                        <button class="btn btn-link text-muted p-0" data-bs-toggle="dropdown"><i class="fas fa-ellipsis-h"></i></button>
                                        <ul class="dropdown-menu dropdown-menu-end shadow border-0 rounded-3">
                                            <li><a class="dropdown-item text-danger" href="javascript:void(0)" onclick="socialDeletePost(<?= $post['id'] ?>)"><i class="fas fa-trash-alt me-2"></i>Sil</a></li>
                                        </ul>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <p class="card-text text-secondary mb-3"><?= nl2br(htmlspecialchars($post['content'])) ?></p>
                                

                                <div class="post-actions d-flex border-top pt-2">
                                    <button class="btn btn-link btn-sm text-decoration-none react-btn <?= $post['user_liked'] ? 'text-primary' : 'text-muted' ?>" data-id="<?= $post['id'] ?>" onclick="socialReact(<?= $post['id'] ?>)">
                                        <i class="fa<?= $post['user_liked'] ? 's' : 'r' ?> fa-heart me-1"></i> Beğen (<?= $post['like_count'] ?>)
                                    </button>
                                    <button class="btn btn-link btn-sm text-decoration-none text-muted ms-2" onclick="document.getElementById('comment-box-<?= $post['id'] ?>').classList.toggle('d-none')">
                                        <i class="far fa-comment me-1"></i> Yorum (<?= $post['comment_count'] ?>)
                                    </button>
                                </div>

                                <!-- Yorumlar Kutusu -->
                                <div id="comment-box-<?= $post['id'] ?>" class="comment-section mt-3 d-none">
                                    <div class="comments-list mb-2">
                                        <?php
                                        $cStmt = $db->prepare("SELECT c.*, u.display_name, u.avatar_url FROM social_comments c JOIN users u ON c.user_id = u.id WHERE c.post_id = ? ORDER BY c.created_at ASC");
                                        $cStmt->execute([$post['id']]);
                                        while($comment = $cStmt->fetch()):
                                        ?>
                                            <div class="d-flex mb-2">
                                                <div class="position-relative me-2" style="width:28px; height:28px;">
                                                    <div class="rounded-circle bg-secondary w-100 h-100 d-flex align-items-center justify-content-center text-white">
                                                        <i class="fas <?= !empty($comment['avatar_url']) ? $comment['avatar_url'] : 'fa-user' ?>"></i>
                                                    </div>
                                                </div>
                                                <div class="bg-light rounded-3 p-2 flex-grow-1" style="font-size: 0.9rem;">
                                                    <div class="fw-bold"><?= htmlspecialchars($comment['display_name']) ?></div>
                                                    <div><?= nl2br(htmlspecialchars($comment['comment'])) ?></div>
                                                </div>
                                            </div>
                                        <?php endwhile; ?>
                                    </div>
                                    <?php if($current_user_id): ?>
                                    <div class="d-flex gap-2">
                                        <input type="text" id="comment-input-<?= $post['id'] ?>" class="form-control form-control-sm rounded-pill" placeholder="Bir şeyler yaz...">
                                        <button class="btn btn-primary btn-sm rounded-pill px-3" onclick="socialComment(<?= $post['id'] ?>)">Gönder</button>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    </script>
    <?php
});

// Footer kısmına JS ekle
add_hook('profile_bottom', function() {
    echo '<script src="'.BASE_URL.'modules/social/social.js?v='.time().'"></script>';
});

// 4. Profil Ayarlarına Kapak Fotoğrafı ve Gizlilik Ekle
add_hook('profile_form_middle', function($data) {
    global $db;
    $user_id = $data['user']['id'];

    $stmt = $db->prepare("SELECT meta_value FROM user_meta WHERE user_id = ? AND meta_key = 'privacy_level'");
    $stmt->execute([$user_id]);
    $privacy = $stmt->fetchColumn() ?: 'public';

    ?>
    <hr class="my-4">
    <h6 class="fw-bold text-primary mb-3"><i class="fas fa-users-cog me-2"></i>Sosyal Ayarlar</h6>
    <?php
    $stmtCover = $db->prepare("SELECT meta_value FROM user_meta WHERE user_id = ? AND meta_key = 'cover_photo'");
    $stmtCover->execute([$user_id]);
    $currentCover = $stmtCover->fetchColumn() ?: "linear-gradient(45deg, #4e73df, #224abe)";
    ?>
    <div class="col-12 mb-4">
        <label class="form-label small fw-bold">Profil Kapağı (Gradient)</label>
        
        <!-- Önizleme -->
        <div id="coverPreview" class="rounded-4 mb-3 shadow-sm border" style="height: 120px; background: <?= e($currentCover) ?>; display: flex; align-items: center; justify-content: center; color: white; text-shadow: 0 2px 4px rgba(0,0,0,0.3);">
            <span class="fw-bold">Görünüm Önizlemesi</span>
        </div>

        <input type="hidden" name="social_cover_gradient" id="socialCoverGradient" value="<?= e($currentCover) ?>">

        <div class="d-flex flex-wrap gap-2 mb-3">
            <?php
            $presets = [
                "Blue Ocean" => "linear-gradient(45deg, #4e73df, #224abe)",
                "Purple Night" => "linear-gradient(45deg, #6a11cb, #2575fc)",
                "Sunset" => "linear-gradient(45deg, #f093fb, #f5576c)",
                "Forest" => "linear-gradient(45deg, #5ee7df, #b490ca)",
                "Darkness" => "linear-gradient(45deg, #2c3e50, #000000)",
                "Gold" => "linear-gradient(45deg, #f6d365, #fda085)"
            ];
            foreach ($presets as $name => $grad): ?>
                <button type="button" class="btn btn-sm btn-outline-secondary rounded-pill px-3 grad-preset" data-grad="<?= e($grad) ?>"><?= e($name) ?></button>
            <?php endforeach; ?>
        </div>

        <div class="row g-2 align-items-center">
            <div class="col-auto"><span class="small text-muted">Özel Renkler:</span></div>
            <div class="col-auto"><input type="color" id="gradColor1" class="form-control form-control-color form-control-sm rounded-circle" value="#4e73df"></div>
            <div class="col-auto"><input type="color" id="gradColor2" class="form-control form-control-color form-control-sm rounded-circle" value="#224abe"></div>
            <div class="col-auto">
                <select id="gradAngle" class="form-select form-select-sm rounded-pill w-auto">
                    <option value="45deg">45°</option>
                    <option value="90deg">90°</option>
                    <option value="135deg">135°</option>
                    <option value="180deg">180°</option>
                </select>
            </div>
            <div class="col-auto">
                <button type="button" id="applyCustomGrad" class="btn btn-sm btn-primary rounded-pill px-3">Uygula</button>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', () => {
        const preview = document.getElementById('coverPreview');
        const hiddenInput = document.getElementById('socialCoverGradient');
        
        document.querySelectorAll('.grad-preset').forEach(btn => {
            btn.addEventListener('click', () => {
                const grad = btn.dataset.grad;
                preview.style.background = grad;
                hiddenInput.value = grad;
            });
        });

        document.getElementById('applyCustomGrad').addEventListener('click', () => {
            const c1 = document.getElementById('gradColor1').value;
            const c2 = document.getElementById('gradColor2').value;
            const angle = document.getElementById('gradAngle').value;
            const grad = `linear-gradient(${angle}, ${c1}, ${c2})`;
            preview.style.background = grad;
            hiddenInput.value = grad;
        });
    });
    </script>
    <div class="col-md-6 mb-3">
        <label class="form-label small fw-bold">Profil Gizliliği</label>
        <select name="privacy_level" class="form-select rounded-3">
            <option value="public" <?= $privacy === 'public' ? 'selected' : '' ?>>Herkes Görebilir</option>
            <option value="followers" <?= $privacy === 'followers' ? 'selected' : '' ?>>Sadece Takipçilerim</option>
            <option value="private" <?= $privacy === 'private' ? 'selected' : '' ?>>Sadece Ben</option>
        </select>
        <div class="form-text">Profilinizi kimlerin görebileceğini belirleyin.</div>
    </div>
    <?php
});

// 5. Profil Kayıt İşlemini Yakala
add_hook('profile_handle_save', function($data) {
    global $db;
    $user_id = $data['user_id'];
    $post = $data['post_data'];

    // Gizlilik Ayarını Kaydet
    if (isset($post['privacy_level'])) {
        $db->prepare("DELETE FROM user_meta WHERE user_id = ? AND meta_key = 'privacy_level'")->execute([$user_id]);
        $db->prepare("INSERT INTO user_meta (user_id, meta_key, meta_value) VALUES (?, 'privacy_level', ?)")->execute([$user_id, $post['privacy_level']]);
    }

    // Kapak Gradient Kaydet
    if (isset($post['social_cover_gradient'])) {
        $grad = $post['social_cover_gradient'];
        $db->prepare("DELETE FROM user_meta WHERE user_id = ? AND meta_key = 'cover_photo'")->execute([$user_id]);
        $db->prepare("INSERT INTO user_meta (user_id, meta_key, meta_value) VALUES (?, 'cover_photo', ?)")->execute([$user_id, $grad]);
    }
});

// 6. Mini Chat (Messenger) UI & Logic
add_hook('footer_end', function() {
    global $db;
    $current_user_id = $_SESSION['user_id'] ?? 0;
    if (!$current_user_id) return;

    // Ayarlardan kontrol et
    $stmt = $db->prepare("SELECT value FROM settings WHERE `key` = 'social_enable_chat'");
    $stmt->execute();
    if ($stmt->fetchColumn() === '0') return;

    ?>
    <div id="mini-chat-container" style="position: fixed; bottom: 85px; right: 20px; z-index: 1000; width: 300px; display: none;">
        <div class="card border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center py-2">
                <div class="d-flex align-items-center">
                    <div id="chat-avatar-wrapper" class="me-2 d-none rounded-circle bg-secondary text-white align-items-center justify-content-center" style="width:25px; height:25px;">
                        <i id="chat-avatar-icon" class="fas fa-user" style="font-size: 0.7em;"></i>
                    </div>
                    <span id="chat-title" class="fw-bold small">Mesajlar</span>
                </div>
                <div>
                    <button class="btn btn-sm text-white p-0 me-2" onclick="toggleChatList()"><i class="fas fa-list"></i></button>
                    <button class="btn btn-sm text-white p-0" onclick="closeChat()"><i class="fas fa-times"></i></button>
                </div>
            </div>
            
            <div id="chat-list" class="list-group list-group-flush" style="max-height: 350px; overflow-y: auto;">
                <!-- Sohbet listesi buraya gelecek -->
            </div>

            <div id="chat-messages" class="p-3 bg-light d-none" style="height: 300px; overflow-y: auto;">
                <!-- Mesajlar buraya gelecek -->
            </div>

            <div id="chat-input-area" class="p-2 border-top d-none">
                <div class="input-group">
                    <input type="text" id="chat-input" class="form-control form-control-sm border-0 bg-light rounded-pill px-3" placeholder="Mesaj yaz...">
                    <button class="btn btn-primary btn-sm rounded-circle ms-2" onclick="sendChatMessage()" style="width:32px; height:32px;"><i class="fas fa-paper-plane fa-xs"></i></button>
                </div>
            </div>
        </div>
    </div>

    <!-- Sohbet Butonu -->
    <div id="chat-toggle-btn" onclick="toggleMiniChat()" style="position: fixed; bottom: 85px; right: 20px; z-index: 999; width: 60px; height: 60px; border-radius: 50%; background: #0084ff; color: white; display: flex; align-items: center; justify-content: center; cursor: pointer; box-shadow: 0 4px 15px rgba(0,0,0,0.2); border: 4px solid #fff;">
        <i class="fas fa-comment-dots fa-lg"></i>
    </div>

    <style>
    .chat-msg { margin-bottom: 10px; padding: 8px 12px; border-radius: 18px; font-size: 0.85rem; width: fit-content; max-width: 85%; }
    .chat-msg-sent { background: #0084ff; color: white; margin-left: auto; border-bottom-right-radius: 4px; }
    .chat-msg-received { background: #e4e6eb; color: black; margin-right: auto; border-bottom-left-radius: 4px; }
    #chat-list .list-group-item:hover { background-color: #f8f9fa; cursor: pointer; }
    .avatar-fallback { display: none; align-items: center; justify-content: center; background-color: #6c757d; color: white; border-radius: 50%; width: 100%; height: 100%; font-size: 0.8em; }
        </style>

    <script>
    var activeChatId = null;
    var chatPollInterval = null;

    function toggleMiniChat() {
        const container = document.getElementById('mini-chat-container');
        if (container.style.display === 'none') {
            container.style.display = 'block';
            document.getElementById('chat-toggle-btn').classList.add('d-none');
            loadChatList();
        } else {
            closeChat();
        }
    }

    function closeChat() {
        document.getElementById('mini-chat-container').style.display = 'none';
        document.getElementById('chat-toggle-btn').classList.remove('d-none');
        activeChatId = null;
        clearInterval(chatPollInterval);
    }

    function toggleChatList() {
    document.getElementById('chat-list').classList.remove('d-none');
    document.getElementById('chat-messages').classList.add('d-none');
    document.getElementById('chat-input-area').classList.add('d-none');
    document.getElementById('chat-title').innerText = 'Mesajlar';
    
    // Hata veren kısım burasıydı, wrapper'ı gizliyoruz
    const avatarWrapper = document.getElementById('chat-avatar-wrapper');
    if (avatarWrapper) {
        avatarWrapper.classList.add('d-none');
        avatarWrapper.classList.remove('d-flex');
    }
    
    activeChatId = null;
    loadChatList();
}

    // Global erişim
    window.toggleMiniChat = toggleMiniChat;
    window.closeChat = closeChat;
    window.toggleChatList = toggleChatList;
    
    // Diğerleri aşağıda tanımlı
    
    if (!window.socialChatInitialized) {
        window.socialChatInitialized = true;
        
        var chatInput = document.getElementById('chat-input');
        if (chatInput) {
            chatInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    sendChatMessage();
                }
            });
        }
    }

    async function loadChatList() {
        const res = await socialFetch('get_chat_list');
        if (res.status === 'success') {
            const list = document.getElementById('chat-list');
            list.innerHTML = '';
            res.chats.forEach(chat => {
                const item = document.createElement('div');
                item.className = 'list-group-item border-0 d-flex align-items-center py-3';
                item.onclick = () => openChat(chat.id, chat.display_name, chat.avatar_url);
                item.innerHTML = `
                    <div class="position-relative me-3 rounded-circle bg-secondary d-flex align-items-center justify-content-center text-white" style="width:40px; height:40px;">
                        <i class="fas ${chat.avatar_url || 'fa-user'}"></i>
                        ${parseInt(chat.unread_count) > 0 ? '<span class="position-absolute top-0 start-100 translate-middle p-1 bg-danger border border-light rounded-circle"></span>' : ''}
                    </div>
                    <div style="line-height: 1.2;">
                        <div class="fw-bold small">${chat.display_name}</div>
                        <div class="text-muted small text-truncate" style="max-width: 150px;">${chat.last_msg || 'Sohbeti başlatın...'}</div>
                    </div>
                `;
                list.appendChild(item);
            });
            if (res.chats.length === 0) {
                list.innerHTML = '<div class="p-4 text-center text-muted small">Henüz mesajınız yok.</div>';
            }
        }
    }

    async function openChat(userId, name, avatar) {
        activeChatId = userId;
        document.getElementById('chat-title').innerText = name;
        
        const wrapper = document.getElementById('chat-avatar-wrapper');
        const icon = document.getElementById('chat-avatar-icon');
        
        wrapper.classList.remove('d-none');
        wrapper.classList.add('d-flex');
        
        icon.className = `fas ${avatar || 'fa-user'}`;
        
        document.getElementById('chat-list').classList.add('d-none');
        document.getElementById('chat-messages').classList.remove('d-none');
        document.getElementById('chat-input-area').classList.remove('d-none');
        
        loadMessages();
        clearInterval(chatPollInterval);
        chatPollInterval = setInterval(loadMessages, 3000);
    }

    async function loadMessages() {
        if (!activeChatId) return;
        const res = await socialFetch('get_messages', { chat_id: activeChatId });
        if (res.status === 'success') {
            const msgBox = document.getElementById('chat-messages');
            const atBottom = msgBox.scrollHeight - msgBox.scrollTop <= msgBox.clientHeight + 50;
            
            msgBox.innerHTML = '';
            res.messages.forEach(m => {
                const div = document.createElement('div');
                div.className = `chat-msg ${m.sender_id == activeChatId ? 'chat-msg-received' : 'chat-msg-sent'}`;
                div.innerText = m.message;
                msgBox.appendChild(div);
            });

            if (atBottom) msgBox.scrollTop = msgBox.scrollHeight;
        }
    }

    async function sendChatMessage() {
        const input = document.getElementById('chat-input');
        const msg = input.value.trim();
        if (!msg || !activeChatId) return;

        const res = await socialFetch('send_message', { receiver_id: activeChatId, message: msg });
        if (res.status === 'success') {
            input.value = '';
            loadMessages();
        }
    }

    // Assign remaining functions to global window object
    window.loadChatList = loadChatList;
    window.openChat = openChat;
    window.loadMessages = loadMessages;
    window.sendChatMessage = sendChatMessage;
    </script>
    <?php
});
