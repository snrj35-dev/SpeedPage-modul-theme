<?php
// modules/social/uninstall.php
global $db;

$queries = [
    "DROP TABLE IF EXISTS social_follows",
    "DROP TABLE IF EXISTS social_blocks",
    "DROP TABLE IF EXISTS social_posts",
    "DROP TABLE IF EXISTS social_comments",
    "DROP TABLE IF EXISTS social_reactions"
];

foreach ($queries as $q) {
    $db->exec($q);
}
