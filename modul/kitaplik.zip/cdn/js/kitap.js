// JavaScript'iniz önceki adımda temizlendiği ve sadece okuma işlevini tuttuğu için
// buraya sadece okuma bloğunu ekledim.
let book;
let rendition;
const viewerContainer = document.getElementById('viewer-container');
const viewer = document.getElementById('viewer');
const btnNext = document.getElementById('next');
const btnPrev = document.getElementById('prev');
const btnClose = document.getElementById('close-viewer');

// Kitaplara tıklanınca çalışan fonksiyon
document.querySelectorAll('.book-item').forEach(item => {
    item.addEventListener('click', function() {
        const bookPath = this.getAttribute('data-path');
        
        // Okuyucuyu göster
        viewerContainer.style.display = 'block';
        
        // Eski rendisyonu temizle
        if (rendition) {
            rendition.destroy();
            rendition = null;
        }

        // 1. EPUB dosyasını fetch ile blob olarak al
        fetch(bookPath)
            .then(response => response.blob())
            .then(blob => {
                // 2. ePub.js ile Kitap Objesini oluştur
                book = ePub(blob);
                
                // 3. Rendisyonu oluştur ve görüntüle
                rendition = book.renderTo(viewer, {
                    width: "100%",
                    height: "100%",
                    method: "continuous", // Veya "default"
                });
                
                // 4. Kitabı görüntüle
                return rendition.display();
            })
            .then(() => {
                // 5. Kontrolleri etkinleştir
                btnNext.disabled = false;
                btnPrev.disabled = false;
            })
            .catch(error => {
                console.error("Kitap yüklenirken bir hata oluştu:", error);
                alert("Kitap yüklenirken bir sorun oluştu.");
                viewerContainer.style.display = 'none'; // Hata durumunda okuyucuyu kapat
            });
    });
});

// Sayfalama Kontrolleri
btnNext.onclick = () => {
    if (rendition) rendition.next();
};

btnPrev.onclick = () => {
    if (rendition) rendition.prev();
};

// Kapatma Fonksiyonu
btnClose.onclick = () => {
    viewerContainer.style.display = 'none';
    if (rendition) {
        rendition.destroy(); // Bellek temizliği
        rendition = null;
    }
};

