<?php
/**
 * Kitaplık Modülü
 * EPUB dosyalarını kategorilere göre listeler
 */

function shortenTitle($text, $maxLength = 25)
{
    if (mb_strlen($text, 'UTF-8') > $maxLength) {
        return mb_substr($text, 0, $maxLength, 'UTF-8') . '...';
    }
    return $text;
}

$baseDir = ROOT_DIR . 'media/kitaplar/';
$library = [];

if (is_dir($baseDir)) {
    $categories = array_diff(scandir($baseDir), ['.', '..']);
    foreach ($categories as $category) {
        $categoryPath = $baseDir . $category . '/';
        if (is_dir($categoryPath)) {
            $files = array_diff(scandir($categoryPath), ['.', '..']);
            $books = [];
            foreach ($files as $file) {
                if (pathinfo($file, PATHINFO_EXTENSION) === 'epub') {
                    $bookTitle = pathinfo($file, PATHINFO_FILENAME);
                    $coverPath = null;
                    $relativeCover = "media/kitaplar/" . $category . "/" . $bookTitle;
                    if (file_exists($categoryPath . $bookTitle . '.jpg')) {
                        $coverPath = BASE_URL . $relativeCover . '.jpg';
                    } elseif (file_exists($categoryPath . $bookTitle . '.png')) {
                        $coverPath = BASE_URL . $relativeCover . '.png';
                    }
                    $books[] = [
                        'title' => $bookTitle,
                        'display_title' => shortenTitle($bookTitle),
                        'path' => $categoryPath . $file,
                        'cover_path' => $coverPath
                    ];
                }
            }
            if (!empty($books)) {
                $displayCategory = ucwords(str_replace(['-', '_'], ' ', $category));
                $library[$displayCategory] = $books;
            }
        }
    }
}
?>

<div class="container mt-5">
    <?php if (empty($library)): ?>
        <div class="alert alert-info">
            📂 Henüz kitap bulunamadı.<br>
            Lütfen ana dizinde <code>media/kitaplar/</code> klasörü içinde kategori klasörleri (ör. <code>roman/</code>,
            <code>bilimkurgu/</code>) oluşturun ve içine <code>.epub</code> dosyaları ekleyin.
        </div>
    <?php else: ?>
        <?php foreach ($library as $category => $books): ?>
            <div class="card p-4 mb-4 shadow-sm">
                <h2><?= htmlspecialchars($category) ?></h2>
                <ul class="book-list">
                    <?php foreach ($books as $book): ?>
                        <li class="book-item" data-path="<?= htmlspecialchars(str_replace(ROOT_DIR, BASE_URL, $book['path'])) ?>">
                            <div class="book-cover">
                                <?php if ($book['cover_path']): ?>
                                    <img src="<?= htmlspecialchars($book['cover_path']) ?>"
                                        alt="<?= htmlspecialchars($book['title']) ?> Kapak Resmi">
                                <?php else: ?>
                                    <span><?= htmlspecialchars($book['title']) ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="book-title" title="<?= htmlspecialchars($book['title']) ?>">
                                <?= htmlspecialchars($book['display_title']) ?>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<div id="viewer-container">
    <span id="close-viewer">❌ Kapat</span>
    <div id="viewer"></div>
    <div id="controls">
        <button id="prev">◀ Önceki</button>
        <button id="next">Sonraki ▶</button>
    </div>
</div>
