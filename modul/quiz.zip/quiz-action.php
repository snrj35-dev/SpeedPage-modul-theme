<?php
require_once __DIR__ . '/../../settings.php';
require_once __DIR__ . '/../../admin/db.php';
require_once __DIR__ . '/quiz-func.php';

// Session başlatma (eğer başlatılmamışsa)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json');

// Yardımcı fonksiyonlar
function requireLogin(): void {
    if (!isset($_SESSION['user_id'])) {
        jsonResponse(['success' => false, 'message' => __('Oturum açmalısınız')], 401);
    }
}

function requireRole(string $role): void {
    $userRole = $_SESSION['role'] ?? 'user';
    // Admin her şeye erişebilir, editor de erişebilir
    if ($userRole !== 'admin' && $userRole !== $role) {
        jsonResponse(['success' => false, 'message' => __('Yetkisiz erişim')], 403);
    }
}

function validateCsrfToken(string $token): bool {
    return isset($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $token);
}

function requirePostMethod(): void {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        jsonResponse(['success' => false, 'message' => __('Geçersiz istek yöntemi')], 405);
    }
}

function jsonResponse(array $data, int $statusCode = 200): void {
    http_response_code($statusCode);
    echo json_encode($data);
    exit;
}

function t(string $key): string {
    return __($key);
}

$action = $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'getQuiz':
            $quizId = $_GET['id'] ?? 0;
            
            $quiz = getQuizById((int)$quizId);
            
            if (!$quiz) {
                jsonResponse(['success' => false, 'message' => t('errors.quiz_not_found')], 404);
            }
            
            // Soruları getir
            $randomize = (bool)($quiz['random_questions'] ?? false);
            $limit = (int)($quiz['questions_per_quiz'] ?? 0);
            
            $questions = getQuizQuestions((int)$quizId, $randomize, $limit);
            
            // Soruları quiz objesine ekle
            $quiz['questions'] = $questions;
            
            jsonResponse(['ok' => true, 'quiz' => $quiz]);
            break;
            
        case 'submitQuiz':
            requireLogin();
            requirePostMethod();
            
            $input = json_decode(file_get_contents('php://input'), true);
            if (!validateCsrfToken((string) ($input['csrf_token'] ?? ''))) {
                jsonResponse(['success' => false, 'message' => t('errors.invalid_token')], 403);
            }
            
            $quizId = (int)($input['quiz_id'] ?? 0);
            $answers = $input['answers'] ?? [];
            $timeSpent = (int)($input['time_spent'] ?? 0);
            
            $result = submitQuizResult((int)$_SESSION['user_id'], $quizId, $answers, $timeSpent);
            
            jsonResponse(['success' => true, ...$result]);
            break;
            
        case 'getQuizzes':
            requireRole('editor');
            
            $quizzes = getAllQuizzes();
            
            jsonResponse(['success' => true, 'quizzes' => $quizzes]);
            break;
            
        case 'getCategories':
            requireRole('editor');
            
            $categories = getQuizCategories();
            
            jsonResponse(['success' => true, 'categories' => $categories]);
            break;
            
        case 'createCategory':
            requireRole('editor');
            requirePostMethod();
            
            $input = json_decode(file_get_contents('php://input'), true);
            
            if (!validateCsrfToken($input['csrf_token'] ?? '')) {
                jsonResponse(['success' => false, 'message' => t('errors.invalid_token')], 403);
            }
            
            $categoryId = createQuizCategory(
                $input['name'],
                $input['description'] ?? '',
                $input['icon'] ?? 'fa-folder',
                $input['color'] ?? '#4F46E5'
            );
            
            jsonResponse(['success' => true, 'category_id' => $categoryId]);
            break;
            
        case 'deleteCategory':
            requireRole('admin');
            requirePostMethod();
            
            $input = json_decode(file_get_contents('php://input'), true);
            
            if (!validateCsrfToken($input['csrf_token'] ?? '')) {
                jsonResponse(['success' => false, 'message' => t('errors.invalid_token')], 403);
            }
            
            $id = (int)($input['id'] ?? 0);
            deleteQuizCategory($id);
            
            jsonResponse(['success' => true]);
            break;
            
        case 'deleteQuiz':
            requireRole('editor');
            requirePostMethod();
            
            $input = json_decode(file_get_contents('php://input'), true);
            
            if (!validateCsrfToken($input['csrf_token'] ?? '')) {
                jsonResponse(['success' => false, 'message' => t('errors.invalid_token')], 403);
            }
            
            $id = (int)($input['id'] ?? 0);
            deleteQuiz($id);
            
            jsonResponse(['success' => true]);
            break;
            
        case 'createQuiz':
            requireRole('editor');
            requirePostMethod();
            
            $input = json_decode(file_get_contents('php://input'), true);
            
            if (!validateCsrfToken($input['csrf_token'] ?? '')) {
                jsonResponse(['success' => false, 'message' => t('errors.invalid_token')], 403);
            }
            
            $quizId = createQuiz($input);
            
            jsonResponse(['success' => true, 'quiz_id' => $quizId]);
            break;
            
        case 'getQuizDetails':
            requireRole('editor');
            
            $quizId = (int)($_GET['id'] ?? 0);
            
            $quiz = getQuizById($quizId);
            
            if (!$quiz) {
                jsonResponse(['success' => false, 'message' => t('errors.quiz_not_found')], 404);
            }
            
            // Soruları ve cevapları getir
            global $db;
            $stmt = $db->prepare("
                SELECT q.* FROM questions q
                WHERE q.quiz_id = ?
                ORDER BY q.question_order ASC
            ");
            $stmt->execute([$quizId]);
            $questions = $stmt->fetchAll();
            
            foreach ($questions as &$question) {
                $stmt = $db->prepare("SELECT * FROM answers WHERE question_id = ?");
                $stmt->execute([$question['id']]);
                $question['answers'] = $stmt->fetchAll();
            }
            
            $quiz['questions'] = $questions;
            jsonResponse(['success' => true, 'quiz' => $quiz]);
            break;
            
        case 'updateQuiz':
            requireRole('editor');
            requirePostMethod();
            
            $input = json_decode(file_get_contents('php://input'), true);
            
            if (!validateCsrfToken($input['csrf_token'] ?? '')) {
                jsonResponse(['success' => false, 'message' => t('errors.invalid_token')], 403);
            }
            
            $quizId = (int)($input['id'] ?? 0);
            updateQuiz($quizId, $input);
            
            jsonResponse(['success' => true]);
            break;
            
        case 'getStatistics':
            requireRole('editor');
            
            $quizId = (int)($_GET['quiz_id'] ?? 0);
            
            if ($quizId) {
                $stats = getQuizStatistics($quizId);
            } else {
                // Genel istatistikler
                global $db;
                $stmt = $db->query("
                    SELECT 
                        COUNT(DISTINCT quiz_id) as total_quizzes,
                        COUNT(*) as total_attempts,
                        COUNT(DISTINCT user_id) as total_users,
                        AVG(percentage) as avg_percentage,
                        SUM(CASE WHEN passed = 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(*) as pass_rate
                    FROM user_results
                ");
                $stats = $stmt->fetch();
            }
            
            jsonResponse(['success' => true, 'statistics' => $stats]);
            break;
            
        default:
            jsonResponse(['success' => false, 'message' => t('errors.something_wrong')], 400);
    }
    
} catch (Exception $e) {
    jsonResponse(['success' => false, 'message' => $e->getMessage()], 500);
}
