let currentQuestion = 0;
let questions = [];
let userAnswers = [];
let lastQuizId = null;
let isLoading = false;

// API'den Quiz Verilerini Çek
async function loadQuiz() {
    const container = document.getElementById('quiz-container');
    const quizId = container ? container.dataset.quizId : null;

    // Eğer ID yoksa veya zaten bu ID'yi yüklüyorsak/yüklediysek işlem yapma
    if (!quizId || isLoading || getattr(container, 'data-loaded') === 'true') return;

    // Eğer yeni bir quiz ise state'i sıfırla (SPA problemi çözümü)
    if (quizId !== lastQuizId) {
        questions = [];
        userAnswers = [];
        currentQuestion = 0;
        lastQuizId = quizId;
    }

    isLoading = true;

    try {
        const response = await fetch(`modules/quiz/quiz-action.php?action=getQuiz&id=${quizId}`);
        const data = await response.json();

        if (data.ok && data.quiz) {
            questions = data.quiz.questions;
            userAnswers = new Array(questions.length).fill(null);

            const loadingEl = document.getElementById('quiz-loading');
            const contentEl = document.getElementById('quiz-content');

            if (loadingEl) loadingEl.classList.add('d-none');
            if (contentEl) contentEl.classList.remove('d-none');

            // İşaretle ki tekrar yüklemeye çalışmasın
            container.setAttribute('data-loaded', 'true');

            showQuestion(0);
        } else {
            showError("Quiz verisi alınamadı! " + (data.message || ''));
        }
    } catch (error) {
        console.error("Hata:", error);
        showError("Bir bağlantı hatası oluştu.");
    } finally {
        isLoading = false;
    }
}

function getattr(el, name) {
    return el ? el.getAttribute(name) : null;
}

function showError(msg) {
    const container = document.getElementById('quiz-container');
    if (container) {
        container.innerHTML = `<div class="alert alert-danger text-center"><i class="fas fa-exclamation-triangle"></i> ${msg}</div>`;
    }
}

// Soruyu Ekranda Göster
function showQuestion(index) {
    currentQuestion = index;
    const q = questions[index];
    const container = document.getElementById('quiz-content');
    if (!container || !q) return;

    let answersHtml = '';
    q.answers.forEach(ans => {
        const isChecked = userAnswers[currentQuestion] == ans.id ? 'checked' : '';
        answersHtml += `
            <div class="form-check quiz-answer-item mb-2 p-2 border rounded cursor-pointer" onclick="selectAnswer(${ans.id})">
                <input class="form-check-input" type="radio" name="answer" id="ans-${ans.id}" value="${ans.id}" ${isChecked}>
                <label class="form-check-label w-100" for="ans-${ans.id}">${ans.answer}</label>
            </div>
        `;
    });

    container.innerHTML = `
        <div class="card shadow-sm p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="m-0">Soru ${index + 1} / ${questions.length}</h5>
                <span class="badge bg-secondary text-white">${window.QUIZ_TIMER ? window.QUIZ_TIMER : ''}</span>
            </div>
            <div class="progress mb-4" style="height: 5px;">
                <div class="progress-bar" role="progressbar" style="width: ${((index + 1) / questions.length) * 100}%"></div>
            </div>
            <h4 class="mb-4">${q.question}</h4>
            <div class="answers-list">${answersHtml}</div>
            <div class="mt-4 d-flex justify-content-between">
                <button class="btn btn-secondary" onclick="showQuestion(${index - 1})" ${index === 0 ? 'disabled' : ''}>
                    <i class="fas fa-arrow-left"></i> Geri
                </button>
                ${index === questions.length - 1
            ? `<button class="btn btn-success" onclick="finishQuiz()">Sınavı Bitir <i class="fas fa-check"></i></button>`
            : `<button class="btn btn-primary" onclick="showQuestion(${index + 1})">Sonraki <i class="fas fa-arrow-right"></i></button>`
        }
            </div>
        </div>
    `;
}

// Cevap Seçme
window.selectAnswer = function (id) {
    userAnswers[currentQuestion] = id;
    const radio = document.getElementById(`ans-${id}`);
    if (radio) radio.checked = true;

    // Görsel geri bildirim
    document.querySelectorAll('.quiz-answer-item').forEach(el => el.classList.remove('border-primary', 'bg-light'));
    if (radio) radio.closest('.quiz-answer-item').classList.add('border-primary', 'bg-light');
}

// GLOBAL fonksiyon dışarı açıyoruz ki HTML onclick görebilsin
window.showQuestion = showQuestion;

// SINAVI BİTİR VE KAYDET
window.finishQuiz = async function () {
    if (!confirm("Sınavı bitirmek istediğinize emin misiniz?")) return;

    const container = document.getElementById('quiz-container');
    const quizId = container ? container.dataset.quizId : null;

    const payload = {
        quiz_id: quizId,
        answers: userAnswers,
        questions: questions.map(q => q.id)
    };

    try {
        const response = await fetch(`modules/quiz/quiz-action.php?action=submitQuiz`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const result = await response.json();
        if (result.success) {
            alert(`Sınav Tamamlandı! Puanınız: %${result.percentage}`);
            window.location.href = "?page=quiz";
        } else {
            alert("Hata: " + result.message);
        }
    } catch (error) {
        console.error("Gönderme hatası:", error);
    }
}

// SPA ve Normal Yükleme Tetikleyicisi
// DOM değişikliğini izle, eğer quiz-container eklenirse ve henüz yüklenmediyse yükle.
const observer = new MutationObserver((mutations) => {
    if (document.getElementById('quiz-container')) {
        loadQuiz();
    }
});

observer.observe(document.body, { childList: true, subtree: true });

// İlk yükleme için
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('quiz-container')) loadQuiz();
});

// Manuel kontrol (Backup)
setInterval(() => {
    if (document.getElementById('quiz-container') && !isLoading && document.getElementById('quiz-loading') && !document.getElementById('quiz-loading').classList.contains('d-none')) {
        loadQuiz();
    }
}, 1000);
