// Quiz Module Hook JavaScript - Minimal global scripts

(function() {
    // Quiz modülü yüklendi bildirimi
    console.log('Quiz Module Loaded');
    
    // Global değişken
    window.quizModuleActive = true;
})();
