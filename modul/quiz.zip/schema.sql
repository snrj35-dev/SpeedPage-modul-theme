CREATE TABLE IF NOT EXISTS quizzes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    category_id INTEGER,
    created_by INTEGER NOT NULL,
    is_active INTEGER DEFAULT 1,
    time_limit INTEGER DEFAULT 0,
    pass_percentage INTEGER DEFAULT 0,
    random_questions INTEGER DEFAULT 0,
    questions_per_quiz INTEGER DEFAULT 0,
    show_certificate INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY(category_id) REFERENCES quiz_categories(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS quiz_categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    icon TEXT,
    color TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS question_pool (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    quiz_id INTEGER NOT NULL,
    question TEXT NOT NULL,
    difficulty TEXT CHECK(difficulty IN ('easy','medium','hard')) DEFAULT 'medium',
    points INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS questions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    quiz_id INTEGER NOT NULL,
    question TEXT NOT NULL,
    question_order INTEGER DEFAULT 0,
    difficulty TEXT CHECK(difficulty IN ('easy','medium','hard')) DEFAULT 'medium',
    points INTEGER DEFAULT 1,
    FOREIGN KEY(quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS answers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    question_id INTEGER NOT NULL,
    answer TEXT NOT NULL,
    is_correct INTEGER CHECK(is_correct IN (0,1)) DEFAULT 0,
    FOREIGN KEY(question_id) REFERENCES questions(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS pool_answers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pool_question_id INTEGER NOT NULL,
    answer TEXT NOT NULL,
    is_correct INTEGER CHECK(is_correct IN (0,1)) DEFAULT 0,
    FOREIGN KEY(pool_question_id) REFERENCES question_pool(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS user_results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    quiz_id INTEGER NOT NULL,
    score INTEGER DEFAULT 0,
    total_questions INTEGER DEFAULT 0,
    percentage REAL DEFAULT 0,
    time_spent INTEGER DEFAULT 0,
    passed INTEGER DEFAULT 0,
    completed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY(quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS certificates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    quiz_id INTEGER NOT NULL,
    result_id INTEGER NOT NULL,
    certificate_code TEXT UNIQUE NOT NULL,
    issued_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY(quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE,
    FOREIGN KEY(result_id) REFERENCES user_results(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS quiz_statistics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    quiz_id INTEGER NOT NULL,
    total_attempts INTEGER DEFAULT 0,
    total_users INTEGER DEFAULT 0,
    average_score REAL DEFAULT 0,
    pass_rate REAL DEFAULT 0,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE
);
