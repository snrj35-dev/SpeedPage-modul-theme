<?php
require_once __DIR__ . '/quiz-func.php';
require_once __DIR__ . '/../../settings.php';
require_once __DIR__ . '/../../admin/db.php';

// Dil dosyasını yükle
sp_load_language('quiz');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Rol kontrolü - editor veya admin olmalı
$userRole = $_SESSION['role'] ?? 'user';
if (!in_array($userRole, ['editor', 'admin'])) {
    die('<div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> ' . (__('error_unauthorized') ?? 'Yetkisiz erişim!') . '</div>');
}

$isAdmin = ($userRole === 'admin');
?>

<div class="container">
    <div class="page-header mb-4">
        <h1><i class="fas fa-cog"></i> <?= __('quiz_management') ?? 'Quiz Yönetimi' ?></h1>
    </div>
    
    <div class="admin-tabs">
        <button class="tab-btn active" onclick="switchTab('quizzes')">
            <i class="fas fa-list"></i> <?= __('quiz_management') ?? 'Quiz Yönetimi' ?>
        </button>
        <button class="tab-btn" onclick="switchTab('categories')">
            <i class="fas fa-folder"></i> <?= __('category_management') ?? 'Kategori Yönetimi' ?>
        </button>
        <button class="tab-btn" onclick="switchTab('statistics')">
            <i class="fas fa-chart-bar"></i> <?= __('statistics') ?? 'İstatistikler' ?>
        </button>
    </div>
    
    <!-- Quizler Tab -->
    <div id="quizzes-tab" class="tab-content active">
        <div class="admin-header">
            <h2><i class="fas fa-list"></i> <?= __('quiz_management') ?? 'Quiz Yönetimi' ?></h2>
            <button class="btn btn-primary" onclick="showCreateModal()">
                <i class="fas fa-plus"></i> <?= __('create_quiz') ?? 'Yeni Quiz' ?>
            </button>
        </div>
        
        <div id="quiz-list" class="loading">
            <i class="fas fa-spinner fa-spin"></i> <?= __('common_loading') ?? 'Yükleniyor...' ?>
        </div>
    </div>
    
    <!-- Kategoriler Tab -->
    <div id="categories-tab" class="tab-content">
        <div class="admin-header">
            <h2><i class="fas fa-folder"></i> <?= __('category_management') ?? 'Kategori Yönetimi' ?></h2>
            <button class="btn btn-primary" onclick="showCategoryModal()">
                <i class="fas fa-plus"></i> <?= __('create_category') ?? 'Yeni Kategori' ?>
            </button>
        </div>
        
        <div id="category-list" class="loading">
            <i class="fas fa-spinner fa-spin"></i> <?= __('common_loading') ?? 'Yükleniyor...' ?>
        </div>
    </div>
    
    <!-- İstatistikler Tab -->
    <div id="statistics-tab" class="tab-content">
        <h2><i class="fas fa-chart-bar"></i> <?= __('statistics') ?? 'İstatistikler' ?></h2>
        <div id="statistics-content" class="loading">
            <i class="fas fa-spinner fa-spin"></i> <?= __('common_loading') ?? 'Yükleniyor...' ?>
        </div>
    </div>
</div>

<!-- Quiz Oluşturma/Düzenleme Modal -->
<div class="modal" id="quiz-modal" style="display: none;">
    <div class="modal-content modal-large">
        <div class="modal-header">
            <h3 id="modal-title"><i class="fas fa-plus"></i> <?= __('create_quiz') ?? 'Yeni Quiz' ?></h3>
            <button class="close-btn" onclick="closeModal()">&times;</button>
        </div>
        <div class="modal-body">
            <input type="hidden" id="quiz-id">
            
            <div class="form-row">
                <div class="form-group">
                    <label><i class="fas fa-heading"></i> <?= __('quiz_title') ?? 'Başlık' ?></label>
                    <input type="text" id="quiz-title" class="form-control" placeholder="<?= __('quiz_title') ?? 'Quiz Başlığı' ?>" required>
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-folder"></i> <?= __('category') ?? 'Kategori' ?></label>
                    <select id="quiz-category" class="form-control">
                        <option value=""><?= __('category_select') ?? 'Kategori Seçin' ?></option>
                    </select>
                </div>
            </div>
            
            <div class="form-group">
                <label><i class="fas fa-align-left"></i> <?= __('description') ?? 'Açıklama' ?></label>
                <textarea id="quiz-description" rows="3" class="form-control" placeholder="<?= __('quiz_description') ?? 'Quiz Açıklaması' ?>"></textarea>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label><i class="fas fa-clock"></i> <?= __('time_limit') ?? 'Süre Limiti' ?> (<?= __('seconds') ?? 'saniye' ?>)</label>
                    <input type="number" id="quiz-time-limit" class="form-control" min="0" value="0">
                    <small class="form-text">0 = Süresiz</small>
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-percentage"></i> <?= __('pass_percentage') ?? 'Geçme Yüzdesi' ?> (%)</label>
                    <input type="number" id="quiz-pass-percentage" class="form-control" min="0" max="100" value="70">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>
                        <input type="checkbox" id="quiz-show-certificate">
                        <i class="fas fa-certificate"></i> <?= __('show_certificate') ?? 'Sertifika Göster' ?>
                    </label>
                </div>
                
                <div class="form-group">
                    <label>
                        <input type="checkbox" id="quiz-random-questions">
                        <i class="fas fa-random"></i> <?= __('random_questions') ?? 'Rastgele Sorular' ?>
                    </label>
                </div>
                
                <div class="form-group">
                    <label>
                        <input type="checkbox" id="quiz-is-active" checked>
                        <i class="fas fa-check-circle"></i> <?= __('active') ?? 'Aktif' ?>
                    </label>
                </div>
            </div>
            
            <div id="random-settings" style="display: none;">
                <div class="form-group">
                    <label><i class="fas fa-hashtag"></i> <?= __('questions_per_quiz') ?? 'Quiz Başına Soru Sayısı' ?></label>
                    <input type="number" id="quiz-questions-per-quiz" class="form-control" min="1" value="10">
                </div>
            </div>
            
            <div class="form-group">
                <label><i class="fas fa-question-circle"></i> <?= __('questions') ?? 'Sorular' ?></label>
                <div id="questions-container"></div>
                <button type="button" class="btn btn-secondary mt-2" onclick="addQuestion()">
                    <i class="fas fa-plus"></i> <?= __('add_question') ?? 'Soru Ekle' ?>
                </button>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeModal()">
                <i class="fas fa-times"></i> <?= __('cancel') ?? 'İptal' ?>
            </button>
            <button class="btn btn-primary" onclick="saveQuiz()">
                <i class="fas fa-save"></i> <?= __('save') ?? 'Kaydet' ?>
            </button>
        </div>
    </div>
</div>

<!-- Kategori Modal -->
<div class="modal" id="category-modal" style="display: none;">
    <div class="modal-content modal-small">
        <div class="modal-header">
            <h3><i class="fas fa-folder"></i> <span id="category-modal-title"><?= __('create_category') ?? 'Yeni Kategori' ?></span></h3>
            <button class="close-btn" onclick="closeCategoryModal()">&times;</button>
        </div>
        <div class="modal-body">
            <input type="hidden" id="category-id">
            
            <div class="form-group">
                <label><i class="fas fa-tag"></i> <?= __('category_name') ?? 'Kategori Adı' ?></label>
                <input type="text" id="category-name" class="form-control" placeholder="<?= __('category_name') ?? 'Kategori Adı' ?>" required>
            </div>
            
            <div class="form-group">
                <label><i class="fas fa-align-left"></i> <?= __('description') ?? 'Açıklama' ?></label>
                <textarea id="category-description" rows="3" class="form-control" placeholder="<?= __('category_description') ?? 'Kategori Açıklaması' ?>"></textarea>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label><i class="fas fa-icons"></i> <?= __('icon') ?? 'İkon' ?></label>
                    <select id="category-icon" class="form-control">
                        <option value="fa-brain">🧠 Brain</option>
                        <option value="fa-flask">⚗️ Flask</option>
                        <option value="fa-landmark">🏛️ Landmark</option>
                        <option value="fa-globe">🌍 Globe</option>
                        <option value="fa-book">📚 Book</option>
                        <option value="fa-calculator">🔢 Calculator</option>
                        <option value="fa-code">💻 Code</option>
                        <option value="fa-music">🎵 Music</option>
                        <option value="fa-palette">🎨 Art</option>
                        <option value="fa-dumbbell">💪 Sports</option>
                        <option value="fa-graduation-cap">🎓 Education</option>
                        <option value="fa-heartbeat">❤️ Health</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-palette"></i> <?= __('color') ?? 'Renk' ?></label>
                    <input type="color" id="category-color" class="form-control" value="#4F46E5">
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" onclick="closeCategoryModal()">
                <i class="fas fa-times"></i> <?= __('cancel') ?? 'İptal' ?>
            </button>
            <button class="btn btn-primary" onclick="saveCategory()">
                <i class="fas fa-save"></i> <?= __('save') ?? 'Kaydet' ?>
            </button>
        </div>
    </div>
</div>

<script>
    const CSRF_TOKEN = '<?= $_SESSION['csrf'] ?? '' ?>';
    const IS_ADMIN = <?= $isAdmin ? 'true' : 'false' ?>;
    
    // LANG nesnesini global olarak tanımla
    window.LANG = {
        quiz: {
            no_quizzes: '<?= __('quiz_no_quizzes') ?? 'Henüz quiz bulunmuyor.' ?>',
            question: '<?= __('question') ?? 'Soru' ?>',
            answer: '<?= __('answer') ?? 'Cevap' ?>',
            questions: '<?= __('questions') ?? 'Sorular' ?>',
            difficulty: '<?= __('difficulty') ?? 'Zorluk' ?>',
            points: '<?= __('points') ?? 'Puan' ?>',
            title: '<?= __('quiz_title') ?? 'Başlık' ?>',
            category: '<?= __('category') ?? 'Kategori' ?>',
            time_limit: '<?= __('time_limit') ?? 'Süre' ?>'
        },
        difficulty: {
            easy: '<?= __('difficulty_easy') ?? 'Kolay' ?>',
            medium: '<?= __('difficulty_medium') ?? 'Orta' ?>',
            hard: '<?= __('difficulty_hard') ?? 'Zor' ?>'
        },
        admin: {
            edit: '<?= __('edit') ?? 'Düzenle' ?>',
            delete: '<?= __('delete') ?? 'Sil' ?>',
            confirm_delete: '<?= __('confirm_delete') ?? 'Silmek istediğinizden emin misiniz?' ?>',
            creator: '<?= __('creator') ?? 'Oluşturan' ?>',
            created_at: '<?= __('created_at') ?? 'Tarih' ?>',
            actions: '<?= __('actions') ?? 'İşlemler' ?>',
            remove_question: '<?= __('remove_question') ?? 'Soruyu Sil' ?>',
            create_quiz: '<?= __('create_quiz') ?? 'Yeni Quiz' ?>'
        },
        common: {
            loading: '<?= __('common_loading') ?? 'Yükleniyor...' ?>',
            minutes: '<?= __('common_minutes') ?? 'dakika' ?>'
        },
        statistics: {
            total_attempts: '<?= __('stats_total_attempts') ?? 'Toplam Deneme' ?>',
            total_users: '<?= __('stats_total_users') ?? 'Toplam Kullanıcı' ?>',
            average_score: '<?= __('stats_average_score') ?? 'Ortalama Skor' ?>',
            pass_rate: '<?= __('stats_pass_rate') ?? 'Başarı Oranı' ?>'
        },
        category: {
            select: '<?= __('category_select') ?? 'Kategori Seçin' ?>'
        },
        errors: {
            required_fields: '<?= __('error_required_fields') ?? 'Gerekli alanları doldurun!' ?>',
            min_questions: '<?= __('error_min_questions') ?? 'En az 1 soru eklemelisiniz!' ?>',
            min_answers: '<?= __('error_min_answers') ?? 'Her soru en az 2 cevap içermelidir!' ?>',
            something_wrong: '<?= __('error_general') ?? 'Bir hata oluştu!' ?>',
            quiz_not_found: '<?= __('quiz_not_found') ?? 'Quiz bulunamadı' ?>'
        }
    };
</script>
