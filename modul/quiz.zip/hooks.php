<?php
declare(strict_types=1);

/**
 * Quiz Module Hooks
 */

// Quiz modülü için gerekli stil ve scriptleri ekle
add_hook('after_navbar', function () {
    if (!isset($_SESSION['user_id']))
        return;
    
    // Quiz bildirim sayısını göster (eğer varsa)
    ?>
    <script>
        window.quizModuleLoaded = true;
    </script>
    <?php
});

// Admin menüsüne quiz istatistiklerini ekle
add_hook('admin_dashboard_widgets', function () {
    if (!hasRole('editor'))
        return;
    
    require_once __DIR__ . '/quiz-func.php';
    
    global $db;
    $stmt = $db->query("
        SELECT COUNT(*) as total FROM quizzes WHERE is_active = 1
    ");
    $stats = $stmt->fetch();
    
    ?>
    <div class="stats-widget">
        <div class="widget-icon">
            <i class="fas fa-graduation-cap"></i>
        </div>
        <div class="widget-content">
            <h3><?= $stats['total'] ?? 0 ?></h3>
            <p>Aktif Quiz</p>
        </div>
    </div>
    <?php
});
