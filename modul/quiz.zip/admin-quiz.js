// Admin Quiz Panel - Module JavaScript

let quizzes = [];
let categories = [];
let currentQuizId = null;
let questionCounter = 0;

// API Base Path - Admin panelinde doğru çalışması için
const API_BASE = '../modules/quiz/';

// Tab değiştir
function switchTab(tabName) {
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));

    document.getElementById(tabName + '-tab').classList.add('active');
    event.target.classList.add('active');

    if (tabName === 'quizzes') {
        loadQuizzes();
    } else if (tabName === 'categories') {
        loadCategories();
    } else if (tabName === 'statistics') {
        loadStatistics();
    }
}

// Quizleri yükle
async function loadQuizzes() {
    try {
        const response = await fetch(`${API_BASE}quiz-action.php?action=getQuizzes`);
        const data = await response.json();

        if (data.success) {
            quizzes = data.quizzes;
            renderQuizList();
        }
    } catch (error) {
        console.error('Error:', error);
        showAlert(LANG.errors.something_wrong, 'danger');
    }
}

// Kategorileri yükle
async function loadCategories() {
    try {
        const response = await fetch(`${API_BASE}quiz-action.php?action=getCategories`);
        const data = await response.json();

        if (data.success) {
            categories = data.categories;
            renderCategoryList();
            updateCategorySelect();
        }
    } catch (error) {
        console.error('Error:', error);
        showAlert(LANG.errors.something_wrong, 'danger');
    }
}

// Quiz listesini render et
function renderQuizList() {
    const container = document.getElementById('quiz-list');

    if (!quizzes || quizzes.length === 0) {
        container.innerHTML = `<div class="alert alert-info"><i class="fas fa-info-circle"></i> ${LANG.quiz.no_quizzes}</div>`;
        return;
    }

    let html = '<div class="table-responsive"><table class="admin-table"><thead><tr>';
    html += `<th>${LANG.quiz.title || 'Başlık'}</th>`;
    html += `<th>${LANG.quiz.category || 'Kategori'}</th>`;
    html += `<th>${LANG.quiz.questions || 'Sorular'}</th>`;
    html += `<th>${LANG.quiz.time_limit || 'Süre'}</th>`;
    html += `<th>${LANG.admin.creator || 'Oluşturan'}</th>`;
    html += `<th>${LANG.admin.created_at || 'Tarih'}</th>`;
    html += `<th>${LANG.admin.actions || 'İşlemler'}</th>`;
    html += '</tr></thead><tbody id="quiz-list-body">';

    quizzes.forEach(quiz => {
        html += `
            <tr>
                <td><strong>${escapeHtml(quiz.title)}</strong></td>
                <td>${quiz.category_name ? `<span class="badge badge-primary">${escapeHtml(quiz.category_name)}</span>` : '-'}</td>
                <td><i class="fas fa-question-circle"></i> ${quiz.question_count}</td>
                <td>${quiz.time_limit > 0 ? Math.floor(quiz.time_limit / 60) + ' ' + (LANG.common.minutes || 'dk') : '-'}</td>
                <td>${escapeHtml(quiz.creator)}</td>
                <td>${new Date(quiz.created_at).toLocaleDateString('tr-TR')}</td>
                <td class="action-buttons">
                    <button class="btn btn-sm btn-primary" onclick="editQuiz(${quiz.id})" title="${LANG.admin.edit || 'Düzenle'}">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="deleteQuiz(${quiz.id})" title="${LANG.admin.delete || 'Sil'}">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    });

    html += '</tbody></table></div>';
    container.innerHTML = html;
}

// Kategori listesini render et
function renderCategoryList() {
    const container = document.getElementById('category-list');

    if (!categories || categories.length === 0) {
        container.innerHTML = `<div class="alert alert-info"><i class="fas fa-info-circle"></i> Henüz kategori bulunmuyor.</div>`;
        return;
    }

    let html = '<div class="category-grid">';

    categories.forEach(cat => {
        html += `
            <div class="category-card" style="border-left: 4px solid ${cat.color}">
                <div class="category-header">
                    <div class="category-icon" style="color: ${cat.color}">
                        <i class="fas ${cat.icon}"></i>
                    </div>
                    <h3>${escapeHtml(cat.name)}</h3>
                </div>
                <p>${escapeHtml(cat.description || '')}</p>
                <div class="category-meta">
                    <span><i class="fas fa-graduation-cap"></i> ${cat.quiz_count || 0} quiz</span>
                </div>
                ${IS_ADMIN ? `
                    <button class="btn btn-sm btn-danger" onclick="deleteCategory(${cat.id})">
                        <i class="fas fa-trash"></i> ${LANG.admin.delete || 'Sil'}
                    </button>
                ` : ''}
            </div>
        `;
    });

    html += '</div>';
    container.innerHTML = html;
}

// Kategori select'i güncelle
function updateCategorySelect() {
    const select = document.getElementById('quiz-category');
    if (!select) return;

    select.innerHTML = `<option value="">${LANG.category.select || 'Kategori Seçin'}</option>`;

    categories.forEach(cat => {
        const option = document.createElement('option');
        option.value = cat.id;
        option.textContent = cat.name;
        select.appendChild(option);
    });
}

// Yeni quiz modal'ını aç
function showCreateModal() {
    currentQuizId = null;
    document.getElementById('modal-title').innerHTML = `<i class="fas fa-plus"></i> ${LANG.admin.create_quiz || 'Yeni Quiz'}`;

    // Form alanlarını temizle
    const form = document.querySelector('#quiz-modal .modal-body');
    if (document.getElementById('quiz-id')) document.getElementById('quiz-id').value = '';
    document.getElementById('quiz-title').value = '';
    document.getElementById('quiz-description').value = '';
    document.getElementById('quiz-category').value = '';
    document.getElementById('quiz-time-limit').value = '0';
    document.getElementById('quiz-pass-percentage').value = '70';
    document.getElementById('quiz-show-certificate').checked = false;
    document.getElementById('quiz-random-questions').checked = false;
    document.getElementById('quiz-questions-per-quiz').value = '10';
    if (document.getElementById('quiz-is-active')) {
        document.getElementById('quiz-is-active').checked = true;
    }
    document.getElementById('questions-container').innerHTML = '';
    document.getElementById('random-settings').style.display = 'none';

    questionCounter = 0;

    loadCategories();
    addQuestion();
    document.getElementById('quiz-modal').style.display = 'flex';
}

// Modal'ı kapat
function closeModal() {
    document.getElementById('quiz-modal').style.display = 'none';
}

// Random soru seçimi checkbox handler
document.addEventListener('DOMContentLoaded', function () {
    const randomCheckbox = document.getElementById('quiz-random-questions');
    if (randomCheckbox) {
        randomCheckbox.addEventListener('change', function () {
            document.getElementById('random-settings').style.display = this.checked ? 'block' : 'none';
        });
    }
});

// Soru ekle
function addQuestion() {
    questionCounter++;
    const container = document.getElementById('questions-container');

    const questionDiv = document.createElement('div');
    questionDiv.className = 'question-item';
    questionDiv.dataset.id = questionCounter;

    questionDiv.innerHTML = `
        <div class="question-header">
            <strong><i class="fas fa-question-circle"></i> ${LANG.quiz.question || 'Soru'} ${questionCounter}</strong>
            <button type="button" class="btn btn-sm btn-danger" onclick="removeQuestion(${questionCounter})">
                <i class="fas fa-trash"></i> ${LANG.admin.remove_question || 'Sil'}
            </button>
        </div>
        <div class="form-group">
            <input type="text" class="question-text form-control" placeholder="${LANG.quiz.question || 'Soru metni'}">
        </div>
        <div class="form-row">
            <div class="form-group">
                <label><i class="fas fa-signal"></i> ${LANG.quiz.difficulty || 'Zorluk'}</label>
                <select class="question-difficulty form-control">
                    <option value="easy">${LANG.difficulty?.easy || 'Kolay'}</option>
                    <option value="medium" selected>${LANG.difficulty?.medium || 'Orta'}</option>
                    <option value="hard">${LANG.difficulty?.hard || 'Zor'}</option>
                </select>
            </div>
            <div class="form-group">
                <label><i class="fas fa-star"></i> ${LANG.quiz.points || 'Puan'}</label>
                <input type="number" class="question-points form-control" min="1" value="10">
            </div>
        </div>
        <div class="answers-container">
            <label><i class="fas fa-list"></i> ${LANG.quiz.answers || 'Cevaplar'} (Doğru cevabı işaretleyin):</label>
            ${[1, 2, 3, 4].map((num, idx) => `
                <div class="answer-item">
                    <input type="text" class="answer-text form-control" placeholder="${LANG.quiz.answer || 'Cevap'} ${num}">
                    <label class="correct-label">
                        <input type="radio" name="correct-${questionCounter}" value="${idx}" ${idx === 0 ? 'checked' : ''}> 
                        <i class="fas fa-check-circle"></i> Doğru
                    </label>
                </div>
            `).join('')}
        </div>
    `;

    container.appendChild(questionDiv);
}

// Soru sil
function removeQuestion(id) {
    const question = document.querySelector(`[data-id="${id}"]`);
    if (question && confirm(`${LANG.quiz.question || 'Soru'} silinsin mi?`)) {
        question.remove();
    }
}

// Quiz kaydet
async function saveQuiz() {
    const title = document.getElementById('quiz-title').value.trim();
    const description = document.getElementById('quiz-description').value.trim();
    const categoryId = document.getElementById('quiz-category').value;
    const timeLimit = parseInt(document.getElementById('quiz-time-limit').value) || 0;
    const passPercentage = parseInt(document.getElementById('quiz-pass-percentage').value) || 70;
    const showCertificate = document.getElementById('quiz-show-certificate').checked ? 1 : 0;
    const randomQuestions = document.getElementById('quiz-random-questions').checked ? 1 : 0;
    const questionsPerQuiz = parseInt(document.getElementById('quiz-questions-per-quiz').value) || 0;
    const isActive = document.getElementById('quiz-is-active') ? (document.getElementById('quiz-is-active').checked ? 1 : 0) : 1;

    if (!title) {
        showAlert(LANG.errors?.required_fields || 'Başlık gereklidir!', 'warning');
        return;
    }

    const questions = [];
    const questionItems = document.querySelectorAll('.question-item');

    let hasError = false;

    questionItems.forEach((item, index) => {
        if (hasError) return;

        const questionText = item.querySelector('.question-text').value.trim();
        if (!questionText) {
            showAlert(`${LANG.quiz.question || 'Soru'} ${index + 1} boş bırakılamaz!`, 'warning');
            hasError = true;
            return;
        }

        const difficulty = item.querySelector('.question-difficulty').value;
        const points = parseInt(item.querySelector('.question-points').value) || 1;
        const answers = [];
        const answerItems = item.querySelectorAll('.answer-item');
        const correctRadio = item.querySelector('input[type="radio"]:checked');
        const correctIndex = correctRadio ? parseInt(correctRadio.value) : 0;

        answerItems.forEach((answerItem, ansIndex) => {
            const answerText = answerItem.querySelector('.answer-text').value.trim();
            if (!answerText) {
                showAlert(`${LANG.quiz.question || 'Soru'} ${index + 1}, Cevap ${ansIndex + 1} boş bırakılamaz!`, 'warning');
                hasError = true;
                return;
            }

            answers.push({
                answer: answerText,
                is_correct: ansIndex === correctIndex ? 1 : 0
            });
        });

        if (answers.length < 2) {
            showAlert(`${LANG.quiz.question || 'Soru'} ${index + 1} en az 2 cevap olmalı!`, 'warning');
            hasError = true;
            return;
        }

        questions.push({
            question: questionText,
            difficulty: difficulty,
            points: points,
            answers: answers
        });
    });

    if (hasError) return;

    if (questions.length === 0) {
        showAlert(LANG.errors?.min_questions || 'En az 1 soru eklemelisiniz!', 'warning');
        return;
    }

    const payload = {
        title,
        description,
        category_id: categoryId || null,
        time_limit: timeLimit,
        pass_percentage: passPercentage,
        show_certificate: showCertificate,
        random_questions: randomQuestions,
        questions_per_quiz: questionsPerQuiz,
        is_active: isActive,
        questions,
        csrf_token: CSRF_TOKEN
    };

    try {
        const url = currentQuizId
            ? `${API_BASE}quiz-action.php?action=updateQuiz`
            : `${API_BASE}quiz-action.php?action=createQuiz`;

        if (currentQuizId) {
            payload.id = currentQuizId;
        }

        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const data = await response.json();

        if (data.success) {
            showAlert(currentQuizId ? 'Quiz güncellendi!' : 'Quiz oluşturuldu!', 'success');
            closeModal();
            loadQuizzes();
        } else {
            showAlert(data.message || LANG.errors.something_wrong, 'danger');
        }
    } catch (error) {
        console.error('Error:', error);
        showAlert(LANG.errors.something_wrong, 'danger');
    }
}

// Quiz düzenle
async function editQuiz(id) {
    try {
        const response = await fetch(`${API_BASE}quiz-action.php?action=getQuizDetails&id=${id}`);
        const data = await response.json();

        if (!data.success) {
            showAlert(data.message || LANG.errors.quiz_not_found, 'danger');
            return;
        }

        currentQuizId = id;
        const quiz = data.quiz;

        document.getElementById('modal-title').innerHTML = `<i class="fas fa-edit"></i> ${LANG.admin.edit || 'Düzenle'}: ${escapeHtml(quiz.title)}`;

        if (document.getElementById('quiz-id')) document.getElementById('quiz-id').value = id;
        document.getElementById('quiz-title').value = quiz.title;
        document.getElementById('quiz-description').value = quiz.description || '';
        document.getElementById('quiz-category').value = quiz.category_id || '';
        document.getElementById('quiz-time-limit').value = quiz.time_limit || 0;
        document.getElementById('quiz-pass-percentage').value = quiz.pass_percentage || 70;
        document.getElementById('quiz-show-certificate').checked = quiz.show_certificate == 1;
        document.getElementById('quiz-random-questions').checked = quiz.random_questions == 1;
        document.getElementById('quiz-questions-per-quiz').value = quiz.questions_per_quiz || 10;
        if (document.getElementById('quiz-is-active')) {
            document.getElementById('quiz-is-active').checked = quiz.is_active == 1;
        }
        document.getElementById('random-settings').style.display = quiz.random_questions == 1 ? 'block' : 'none';

        document.getElementById('questions-container').innerHTML = '';
        questionCounter = 0;

        await loadCategories();

        if (quiz.questions && quiz.questions.length > 0) {
            quiz.questions.forEach((q) => {
                addQuestion();
                const questionItem = document.querySelector(`[data-id="${questionCounter}"]`);
                questionItem.querySelector('.question-text').value = q.question;
                questionItem.querySelector('.question-difficulty').value = q.difficulty || 'medium';
                questionItem.querySelector('.question-points').value = q.points || 10;

                const answerItems = questionItem.querySelectorAll('.answer-item');
                let correctIndex = 0;

                q.answers.forEach((a, aIndex) => {
                    if (answerItems[aIndex]) {
                        answerItems[aIndex].querySelector('.answer-text').value = a.answer;
                        if (a.is_correct == 1) {
                            correctIndex = aIndex;
                        }
                    }
                });

                // Doğru cevabı işaretle
                const correctRadio = questionItem.querySelector(`input[name="correct-${questionCounter}"][value="${correctIndex}"]`);
                if (correctRadio) correctRadio.checked = true;
            });
        } else {
            addQuestion();
        }

        document.getElementById('quiz-modal').style.display = 'flex';

    } catch (error) {
        console.error('Error:', error);
        showAlert(LANG.errors.quiz_not_found, 'danger');
    }
}

// Quiz sil
async function deleteQuiz(id) {
    if (!confirm(LANG.admin?.confirm_delete || 'Silmek istediğinizden emin misiniz?')) {
        return;
    }

    try {
        const response = await fetch(`${API_BASE}quiz-action.php?action=deleteQuiz`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id, csrf_token: CSRF_TOKEN })
        });

        const data = await response.json();

        if (data.success) {
            showAlert('Quiz silindi!', 'success');
            loadQuizzes();
        } else {
            showAlert(data.message || LANG.errors.something_wrong, 'danger');
        }
    } catch (error) {
        console.error('Error:', error);
        showAlert(LANG.errors.something_wrong, 'danger');
    }
}

// Kategori modal
function showCategoryModal() {
    if (document.getElementById('category-id')) document.getElementById('category-id').value = '';
    document.getElementById('category-name').value = '';
    document.getElementById('category-description').value = '';
    document.getElementById('category-icon').value = 'fa-brain';
    document.getElementById('category-color').value = '#4F46E5';
    document.getElementById('category-modal-title').textContent = LANG.admin?.create_category || 'Yeni Kategori';
    document.getElementById('category-modal').style.display = 'flex';
}

function closeCategoryModal() {
    document.getElementById('category-modal').style.display = 'none';
}

// Kategori kaydet
async function saveCategory() {
    const name = document.getElementById('category-name').value.trim();
    const description = document.getElementById('category-description').value.trim();
    const icon = document.getElementById('category-icon').value;
    const color = document.getElementById('category-color').value;

    if (!name) {
        showAlert(LANG.errors?.required_fields || 'Kategori adı gereklidir!', 'warning');
        return;
    }

    try {
        const response = await fetch(`${API_BASE}quiz-action.php?action=createCategory`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, description, icon, color, csrf_token: CSRF_TOKEN })
        });

        const data = await response.json();

        if (data.success) {
            showAlert('Kategori oluşturuldu!', 'success');
            closeCategoryModal();
            loadCategories();
        } else {
            showAlert(data.message || LANG.errors.something_wrong, 'danger');
        }
    } catch (error) {
        console.error('Error:', error);
        showAlert(LANG.errors.something_wrong, 'danger');
    }
}

// Kategori sil
async function deleteCategory(id) {
    if (!confirm(LANG.admin?.confirm_delete || 'Bu kategoriyi silmek istediğinizden emin misiniz?')) {
        return;
    }

    try {
        const response = await fetch(`${API_BASE}quiz-action.php?action=deleteCategory`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id, csrf_token: CSRF_TOKEN })
        });

        const data = await response.json();

        if (data.success) {
            showAlert('Kategori silindi!', 'success');
            loadCategories();
        } else {
            showAlert(data.message || LANG.errors.something_wrong, 'danger');
        }
    } catch (error) {
        console.error('Error:', error);
        showAlert(LANG.errors.something_wrong, 'danger');
    }
}

// İstatistikleri yükle
async function loadStatistics() {
    try {
        const response = await fetch(`${API_BASE}quiz-action.php?action=getStatistics`);
        const data = await response.json();

        if (data.success) {
            renderStatistics(data.statistics);
        }
    } catch (error) {
        console.error('Error:', error);
        showAlert(LANG.errors.something_wrong, 'danger');
    }
}

// İstatistikleri render et
function renderStatistics(stats) {
    const container = document.getElementById('statistics-content');

    let html = '<div class="stats-grid">';

    html += `
        <div class="stat-card">
            <i class="fas fa-clipboard-list"></i>
            <h3>${stats.total_attempts || 0}</h3>
            <p>${LANG.statistics?.total_attempts || 'Toplam Deneme'}</p>
        </div>
        
        <div class="stat-card">
            <i class="fas fa-users"></i>
            <h3>${stats.total_users || 0}</h3>
            <p>${LANG.statistics?.total_users || 'Toplam Kullanıcı'}</p>
        </div>
        
        <div class="stat-card">
            <i class="fas fa-percentage"></i>
            <h3>${Math.round(stats.avg_percentage || 0)}%</h3>
            <p>${LANG.statistics?.average_score || 'Ortalama Skor'}</p>
        </div>
        
        <div class="stat-card">
            <i class="fas fa-check-circle"></i>
            <h3>${Math.round(stats.pass_rate || 0)}%</h3>
            <p>${LANG.statistics?.pass_rate || 'Başarı Oranı'}</p>
        </div>
    `;

    html += '</div>';
    container.innerHTML = html;
}

// Alert göster
function showAlert(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.innerHTML = `<i class="fas fa-${type === 'success' ? 'check' : type === 'danger' ? 'exclamation' : 'info'}-circle"></i> ${message}`;
    alertDiv.style.cssText = 'position:fixed;top:20px;right:20px;z-index:9999;min-width:300px;animation:slideIn 0.3s;';

    document.body.appendChild(alertDiv);

    setTimeout(() => {
        alertDiv.style.animation = 'slideOut 0.3s';
        setTimeout(() => alertDiv.remove(), 300);
    }, 3000);
}

// HTML escape
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Sayfa yüklendiğinde
document.addEventListener('DOMContentLoaded', function () {
    loadQuizzes();
    loadCategories();
});
