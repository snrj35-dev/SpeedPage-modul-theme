<?php
require_once __DIR__ . '/quiz-func.php';
require_once __DIR__ . '/../../settings.php';
require_once __DIR__ . '/../../admin/db.php';

// Dil dosyasını yükle
sp_load_language('quiz');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$quizId = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($quizId > 0): ?>
    <div id="quiz-container" class="container mt-4" data-quiz-id="<?= $quizId ?>">
        <div id="quiz-loading" class="text-center">
            <div class="spinner-border text-primary" role="status"></div>
            <p class="mt-2">Quiz Yükleniyor...</p>
        </div>
        <div id="quiz-content" class="d-none">
            <!-- Quiz içeriği buraya yüklenecek -->
        </div>
    </div>

<?php else: ?>
    <!-- Normal quiz listesi -->
    <?php
    $userId = $_SESSION['user_id'] ?? 0;
    $categoryFilter = $_GET['category'] ?? '';

    // Kategorileri getir
    $categories = getQuizCategories();

    // Aktif quizleri getir
    $quizzes = getActiveQuizzes($categoryFilter ? (int) $categoryFilter : null);
    ?>

    <div class="container mt-4">
        <div class="page-header mb-4">
            <h1><i class="fas fa-graduation-cap"></i>
                <?= __('quiz_available_quizzes') ?? 'Mevcut Quizler' ?>
            </h1>
        </div>

        <div class="category-filter mb-4">
            <a href="?page=quiz" data-page="quiz" class="category-btn <?= !$categoryFilter ? 'active' : '' ?>">
                <i class="fas fa-th"></i>
                <?= __('category_all') ?? 'Tüm Kategoriler' ?>
            </a>
            <?php foreach ($categories as $cat): ?>
                <a href="?page=quiz&category=<?= $cat['id'] ?>" data-page="quiz&category=<?= $cat['id'] ?>"
                    class="category-btn <?= $categoryFilter == $cat['id'] ? 'active' : '' ?>"
                    style="--cat-color: <?= $cat['color'] ?>">
                    <i class="fas <?= $cat['icon'] ?>"></i>
                    <?= e($cat['name']) ?>
                    <span class="badge">
                        <?= $cat['quiz_count'] ?>
                    </span>
                </a>
            <?php endforeach; ?>
        </div>

        <?php if (empty($quizzes)): ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i>
                <?= __('quiz_no_quizzes') ?? 'Henüz quiz bulunmuyor.' ?>
            </div>
        <?php else: ?>
            <div class="quiz-grid">
                <?php foreach ($quizzes as $quiz): ?>
                    <div class="quiz-card">
                        <div class="quiz-header">
                            <?php if ($quiz['category_icon']): ?>
                                <div class="quiz-icon" style="background: <?= $quiz['category_color'] ?>">
                                    <i class="fas <?= $quiz['category_icon'] ?>"></i>
                                </div>
                            <?php endif; ?>

                            <h3>
                                <?= e($quiz['title']) ?>
                            </h3>
                            <p>
                                <?= e($quiz['description'] ?? '') ?>
                            </p>

                            <div class="quiz-meta">
                                <span>
                                    <i class="fas fa-question-circle"></i>
                                    <?= $quiz['question_count'] ?>
                                    <?= __('quiz_questions') ?? 'Soru' ?>
                                </span>
                                <?php if ($quiz['user_attempts'] > 0): ?>
                                    <span class="text-success">
                                        <i class="fas fa-check"></i>
                                        <?= $quiz['user_attempts'] ?>
                                        <?= __('quiz_attempts') ?? 'deneme' ?>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <?php if ($quiz['time_limit'] > 0): ?>
                                <div class="quiz-info">
                                    <i class="fas fa-clock"></i>
                                    <?= floor($quiz['time_limit'] / 60) ?>
                                    <?= __('common_minutes') ?? 'dakika' ?>
                                </div>
                            <?php endif; ?>

                            <?php if ($quiz['show_certificate']): ?>
                                <div class="quiz-badge">
                                    <i class="fas fa-certificate"></i>
                                    <?= __('certificate_available') ?? 'Sertifika Mevcut' ?>
                                </div>
                            <?php endif; ?>

                            <a href="?page=quiz&id=<?= $quiz['id'] ?>" data-page="quiz&id=<?= $quiz['id'] ?>"
                                class="btn btn-primary btn-block">
                                <i class="fas fa-play"></i>
                                <?= __('quiz_start') ?? 'Quize Başla' ?>
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>