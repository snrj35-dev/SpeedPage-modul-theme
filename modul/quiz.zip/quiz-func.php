<?php
declare(strict_types=1);

/**
 * Quiz Module Functions
 */

function getQuizById(int $quizId): ?array
{
    global $db;
    $stmt = $db->prepare("
        SELECT q.*, c.name as category_name, c.icon as category_icon, c.color as category_color,
               u.username as creator_name
        FROM quizzes q
        LEFT JOIN quiz_categories c ON q.category_id = c.id
        LEFT JOIN users u ON q.created_by = u.id
        WHERE q.id = ?
    ");
    $stmt->execute([$quizId]);
    $result = $stmt->fetch();
    return $result ?: null;
}

function getActiveQuizzes(?int $categoryId = null): array
{
    global $db;
    
    $sql = "
        SELECT q.*, c.name as category_name, c.icon as category_icon, c.color as category_color,
               (SELECT COUNT(*) FROM questions WHERE quiz_id = q.id) as question_count,
               (SELECT COUNT(*) FROM user_results WHERE quiz_id = q.id AND user_id = ?) as user_attempts
        FROM quizzes q
        LEFT JOIN quiz_categories c ON q.category_id = c.id
        WHERE q.is_active = 1
    ";
    
    if ($categoryId) {
        $sql .= " AND q.category_id = ?";
    }
    
    $sql .= " ORDER BY q.created_at DESC";
    
    $stmt = $db->prepare($sql);
    
    if ($categoryId) {
        $stmt->execute([($_SESSION['user_id'] ?? 0), $categoryId]);
    } else {
        $stmt->execute([($_SESSION['user_id'] ?? 0)]);
    }
    
    return $stmt->fetchAll();
}

function getQuizCategories(): array
{
    global $db;
    $stmt = $db->query("
        SELECT c.*, 
               (SELECT COUNT(*) FROM quizzes WHERE category_id = c.id AND is_active = 1) as quiz_count
        FROM quiz_categories c 
        ORDER BY c.name
    ");
    return $stmt->fetchAll();
}

function createQuizCategory(string $name, string $description = '', string $icon = 'fa-folder', string $color = '#4F46E5'): int
{
    global $db;
    $stmt = $db->prepare("
        INSERT INTO quiz_categories (name, description, icon, color)
        VALUES (?, ?, ?, ?)
    ");
    $stmt->execute([$name, $description, $icon, $color]);
    return (int) $db->lastInsertId();
}

function deleteQuizCategory(int $categoryId): bool
{
    global $db;
    $stmt = $db->prepare("DELETE FROM quiz_categories WHERE id = ?");
    return $stmt->execute([$categoryId]);
}

function createQuiz(array $data): int
{
    global $db;
    
    $db->beginTransaction();
    
    try {
        // Quiz oluştur
        $stmt = $db->prepare("
            INSERT INTO quizzes (title, description, category_id, created_by, time_limit, 
                                pass_percentage, random_questions, questions_per_quiz, show_certificate, is_active)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $data['title'],
            $data['description'] ?? '',
            $data['category_id'] ?? null,
            $_SESSION['user_id'],
            $data['time_limit'] ?? 0,
            $data['pass_percentage'] ?? 0,
            $data['random_questions'] ?? 0,
            $data['questions_per_quiz'] ?? 0,
            $data['show_certificate'] ?? 0,
            $data['is_active'] ?? 1
        ]);
        
        $quizId = (int) $db->lastInsertId();
        
        // Sorular ekle
        if (isset($data['questions']) && is_array($data['questions'])) {
            foreach ($data['questions'] as $index => $question) {
                $stmt = $db->prepare("
                    INSERT INTO questions (quiz_id, question, question_order, difficulty, points)
                    VALUES (?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $quizId,
                    $question['question'],
                    $index,
                    $question['difficulty'] ?? 'medium',
                    $question['points'] ?? 1
                ]);
                
                $questionId = (int) $db->lastInsertId();
                
                // Cevapları ekle
                if (isset($question['answers']) && is_array($question['answers'])) {
                    foreach ($question['answers'] as $answer) {
                        $stmt = $db->prepare("
                            INSERT INTO answers (question_id, answer, is_correct)
                            VALUES (?, ?, ?)
                        ");
                        $stmt->execute([
                            $questionId,
                            $answer['answer'],
                            $answer['is_correct'] ? 1 : 0
                        ]);
                    }
                }
            }
        }
        
        $db->commit();
        return $quizId;
        
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

function updateQuiz(int $quizId, array $data): bool
{
    global $db;
    
    $db->beginTransaction();
    
    try {
        // Quiz güncelle
        $stmt = $db->prepare("
            UPDATE quizzes 
            SET title = ?, description = ?, category_id = ?, time_limit = ?, 
                pass_percentage = ?, random_questions = ?, questions_per_quiz = ?, show_certificate = ?, is_active = ?
            WHERE id = ?
        ");
        $stmt->execute([
            $data['title'],
            $data['description'] ?? '',
            $data['category_id'] ?? null,
            $data['time_limit'] ?? 0,
            $data['pass_percentage'] ?? 0,
            $data['random_questions'] ?? 0,
            $data['questions_per_quiz'] ?? 0,
            $data['show_certificate'] ?? 0,
            $data['is_active'] ?? 1,
            $quizId
        ]);
        
        // Mevcut soruları sil
        $stmt = $db->prepare("DELETE FROM questions WHERE quiz_id = ?");
        $stmt->execute([$quizId]);
        
        // Yeni soruları ekle
        if (isset($data['questions']) && is_array($data['questions'])) {
            foreach ($data['questions'] as $index => $question) {
                $stmt = $db->prepare("
                    INSERT INTO questions (quiz_id, question, question_order, difficulty, points)
                    VALUES (?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $quizId,
                    $question['question'],
                    $index,
                    $question['difficulty'] ?? 'medium',
                    $question['points'] ?? 1
                ]);
                
                $questionId = (int) $db->lastInsertId();
                
                // Cevapları ekle
                if (isset($question['answers']) && is_array($question['answers'])) {
                    foreach ($question['answers'] as $answer) {
                        $stmt = $db->prepare("
                            INSERT INTO answers (question_id, answer, is_correct)
                            VALUES (?, ?, ?)
                        ");
                        $stmt->execute([
                            $questionId,
                            $answer['answer'],
                            $answer['is_correct'] ? 1 : 0
                        ]);
                    }
                }
            }
        }
        
        $db->commit();
        return true;
        
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

function deleteQuiz(int $quizId): bool
{
    global $db;
    $stmt = $db->prepare("DELETE FROM quizzes WHERE id = ?");
    return $stmt->execute([$quizId]);
}

function getQuizQuestions(int $quizId, bool $randomize = false, int $limit = 0): array
{
    global $db;
    
    $sql = "
        SELECT q.id, q.question, q.question_order, q.difficulty, q.points
        FROM questions q
        WHERE q.quiz_id = ?
    ";
    
    if ($randomize) {
        $sql .= " ORDER BY RANDOM()";
    } else {
        $sql .= " ORDER BY q.question_order ASC";
    }
    
    if ($limit > 0) {
        $sql .= " LIMIT ?";
    }
    
    $stmt = $db->prepare($sql);
    
    if ($limit > 0) {
        $stmt->execute([$quizId, $limit]);
    } else {
        $stmt->execute([$quizId]);
    }
    
    $questions = $stmt->fetchAll();
    
    // Her soru için cevapları getir
    foreach ($questions as &$question) {
        $stmt = $db->prepare("
            SELECT id, answer
            FROM answers
            WHERE question_id = ?
            ORDER BY RANDOM()
        ");
        $stmt->execute([$question['id']]);
        $question['answers'] = $stmt->fetchAll();
    }
    
    return $questions;
}

function submitQuizResult(int $userId, int $quizId, array $answers, int $timeSpent): array
{
    global $db;
    
    $score = 0;
    $totalPoints = 0;
    $earnedPoints = 0;
    
    foreach ($answers as $answerId) {
        // Cevabı kontrol et
        $stmt = $db->prepare("
            SELECT a.is_correct, COALESCE(q.points, 1) as points
            FROM answers a
            LEFT JOIN questions q ON a.question_id = q.id
            WHERE a.id = ?
        ");
        $stmt->execute([$answerId]);
        $answer = $stmt->fetch();
        
        if ($answer) {
            $totalPoints += $answer['points'];
            if ($answer['is_correct'] == 1) {
                $score++;
                $earnedPoints += $answer['points'];
            }
        }
    }
    
    $total = count($answers);
    $percentage = $total > 0 ? ($score / $total) * 100 : 0;
    
    // Quiz bilgilerini al
    $quiz = getQuizById($quizId);
    $passed = $percentage >= ($quiz['pass_percentage'] ?? 0) ? 1 : 0;
    
    // Sonucu kaydet
    $stmt = $db->prepare("
        INSERT INTO user_results (user_id, quiz_id, score, total_questions, percentage, time_spent, passed)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([$userId, $quizId, $score, $total, $percentage, $timeSpent, $passed]);
    $resultId = (int) $db->lastInsertId();
    
    // İstatistikleri güncelle
    updateQuizStatistics($quizId);
    
    // Sertifika oluştur (eğer geçti ve sertifika aktifse)
    if ($passed && $quiz['show_certificate']) {
        generateCertificate($userId, $quizId, $resultId);
    }
    
    return [
        'result_id' => $resultId,
        'score' => $score,
        'total' => $total,
        'percentage' => round($percentage, 2),
        'passed' => $passed,
        'time_spent' => $timeSpent
    ];
}

function updateQuizStatistics(int $quizId): void
{
    global $db;
    
    $stmt = $db->prepare("
        SELECT 
            COUNT(*) as total_attempts,
            COUNT(DISTINCT user_id) as total_users,
            AVG(percentage) as avg_percentage,
            SUM(CASE WHEN passed = 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(*) as pass_rate
        FROM user_results
        WHERE quiz_id = ?
    ");
    $stmt->execute([$quizId]);
    $stats = $stmt->fetch();
    
    $stmt = $db->prepare("
        INSERT OR REPLACE INTO quiz_statistics (quiz_id, total_attempts, total_users, average_score, pass_rate, updated_at)
        VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
    ");
    $stmt->execute([
        $quizId,
        $stats['total_attempts'],
        $stats['total_users'],
        $stats['avg_percentage'],
        $stats['pass_rate']
    ]);
}

function generateCertificate(int $userId, int $quizId, int $resultId): string
{
    global $db;
    
    // Benzersiz sertifika kodu oluştur
    $certificateCode = strtoupper(substr(md5(uniqid((string)$userId, true)), 0, 12));
    
    $stmt = $db->prepare("
        INSERT INTO certificates (user_id, quiz_id, result_id, certificate_code)
        VALUES (?, ?, ?, ?)
    ");
    $stmt->execute([$userId, $quizId, $resultId, $certificateCode]);
    
    return $certificateCode;
}

function getUserResults(int $userId, ?int $quizId = null): array
{
    global $db;
    
    $sql = "
        SELECT ur.*, q.title as quiz_title, q.show_certificate,
               c.certificate_code
        FROM user_results ur
        LEFT JOIN quizzes q ON ur.quiz_id = q.id
        LEFT JOIN certificates c ON ur.id = c.result_id
        WHERE ur.user_id = ?
    ";
    
    if ($quizId) {
        $sql .= " AND ur.quiz_id = ?";
    }
    
    $sql .= " ORDER BY ur.completed_at DESC";
    
    $stmt = $db->prepare($sql);
    
    if ($quizId) {
        $stmt->execute([$userId, $quizId]);
    } else {
        $stmt->execute([$userId]);
    }
    
    return $stmt->fetchAll();
}

function getQuizStatistics(int $quizId): ?array
{
    global $db;
    $stmt = $db->prepare("SELECT * FROM quiz_statistics WHERE quiz_id = ?");
    $stmt->execute([$quizId]);
    $result = $stmt->fetch();
    return $result ?: null;
}

function getAllQuizzes(): array
{
    global $db;
    $stmt = $db->query("
        SELECT q.*, u.username as creator, c.name as category_name,
               (SELECT COUNT(*) FROM questions WHERE quiz_id = q.id) as question_count
        FROM quizzes q
        JOIN users u ON q.created_by = u.id
        LEFT JOIN quiz_categories c ON q.category_id = c.id
        ORDER BY q.created_at DESC
    ");
    return $stmt->fetchAll();
}
